# Vesper Client

A dark-first, CPvP-focused Fabric client mod for **Minecraft 1.21.11** (Java 21). Original name and design; inspired by the *category* of
clients like Dawn, with no code, branding or assets copied.

> **Status: milestone 1, written but not yet compiled against Minecraft.** The framework-free parts are tested (see below).
> The Minecraft-facing code (GUI, HUD, modules) has never been built or run in-game. Expect to fix a few compile errors on
> first build; see "If the build fails". Do not treat anything in the "unverified" column as working until you have run it.

## Get the .jar (no local setup)

1. Create an empty GitHub repository and push this folder to it (`git init && git add . && git commit -m init && git push`).
2. Open the **Actions** tab. The `build` workflow runs automatically (about 3-5 minutes the first time).
3. Open the finished run and download the **vesper-client** artifact. It contains `vesper-client-0.1.0.jar`.
4. Install Fabric Loader (0.18.1+) and **Fabric API** for 1.21.11, then put the jar in `.minecraft/mods`.

Local build instead: install JDK 21 and Gradle 9.x, run `gradle wrapper --gradle-version 9.2.0` once, then `./gradlew build`
(jar in `build/libs/`) and `./gradlew coreTests`. `./gradlew runClient` starts a dev client.

## If the build fails

The workflow uploads whatever it built and always runs tests, so open the failed step and send the error text back; each
fix is usually one line. Version pins live in `gradle.properties` (`fabric_version`, `loader_version`, `loom_version`); if Gradle
says one does not exist, take the newest 1.21.11 entry from <https://fabricmc.net/develop/>.

Minecraft API calls most likely to need adjusting (all names are Mojang official mappings, 1.21.11):

| File | What |
|---|---|
| `mc/Keys.java` | window handle (`getWindow().handle()`), `InputConstants` key names |
| `gui/ClickGui.java`, `gui/HudEditorScreen.java` | `Screen` input signatures (`MouseButtonEvent`, `KeyEvent`, `CharacterEvent`), `KeyEvent.modifiers()` |
| `hud/HudModule.java`, `gui/Draw.java` | `GuiGraphics` calls: `pose().pushMatrix()/translate/scale`, `fill`, `drawString`, scissor, `renderItem` |
| `VesperClient.java` | `HudRenderCallback` (deprecated in newer Fabric API; swap for `HudElementRegistry`) |
| `mc/McUtil.java` | enchantment holders (`Holder.is(Enchantments.X)`), `getArmorValue`, attribute lookup |
| `mc/Exposure.java` | `ClipContext` constructor |
| `modules/CleanVisuals.java` | option accessors (`damageTiltStrength`, `fovEffectScale`, `screenEffectScale`) |

## What is in milestone 1

| Area | Feature | Status |
|---|---|---|
| Core | Module framework (lifecycle, settings, keybinds, error isolation: a module failing 3x in a row is disabled) | lifecycle + settings **tested**; Minecraft glue unverified |
| Config | Versioned JSON profiles, migrations, corrupt-file recovery (backup + defaults), validation with fix-it messages, debounced async atomic saves, import/export (data only, never executed) | **tested** (30 checks) |
| Combat math | Crystal damage: exposure-independent math for difficulty, armor/toughness, Resistance, Protection/Blast Protection (EPF cap 20), absorption | **tested** against hand-derived values (14 checks); **not validated against the real game** |
| Combat info | Crystal Damage HUD (self + target, placement preview, lethal notice), Target Info, Combat Alerts (inferred totem pops, low totems/armor), Combat Timer, Item Counters | unverified in-game |
| QoL | Armor Status, Info (FPS/ping/server), Coordinates, CPS, Potion Timers, Module List, Notifications | unverified in-game |
| Visual | Clean Visuals (particles, damage tilt, FOV effects, distortion; restores originals on disable) | unverified in-game |
| GUI | Click GUI: categories, search, enabled-only filter, favorites, recents, expandable settings (toggle/slider/mode/color picker/keybind), tooltips, keyboard navigation, drag + resize, GUI scale/opacity, reduced motion, first-launch card with presets, Profiles page | unverified in-game |
| HUD editor | Drag, wheel-scale, right-click reset, arrow nudge, grid snap, alignment guides, undo/redo, component palette, sample previews | unverified in-game |

### Not in milestone 1 (honest list)

Custom sky renderer, skybox/panorama import, themes beyond accent color, custom crosshair, main-menu backgrounds, custom hit
indicators and sounds, in-world crystal/damage rendering (ESP), named HUD layouts separate from profiles (layouts are saved
per profile), font choice, chat customization, replay tools, per-module performance profiling. The sky renderer in particular
needs the 1.21.11 render pipeline and should be built and tested in a running client rather than written blind.

## CPvP compatibility and rules

Vesper is **information only** for combat. It never places crystals, attacks, or breaks anything, and sends no extra packets.
It reads client-side state and draws on your own screen. Even so, *some servers ban any client mods or HUD overlays*: check your
server's rules before joining with it. Disable modules your server forbids.

Known limits of the damage estimate: it uses your client's copy of the world (unloaded chunks count as air); exposure is sampled
the way vanilla does but not proven bit-identical; modded/server-plugin damage changes are unknown; a fully blocked explosion
(0% exposure) is assumed to deal 0 damage; this edge case was not verified against the game. Totem pops are **inferred**, so
rare false alarms are possible. The Combat Timer approximates server combat tags and is not server-authoritative.

## Controls

* **Right Shift** opens the menu (changeable under *Interface > Keybind*, saved per profile).
* Click a module to toggle, right-click for settings, star to favorite, hover for help. Right-click a setting to reset it.
* Up/Down/Enter/Left/Right/Tab navigate the list; type to search; Esc closes.
* **HUD Editor** button: drag to move, wheel to scale, right-click to reset, arrows nudge (Shift = 8px), Ctrl+Z / Ctrl+Y, G grid.

## Files

`.minecraft/config/vesper/` contains `state.json`, `profiles/<name>.json`, and `exports/`. To share a profile use *Profiles >
Export active*, send the file, and have the recipient drop it in their `exports/` folder and click it under *Import*. Edit JSON by
hand if you like: invalid values fall back to defaults with a message that names the setting. A damaged file is kept as
`<name>.json.corrupt-<time>` and defaults are loaded. Schema changes go through `config/Migrations.java`.

## Layout

```
dev.vesper.core      Module, Category, settings (no Minecraft types, unit-tested)
dev.vesper.config    ConfigManager, Migrations (unit-tested)
dev.vesper.calc      ExplosionMath (pure, unit-tested)
dev.vesper.mc        Minecraft-touching helpers: Keys, McUtil, Exposure
dev.vesper.hud       HudModule base classes, HudManager, Notifications
dev.vesper.modules   Feature modules (add one: extend a base class, register in VesperClient)
dev.vesper.gui       ClickGui, HudEditorScreen, Theme, Draw
```

Adding a feature = one class + one `modules.register(...)` line. Settings, persistence, search, keybind and GUI come free.

## Performance notes

HUD modules recompute on an adjustable tick interval and cache their text; frames only draw. Crystal Damage ray-casts about 45
times per crystal and player per update, limited to the 6 nearest crystals, so raise its *Update interval* if you see cost.
Config writes happen off the game thread. State is reset on world/dimension change.

## License

MIT.
