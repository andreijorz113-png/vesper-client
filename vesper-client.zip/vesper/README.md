# Vesper Client

A dark-first, CPvP-focused Fabric client mod for **Minecraft 1.21.11** (Java 21). Original name and design; inspired by the *category* of
clients like Dawn, with no code, branding or assets copied.

> **Status: milestone 2. Milestone 1 compiled and launched; milestone 2 has not been built or run yet.** The framework-free parts are tested (see below).
> The Minecraft-facing code (GUI, HUD, modules) has never been built or run in-game. Expect to fix a few compile errors on
> first build; see "If the build fails". Do not treat anything in the "unverified" column as working until you have run it.

## Get the .jar (no local setup)

1. Create an empty GitHub repository and push this folder to it (`git init && git add . && git commit -m init && git push`).
2. Open the **Actions** tab. The `build` workflow runs automatically (about 3-5 minutes the first time).
3. Open the finished run and download the **vesper-client** artifact. It contains `vesper-client-0.1.0.jar`.
4. Install Fabric Loader (0.18.1+) and **Fabric API** for 1.21.11, then put the jar in `.minecraft/mods`.

Local build instead: install JDK 21 and Gradle 9.x, run `gradle wrapper --gradle-version 9.2.0` once, then `./gradlew build`
(jar in `build/libs/`) and `./gradlew coreTests`. `./gradlew runClient` starts a dev client.

## If the build fails

The workflow uploads whatever it built and always runs tests, so open the failed step and send the error text back; each
fix is usually one line. Version pins live in `gradle.properties` (`fabric_version`, `loader_version`, `loom_version`); if Gradle
says one does not exist, take the newest 1.21.11 entry from <https://fabricmc.net/develop/>.

Minecraft API calls most likely to need adjusting (all names are Mojang official mappings, 1.21.11):

| File | What |
|---|---|
| `mc/Keys.java` | window handle (`getWindow().handle()`), `InputConstants` key names |
| `gui/ClickGui.java`, `gui/HudEditorScreen.java` | `Screen` input signatures (`MouseButtonEvent`, `KeyEvent`, `CharacterEvent`), `KeyEvent.modifiers()` |
| `hud/HudModule.java`, `gui/Draw.java` | `GuiGraphics` calls: `pose().pushMatrix()/translate/scale`, `fill`, `drawString`, scissor, `renderItem` |
| `VesperClient.java` | `HudRenderCallback` (deprecated in newer Fabric API; swap for `HudElementRegistry`) |
| `mc/McUtil.java` | enchantment holders (`Holder.is(Enchantments.X)`), `getArmorValue`, attribute lookup |
| `mc/Exposure.java` | `ClipContext` constructor |
| `modules/CleanVisuals.java` | option accessors (`damageTiltStrength`, `fovEffectScale`, `screenEffectScale`) |

## What is in milestone 1

| Area | Feature | Status |
|---|---|---|
| Core | Module framework (lifecycle, settings, keybinds, error isolation: a module failing 3x in a row is disabled) | lifecycle + settings **tested**; Minecraft glue unverified |
| Config | Versioned JSON profiles, migrations, corrupt-file recovery (backup + defaults), validation with fix-it messages, debounced async atomic saves, import/export (data only, never executed) | **tested** (30 checks) |
| Combat math | Crystal damage: exposure-independent math for difficulty, armor/toughness, Resistance, Protection/Blast Protection (EPF cap 20), absorption | **tested** against hand-derived values (14 checks); **not validated against the real game** |
| Combat info | Crystal Damage HUD (self + target, placement preview, lethal notice), Target Info, Combat Alerts (inferred totem pops, low totems/armor), Combat Timer, Item Counters | unverified in-game |
| QoL | Armor Status, Info (FPS/ping/server), Coordinates, CPS, Potion Timers, Module List, Notifications | unverified in-game |
| Visual | Clean Visuals (particles, damage tilt, FOV effects, distortion; restores originals on disable) | unverified in-game |
| GUI | Click GUI: categories, search, enabled-only filter, favorites, recents, expandable settings (toggle/slider/mode/color picker/keybind), tooltips, keyboard navigation, drag + resize, GUI scale/opacity, reduced motion, first-launch card with presets, Profiles page | unverified in-game |
| HUD editor | Drag, wheel-scale, right-click reset, arrow nudge, grid snap, alignment guides, undo/redo, component palette, sample previews | unverified in-game |

## Milestone 2 additions (written, compiled only if your build is green, **not yet run in-game**)

| Feature | Where | Notes |
|---|---|---|
| Vesper main menu | Visual > Main Menu | Replaces the title screen: left navigation, logo, status line. Backgrounds: Minecraft panorama, your own image (PNG/JPG/GIF/BMP in `config/vesper/backgrounds/`), gradient, solid. Tint, darkening, opacity, drift, animation and logo-twinkle settings, **Preview** button. Disable the module to get the vanilla title screen back. |
| Logo | main menu + click GUI | Drawn in code (diamond crystal, V, evening star, VESPER lettering), so it is sharp at every GUI scale. SVG/PNG versions are separate files. |
| Theme engine | Client > Theme | 7 presets (Obsidian, Eclipse, Midnight, Violet, Frost, Ember, Monochrome), per-color editing (switches to Custom), glow, Save/Load/Delete/Export/Import named themes, Revert. Live preview: everything recolors instantly. The sky is unaffected. |
| Totem Pop visual | Visual > Totem Pop | Small fading text with an optional 9px totem icon, own/other colors, duration, optional sound, draggable in the HUD editor. Pops are **inferred**, not read from the network. |
| Custom crosshair | Visual > Custom Crosshair | Cross, Dot, Circle, Square, Cross + Dot; size, gap, thickness, color, outline. Replaces the vanilla crosshair (and its attack indicator) while enabled. |
| Hit indicator | Visual > Hit Indicator | Hit marker and damage number when the target under your crosshair loses health. |
| Particle control | Visual > Particle Control | Percent kept per category (general, explosion, ambient, crit, combat). Presets Vanilla/Reduced/Minimal/Custom. Implemented with a mixin on `ParticleEngine.createParticle`, so dropped particles cost nothing. If the mixin ever fails to apply, the filter silently does nothing (it will not crash the game). |
| Discord Rich Presence | Integrations > Discord | Real Discord IPC (named pipe / unix socket, no library). Needs a free Application ID (see below). Server IP hidden by default. |
| Spotify now playing | Integrations > Spotify | Real Spotify Web API with PKCE sign-in (no client secret). Real data only; the HUD editor shows clearly labelled sample text. |
| Text fields and buttons in the GUI | any module | New setting types used by the above. |

### Discord setup (2 minutes)
1. Go to <https://discord.com/developers/applications>, **New Application**, name it (the name is what friends see: "Playing <name>").
2. Copy the **Application ID** into *Integrations > Discord Rich Presence > Application ID* and enable the module. Discord must be running.
3. Optional: upload an image under *Rich Presence > Art Assets*, then put its key in *Large image key*.
Updates are limited by Discord to one per 15 seconds.

### Spotify setup (3 minutes)
1. Go to <https://developer.spotify.com/dashboard>, **Create app**. Add the redirect URI exactly: `http://127.0.0.1:8888/callback`.
2. Copy the **Client ID** into *Integrations > Spotify > Client ID*, enable the module, press **Connect**, approve in the browser.
3. Your login is stored only in `config/vesper/spotify.json` on your computer, never in profiles or exports. **Disconnect** deletes it.
Spotify apps in development mode only work for accounts you add under the app's *User Management*, so add yourself.

### Verification status
Tested here with real runs: damage math, settings, config/profiles/migrations, theme store (validation, import/export), particle
classification, Spotify PKCE (official RFC 7636 test vector) and response parsing, and the **Discord IPC handshake and
SET_ACTIVITY frames against a fake Discord server on a socket**. Not testable here: anything that renders or calls Minecraft.

### Not built yet (honest list)
* **Custom sky** (skybox, panorama, gradient): needs hooks into the 1.21.11 sky renderer. A color overlay would not be a real
  sky, so nothing was shipped rather than a fake.
* **Custom enchantment glint**: needs a real shader/render-type hook. A static tint would not be a custom glint.
* Name-tag styling, entity highlights, custom HUD fonts, blur on the main menu, custom panoramic/cube-map main menu backgrounds,
  named HUD layouts separate from profiles, camera-effect reduction beyond Clean Visuals, in-world crystal/damage rendering.

## CPvP compatibility and rules

Vesper is **information only** for combat. It never places crystals, attacks, or breaks anything, and sends no extra packets.
It reads client-side state and draws on your own screen. Even so, *some servers ban any client mods or HUD overlays*: check your
server's rules before joining with it. Disable modules your server forbids.

Known limits of the damage estimate: it uses your client's copy of the world (unloaded chunks count as air); exposure is sampled
the way vanilla does but not proven bit-identical; modded/server-plugin damage changes are unknown; a fully blocked explosion
(0% exposure) is assumed to deal 0 damage; this edge case was not verified against the game. Totem pops are **inferred**, so
rare false alarms are possible. The Combat Timer approximates server combat tags and is not server-authoritative.

## Controls

* **Right Shift** opens the menu (changeable under *Interface > Keybind*, saved per profile).
* Click a module to toggle, right-click for settings, star to favorite, hover for help. Right-click a setting to reset it.
* Up/Down/Enter/Left/Right/Tab navigate the list; type to search; Esc closes.
* **HUD Editor** button: drag to move, wheel to scale, right-click to reset, arrows nudge (Shift = 8px), Ctrl+Z / Ctrl+Y, G grid.

## Files

`.minecraft/config/vesper/` contains `state.json`, `profiles/<name>.json`, and `exports/`. To share a profile use *Profiles >
Export active*, send the file, and have the recipient drop it in their `exports/` folder and click it under *Import*. Edit JSON by
hand if you like: invalid values fall back to defaults with a message that names the setting. A damaged file is kept as
`<name>.json.corrupt-<time>` and defaults are loaded. Schema changes go through `config/Migrations.java`.

## Layout

```
dev.vesper.core      Module, Category, settings (no Minecraft types, unit-tested)
dev.vesper.config    ConfigManager, Migrations (unit-tested)
dev.vesper.calc      ExplosionMath (pure, unit-tested)
dev.vesper.mc        Minecraft-touching helpers: Keys, McUtil, Exposure
dev.vesper.hud       HudModule base classes, HudManager, Notifications
dev.vesper.modules   Feature modules (add one: extend a base class, register in VesperClient)
dev.vesper.gui       ClickGui, HudEditorScreen, Theme, Draw
```

Adding a feature = one class + one `modules.register(...)` line. Settings, persistence, search, keybind and GUI come free.

## Performance notes

HUD modules recompute on an adjustable tick interval and cache their text; frames only draw. Crystal Damage ray-casts about 45
times per crystal and player per update, limited to the 6 nearest crystals, so raise its *Update interval* if you see cost.
Config writes happen off the game thread. State is reset on world/dimension change.

## License

MIT.
