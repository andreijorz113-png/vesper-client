package dev.vesper;

import dev.vesper.config.ConfigManager;
import dev.vesper.core.setting.Setting;
import dev.vesper.hud.HudManager;
import dev.vesper.hud.Notifications;
import dev.vesper.modules.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class VesperClient implements ClientModInitializer {
    public static final String ID = "vesper";
    public static final Logger LOG = LoggerFactory.getLogger("Vesper");

    private static ModuleManager modules;
    private static ConfigManager config;
    private static ClientSettings settings;

    public static ModuleManager modules() { return modules; }
    public static ConfigManager config() { return config; }
    public static ClientSettings settings() { return settings; }

    @Override public void onInitializeClient() {
        modules = new ModuleManager();
        settings = new ClientSettings();
        modules.register(settings);
        // Combat
        modules.register(new CrystalDamage());
        modules.register(new TargetInfo());
        modules.register(new CombatAlerts());
        modules.register(new CombatTimer());
        modules.register(new ItemCounters());
        // QoL
        modules.register(new ArmorStatus());
        modules.register(new InfoHud());
        modules.register(new Coordinates());
        modules.register(new CpsHud());
        modules.register(new PotionTimers());
        modules.register(new ModuleListHud());
        modules.register(new NotificationsHud());
        // Visual
        modules.register(new CleanVisuals());

        config = new ConfigManager(FabricLoader.getInstance().getConfigDir().resolve("vesper"), modules);
        boolean first = config.load();
        Setting.setChangeHook(config::markDirty);

        ClientTickEvents.END_CLIENT_TICK.register(modules::tick);
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> config.flushNow());
        HudRenderCallback.EVENT.register((graphics, tickCounter) -> HudManager.renderAll(graphics));

        // Do NOT call Keys.name() here: it uses GLFW, which is not initialised yet while mods load (that crashed the game).
        if (first) Notifications.push("Vesper installed. Press Right Shift to open the menu.", Notifications.INFO);
        LOG.info("Vesper loaded: {} modules, profile '{}'", modules.all().size(), config.active());
    }
}
