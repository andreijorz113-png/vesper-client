package dev.vesper.config;

import com.google.gson.*;
import dev.vesper.core.Module;
import dev.vesper.core.ModuleRegistry;
import dev.vesper.core.setting.Setting;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * Versioned JSON profiles. Layout under <dir>:
 *   state.json            {schemaVersion, activeProfile, welcomeDone}
 *   profiles/<name>.json  one profile (module states, settings, keybinds, HUD layout, favorites)
 *   exports/              target for export and source for import
 * Imported files are only ever parsed as data, never executed.
 * Saving is debounced: call markDirty(); tick() serialises on the caller's thread after the debounce
 * and hands the file write to a background thread.
 */
public final class ConfigManager {
    private static final Logger LOG = LoggerFactory.getLogger("Vesper/Config");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Pattern NAME = Pattern.compile("[A-Za-z0-9 _-]{1,32}");
    private static final long DEBOUNCE_MS = 750;

    private final Path root, profilesDir, exportsDir;
    private final ModuleRegistry registry;
    private final ExecutorService io = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "Vesper-ConfigIO"); t.setDaemon(true); return t; });

    private String active = "Default";
    private boolean welcomeDone;
    private boolean loading;
    private volatile boolean dirty;
    private volatile long lastChange;
    private final List<String> errors = new ArrayList<>();

    public ConfigManager(Path root, ModuleRegistry registry) {
        this.root = root; this.registry = registry;
        this.profilesDir = root.resolve("profiles"); this.exportsDir = root.resolve("exports");
    }

    // ------------------------------------------------------------------ loading
    /** Loads state + active profile. Returns true on the very first launch (no state file). */
    public boolean load() {
        try { Files.createDirectories(profilesDir); Files.createDirectories(exportsDir); }
        catch (IOException e) { error("Could not create " + root + ": " + e.getMessage() + ". Check folder permissions; settings will not be saved."); }

        boolean first = !Files.exists(root.resolve("state.json"));
        JsonObject st = readObject(root.resolve("state.json"), "state.json");
        if (st != null) {
            try {
                st = Migrations.migrate(st, Migrations.CURRENT);
                if (st.has("activeProfile") && validName(st.get("activeProfile").getAsString())) active = st.get("activeProfile").getAsString();
                welcomeDone = st.has("welcomeDone") && st.get("welcomeDone").getAsBoolean();
            } catch (RuntimeException e) { error("state.json: " + e.getMessage()); }
        }
        loadProfile(active);
        return first;
    }

    private void loadProfile(String name) {
        loading = true;
        try {
            for (Module m : registry.all()) m.resetToDefaults();
            registry.favorites().clear(); registry.recent().clear();
            Path p = profilePath(name);
            if (!Files.exists(p)) { dirty = true; lastChange = System.currentTimeMillis(); return; }
            JsonObject o = readObject(p, "profile '" + name + "'");
            if (o == null) return;
            try { o = Migrations.migrate(o, Migrations.CURRENT); }
            catch (RuntimeException e) {
                error("Profile '" + name + "' " + e.getMessage() + " Defaults were loaded and the file was left untouched.");
                return;
            }
            apply(o, name);
        } finally { loading = false; }
    }

    private void apply(JsonObject o, String name) {
        JsonObject mods = o.has("modules") && o.get("modules").isJsonObject() ? o.getAsJsonObject("modules") : new JsonObject();
        for (Module m : registry.all()) {
            if (!mods.has(m.id) || !mods.get(m.id).isJsonObject()) continue;
            JsonObject mo = mods.getAsJsonObject(m.id);
            try {
                if (mo.has("key") && mo.get("key").isJsonPrimitive()) m.setKey(mo.get("key").getAsInt());
                if (mo.has("settings") && mo.get("settings").isJsonObject()) {
                    JsonObject so = mo.getAsJsonObject("settings");
                    for (Setting<?> s : m.settings()) {
                        if (!so.has(s.id)) continue;
                        try { s.fromJson(so.get(s.id)); }
                        catch (RuntimeException e) {
                            error(m.name + " > " + s.name + " in profile '" + name + "' is invalid (" + e.getMessage() + "). Reset to default; open the setting to change it.");
                        }
                    }
                }
                m.extraFromJson(mo);
                if (mo.has("enabled") && mo.get("enabled").isJsonPrimitive()) m.setEnabled(mo.get("enabled").getAsBoolean());
            } catch (RuntimeException e) {
                error("Module " + m.name + " could not be loaded from profile '" + name + "': " + e.getMessage());
            }
        }
        readIds(o, "favorites", registry.favorites());
        readIds(o, "recent", registry.recent());
    }

    private void readIds(JsonObject o, String key, List<String> out) {
        if (!o.has(key) || !o.get(key).isJsonArray()) return;
        Set<String> known = new HashSet<>();
        for (Module m : registry.all()) known.add(m.id);
        for (JsonElement e : o.getAsJsonArray(key))
            if (e.isJsonPrimitive() && known.contains(e.getAsString()) && !out.contains(e.getAsString())) out.add(e.getAsString());
    }

    private JsonObject readObject(Path p, String label) {
        if (!Files.exists(p)) return null;
        try {
            JsonElement e = JsonParser.parseString(Files.readString(p, StandardCharsets.UTF_8));
            if (!e.isJsonObject()) throw new JsonParseException("top level is not an object");
            return e.getAsJsonObject();
        } catch (IOException | RuntimeException ex) {
            Path bak = p.resolveSibling(p.getFileName() + ".corrupt-" + System.currentTimeMillis());
            try { Files.move(p, bak); } catch (IOException ignored) { bak = p; }
            error("Could not read " + label + " (" + ex.getMessage() + "). Defaults were loaded; the damaged file was kept as " + bak.getFileName() + ".");
            return null;
        }
    }

    // ------------------------------------------------------------------ saving
    public void markDirty() {
        if (loading) return;
        lastChange = System.currentTimeMillis();
        dirty = true;
    }

    /** Call every client tick. */
    public void tick() {
        if (dirty && System.currentTimeMillis() - lastChange >= DEBOUNCE_MS) saveAsync();
    }

    private void saveAsync() {
        dirty = false;
        final String profileJson = GSON.toJson(snapshot(active)), stateJson = GSON.toJson(state());
        final Path p = profilePath(active), s = root.resolve("state.json");
        io.submit(() -> { writeAtomic(p, profileJson); writeAtomic(s, stateJson); });
    }

    /** Synchronous save for shutdown or tests. */
    public void flushNow() {
        dirty = false;
        writeAtomic(profilePath(active), GSON.toJson(snapshot(active)));
        writeAtomic(root.resolve("state.json"), GSON.toJson(state()));
    }

    private JsonObject state() {
        JsonObject o = new JsonObject();
        o.addProperty("schemaVersion", Migrations.CURRENT);
        o.addProperty("activeProfile", active);
        o.addProperty("welcomeDone", welcomeDone);
        return o;
    }

    private JsonObject snapshot(String name) {
        JsonObject o = new JsonObject();
        o.addProperty("schemaVersion", Migrations.CURRENT);
        o.addProperty("name", name);
        JsonObject mods = new JsonObject();
        for (Module m : registry.all()) {
            JsonObject mo = new JsonObject();
            mo.addProperty("enabled", m.enabled());
            mo.addProperty("key", m.key());
            JsonObject so = new JsonObject();
            for (Setting<?> s : m.settings()) if (s.persistent()) so.add(s.id, s.toJson());
            mo.add("settings", so);
            m.extraToJson(mo);
            mods.add(m.id, mo);
        }
        o.add("modules", mods);
        JsonArray fav = new JsonArray(), rec = new JsonArray();
        registry.favorites().forEach(fav::add); registry.recent().forEach(rec::add);
        o.add("favorites", fav); o.add("recent", rec);
        return o;
    }

    private void writeAtomic(Path target, String content) {
        try {
            Files.createDirectories(target.getParent());
            Path tmp = target.resolveSibling(target.getFileName() + ".tmp");
            Files.writeString(tmp, content, StandardCharsets.UTF_8);
            try { Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException e) { Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException e) {
            LOG.error("Failed to write {}: {}", target, e.getMessage());
            synchronized (errors) { errors.add("Could not save " + target.getFileName() + ": " + e.getMessage() + ". Check disk space and permissions."); }
        }
    }

    // ------------------------------------------------------------------ profiles
    public String active() { return active; }
    public Path root() { return root; }
    public Path exportsDir() { return exportsDir; }
    public boolean welcomeDone() { return welcomeDone; }
    public void setWelcomeDone() { welcomeDone = true; dirty = true; lastChange = System.currentTimeMillis(); }

    public List<String> profiles() {
        List<String> out = new ArrayList<>();
        try (Stream<Path> s = Files.list(profilesDir)) {
            s.map(p -> p.getFileName().toString()).filter(n -> n.endsWith(".json"))
             .map(n -> n.substring(0, n.length() - 5)).filter(ConfigManager::validName).sorted().forEach(out::add);
        } catch (IOException ignored) {}
        if (!out.contains(active)) out.add(active);
        Collections.sort(out);
        return out;
    }

    public static boolean validName(String n) { return n != null && NAME.matcher(n).matches(); }
    private Path profilePath(String name) { return profilesDir.resolve(name + ".json"); }

    public void switchTo(String name) {
        if (!validName(name) || name.equals(active)) return;
        flushNow();
        active = name;
        loadProfile(name);
        flushNow();
    }

    /** Creates a new profile as a copy of the current settings and switches to it. */
    public String createFromCurrent() {
        flushNow();
        int i = 2; String n;
        do { n = "Profile " + i++; } while (Files.exists(profilePath(n)));
        writeAtomic(profilePath(n), GSON.toJson(snapshot(n)));
        active = n; flushNow();
        return n;
    }

    public boolean delete(String name) {
        if (name.equals(active) || !validName(name)) return false;
        try { return Files.deleteIfExists(profilePath(name)); } catch (IOException e) { error("Could not delete " + name + ": " + e.getMessage()); return false; }
    }

    public void resetActive() {
        loading = true;
        try { for (Module m : registry.all()) m.resetToDefaults(); registry.favorites().clear(); registry.recent().clear(); }
        finally { loading = false; }
        markDirty();
    }

    public Path exportActive() {
        flushNow();
        Path out = exportsDir.resolve(active + ".json");
        writeAtomic(out, GSON.toJson(snapshot(active)));
        return out;
    }

    public List<String> listImports() {
        List<String> out = new ArrayList<>();
        try (Stream<Path> s = Files.list(exportsDir)) {
            s.map(p -> p.getFileName().toString()).filter(n -> n.endsWith(".json")).sorted().forEach(out::add);
        } catch (IOException ignored) {}
        return out;
    }

    /** Imports exports/<fileName>, validating it as data. Returns the new profile name or null on failure. */
    public String importFile(String fileName) {
        if (fileName.contains("/") || fileName.contains("\\") || fileName.contains("..")) { error("Invalid file name."); return null; }
        Path p = exportsDir.resolve(fileName);
        JsonObject o;
        try {
            JsonElement e = JsonParser.parseString(Files.readString(p, StandardCharsets.UTF_8));
            if (!e.isJsonObject()) throw new JsonParseException("top level is not an object");
            o = Migrations.migrate(e.getAsJsonObject(), Migrations.CURRENT);
        } catch (IOException | RuntimeException ex) {
            error("Import of " + fileName + " failed: " + ex.getMessage() + ". Export a fresh copy from Vesper or fix the JSON.");
            return null;
        }
        String base = o.has("name") && o.get("name").isJsonPrimitive() ? o.get("name").getAsString() : fileName.replace(".json", "");
        if (!validName(base)) base = base.replaceAll("[^A-Za-z0-9 _-]", "").trim();
        if (base.isEmpty()) base = "Imported";
        if (base.length() > 28) base = base.substring(0, 28);
        String n = base; int i = 2;
        while (Files.exists(profilePath(n))) n = base + " " + i++;
        o.addProperty("name", n);
        writeAtomic(profilePath(n), GSON.toJson(o));
        switchTo(n);
        return n;
    }

    // ------------------------------------------------------------------ errors
    private void error(String msg) { LOG.warn(msg); synchronized (errors) { errors.add(msg); } }
    /** Returns and clears pending messages meant for the user. */
    public List<String> drainErrors() { synchronized (errors) { List<String> c = new ArrayList<>(errors); errors.clear(); return c; } }
}
