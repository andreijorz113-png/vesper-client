package dev.vesper.config;

import com.google.gson.JsonObject;
import java.util.Map;
import java.util.function.UnaryOperator;

/**
 * Schema migrations. To change the format: bump CURRENT and register a step keyed by the
 * version it upgrades FROM, e.g. STEPS.put(1, o -> { ...rename keys...; return o; }).
 */
public final class Migrations {
    private Migrations() {}

    public static final int CURRENT = 1;
    private static final Map<Integer, UnaryOperator<JsonObject>> STEPS = new java.util.HashMap<>();

    /** Test hook. */
    public static Map<Integer, UnaryOperator<JsonObject>> steps() { return STEPS; }

    /** Returns the migrated object (with schemaVersion = target). Throws if the file is from a newer client. */
    public static JsonObject migrate(JsonObject o, int target) {
        int v = o.has("schemaVersion") && o.get("schemaVersion").isJsonPrimitive() ? o.get("schemaVersion").getAsInt() : 1;
        if (v > target) throw new IllegalArgumentException(
            "was saved by a newer Vesper (schema " + v + ", this build supports " + target + "). Update the client.");
        while (v < target) {
            UnaryOperator<JsonObject> step = STEPS.get(v);
            if (step == null) throw new IllegalArgumentException("no migration from schema " + v);
            o = step.apply(o);
            v++;
            o.addProperty("schemaVersion", v);
        }
        o.addProperty("schemaVersion", target);
        return o;
    }
}
