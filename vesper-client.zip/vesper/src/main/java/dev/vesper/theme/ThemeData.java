package dev.vesper.theme;

import com.google.gson.JsonObject;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** A complete interface palette (ARGB ints). glow is 0..1. */
public record ThemeData(String name, int bg, int panel, int hover, int border, int text, int dim, int accent, float glow) {

    private static ThemeData t(String n, String bg, String panel, String hover, String border, String text, String dim, String accent, float glow) {
        return new ThemeData(n, c(bg), c(panel), c(hover), c(border), c(text), c(dim), c(accent), glow);
    }
    private static int c(String hex) { return 0xFF000000 | Integer.parseInt(hex, 16); }

    private static final Map<String, ThemeData> PRESETS = new LinkedHashMap<>();
    static {
        for (ThemeData d : List.of(
            t("Obsidian",   "121218", "1B1B24", "252532", "2C2C3A", "ECECF4", "8C8CA0", "8B7CFF", 0.25f),
            t("Eclipse",    "0B0A10", "15131C", "1F1C29", "2A2636", "F2EEF8", "8F889F", "FF9F43", 0.35f),
            t("Midnight",   "0A0F1E", "111828", "1A2438", "24304A", "E6EEFF", "7F8FB0", "4C8DFF", 0.25f),
            t("Violet",     "130F1F", "1C1630", "281F44", "3A2C5C", "F0E9FF", "9A8CC0", "B28CFF", 0.40f),
            t("Frost",      "0E1519", "152027", "1E2D36", "2A3F4B", "EAF6FA", "87A5B3", "5FD7F0", 0.20f),
            t("Ember",      "140E0C", "1F1613", "2C1F1A", "40302A", "FBEFE8", "B09388", "FF6A3D", 0.35f),
            t("Monochrome", "101010", "1A1A1A", "262626", "333333", "F2F2F2", "8A8A8A", "E6E6E6", 0.10f))) PRESETS.put(d.name(), d);
    }

    public static List<String> presetNames() { return List.copyOf(PRESETS.keySet()); }
    public static ThemeData preset(String name) { return PRESETS.get(name); }
    public static ThemeData defaultTheme() { return PRESETS.get("Obsidian"); }

    public ThemeData named(String n) { return new ThemeData(n, bg, panel, hover, border, text, dim, accent, glow); }

    /** Same colors ignoring the name. */
    public boolean samePalette(ThemeData o) {
        return bg == o.bg && panel == o.panel && hover == o.hover && border == o.border && text == o.text && dim == o.dim
            && accent == o.accent && Math.abs(glow - o.glow) < 0.005f;
    }

    private static String hex(int argb) { return String.format("#%06X", argb & 0xFFFFFF); }

    public JsonObject toJson() {
        JsonObject o = new JsonObject();
        o.addProperty("schemaVersion", 1);
        o.addProperty("name", name);
        o.addProperty("bg", hex(bg)); o.addProperty("panel", hex(panel)); o.addProperty("hover", hex(hover));
        o.addProperty("border", hex(border)); o.addProperty("text", hex(text)); o.addProperty("dim", hex(dim));
        o.addProperty("accent", hex(accent)); o.addProperty("glow", glow);
        return o;
    }

    /** Validates untrusted JSON. Throws IllegalArgumentException with a message that says what to fix. */
    public static ThemeData fromJson(JsonObject o) {
        if (o.has("schemaVersion") && o.get("schemaVersion").isJsonPrimitive() && o.get("schemaVersion").getAsInt() > 1)
            throw new IllegalArgumentException("theme was made by a newer Vesper");
        String name = o.has("name") && o.get("name").isJsonPrimitive() ? o.get("name").getAsString() : "Imported";
        return new ThemeData(name, col(o, "bg"), col(o, "panel"), col(o, "hover"), col(o, "border"), col(o, "text"), col(o, "dim"), col(o, "accent"),
            glow(o));
    }

    private static int col(JsonObject o, String k) {
        if (!o.has(k) || !o.get(k).isJsonPrimitive() || !o.get(k).getAsJsonPrimitive().isString())
            throw new IllegalArgumentException("missing color '" + k + "' (use #RRGGBB)");
        String s = o.get(k).getAsString().trim();
        if (s.startsWith("#")) s = s.substring(1);
        if (s.length() != 6) throw new IllegalArgumentException("color '" + k + "' must look like #RRGGBB");
        try { return c(s); } catch (NumberFormatException e) { throw new IllegalArgumentException("color '" + k + "' is not valid hex"); }
    }
    private static float glow(JsonObject o) {
        if (!o.has("glow")) return 0.25f;
        try { float g = o.get("glow").getAsFloat(); if (g < 0 || g > 1) throw new IllegalArgumentException("glow must be between 0 and 1"); return g; }
        catch (NumberFormatException | UnsupportedOperationException | IllegalStateException e) { throw new IllegalArgumentException("glow must be a number"); }
    }
}
