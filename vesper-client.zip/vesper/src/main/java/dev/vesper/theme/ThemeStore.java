package dev.vesper.theme;

import com.google.gson.*;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/** User themes as JSON files in <dir>. Imported files are validated as data only. */
public final class ThemeStore {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Pattern NAME = Pattern.compile("[A-Za-z0-9 _-]{1,32}");
    private final Path dir;

    public ThemeStore(Path dir) { this.dir = dir; }
    public static boolean validName(String n) { return n != null && NAME.matcher(n).matches(); }
    private Path file(String name) { return dir.resolve(name + ".json"); }

    public void save(ThemeData d) throws IOException {
        if (!validName(d.name())) throw new IOException("Theme names may use letters, numbers, spaces, - and _ (max 32 characters).");
        Files.createDirectories(dir);
        Files.writeString(file(d.name()), GSON.toJson(d.toJson()), StandardCharsets.UTF_8);
    }

    public ThemeData load(String name) throws IOException {
        if (!validName(name)) throw new IOException("Invalid theme name.");
        if (!Files.exists(file(name))) throw new IOException("No saved theme called '" + name + "'.");
        return parse(Files.readString(file(name), StandardCharsets.UTF_8), name);
    }

    public boolean delete(String name) throws IOException { return validName(name) && Files.deleteIfExists(file(name)); }

    public List<String> list() {
        List<String> out = new ArrayList<>();
        if (!Files.isDirectory(dir)) return out;
        try (Stream<Path> s = Files.list(dir)) {
            s.map(p -> p.getFileName().toString()).filter(n -> n.endsWith(".json")).map(n -> n.substring(0, n.length() - 5))
             .filter(ThemeStore::validName).sorted().forEach(out::add);
        } catch (IOException ignored) {}
        return out;
    }

    /** Copies a saved theme to exportsDir/theme-<name>.json for sharing. */
    public Path export(String name, Path exportsDir) throws IOException {
        ThemeData d = load(name);
        Files.createDirectories(exportsDir);
        Path out = exportsDir.resolve("theme-" + name + ".json");
        Files.writeString(out, GSON.toJson(d.toJson()), StandardCharsets.UTF_8);
        return out;
    }

    /** Imports exportsDir/theme-<name>.json (or any file name given) as a saved theme. Returns the saved name. */
    public String importFile(String fileName, Path exportsDir) throws IOException {
        if (fileName.contains("/") || fileName.contains("\\") || fileName.contains("..")) throw new IOException("Invalid file name.");
        Path p = exportsDir.resolve(fileName.endsWith(".json") ? fileName : fileName + ".json");
        if (!Files.exists(p)) throw new IOException("File not found in the exports folder: " + p.getFileName());
        String base = p.getFileName().toString().replaceFirst("\\.json$", "").replaceFirst("^theme-", "");
        ThemeData d = parse(Files.readString(p, StandardCharsets.UTF_8), base);
        String n = validName(d.name()) ? d.name() : base.replaceAll("[^A-Za-z0-9 _-]", "");
        if (n.isBlank()) n = "Imported";
        if (n.length() > 28) n = n.substring(0, 28);
        String unique = n; int i = 2;
        while (Files.exists(file(unique))) unique = n + " " + i++;
        save(d.named(unique));
        return unique;
    }

    private static ThemeData parse(String json, String fallbackName) throws IOException {
        try {
            JsonElement e = JsonParser.parseString(json);
            if (!e.isJsonObject()) throw new IOException("Theme file is not a JSON object.");
            ThemeData d = ThemeData.fromJson(e.getAsJsonObject());
            return d.name() == null || d.name().isBlank() ? d.named(fallbackName) : d;
        } catch (JsonParseException | IllegalArgumentException ex) {
            throw new IOException("Theme file is invalid: " + ex.getMessage());
        }
    }
}
