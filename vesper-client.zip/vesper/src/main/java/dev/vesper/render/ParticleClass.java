package dev.vesper.render;

import java.util.Set;

/** Groups vanilla particle ids (registry path, e.g. "explosion_emitter") into user-facing categories. */
public enum ParticleClass {
    EXPLOSION, CRIT, COMBAT, AMBIENT, GENERAL;

    private static final Set<String> EXPLOSION_IDS = Set.of("explosion", "explosion_emitter", "poof", "firework", "flash");
    private static final Set<String> CRIT_IDS = Set.of("crit", "enchanted_hit");
    private static final Set<String> COMBAT_IDS = Set.of("damage_indicator", "sweep_attack", "totem_of_undying", "angry_villager", "heart");
    private static final Set<String> AMBIENT_IDS = Set.of("ash", "white_ash", "smoke", "large_smoke", "campfire_cosy_smoke", "campfire_signal_smoke",
        "underwater", "mycelium", "spore_blossom_air", "falling_spore_blossom", "warped_spore", "crimson_spore", "small_gust", "dust_plume",
        "ambient_entity_effect", "entity_effect", "bubble", "bubble_pop", "current_down", "bubble_column_up", "splash", "rain", "dripping_water",
        "dripping_lava", "falling_water", "falling_lava", "drip_obsidian_tear");

    public static ParticleClass of(String path) {
        if (EXPLOSION_IDS.contains(path)) return EXPLOSION;
        if (CRIT_IDS.contains(path)) return CRIT;
        if (COMBAT_IDS.contains(path)) return COMBAT;
        if (AMBIENT_IDS.contains(path)) return AMBIENT;
        return GENERAL;
    }

    /** Whether to drop a particle given the percentage (0..100) of this class that should be kept. */
    public static boolean shouldDrop(int keepPercent, double random01) {
        if (keepPercent >= 100) return false;
        if (keepPercent <= 0) return true;
        return random01 * 100.0 >= keepPercent;
    }
}
