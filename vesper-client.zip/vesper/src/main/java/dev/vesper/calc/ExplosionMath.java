package dev.vesper.calc;

/**
 * Pure-Java implementation of Minecraft (Java Edition) explosion damage reduction.
 * No Minecraft classes are referenced so this can be unit-tested without the game.
 *
 * Order of operations (mirrors vanilla LivingEntity damage handling):
 *   raw explosion damage -> difficulty scaling -> armor/toughness -> Resistance effect
 *   -> enchantment protection (EPF, capped at 20) -> absorption hearts -> health.
 *
 * Exposure (line-of-sight percentage) is computed in-game by dev.vesper.mc.Exposure.
 */
public final class ExplosionMath {
    private ExplosionMath() {}

    public static final float CRYSTAL_POWER = 6.0f;

    public enum Difficulty {
        PEACEFUL, EASY, NORMAL, HARD;

        public static Difficulty parse(String s) {
            try { return valueOf(s.toUpperCase(java.util.Locale.ROOT)); }
            catch (RuntimeException e) { return NORMAL; }
        }
    }

    /** Everything about the victim that reduces damage. resistanceAmplifier is -1 when absent. */
    public record Defense(float armor, float toughness, float enchantProtection,
                          int resistanceAmplifier, float absorption) {
        public static final Defense NONE = new Defense(0, 0, 0, -1, 0);
    }

    /** Raw damage at the explosion, before any reduction. Returns 0 outside the blast radius. */
    public static float rawDamage(double distance, double exposure, float power) {
        float q = power * 2.0f;
        double d = distance / q;
        if (d > 1.0) return 0f;
        double impact = (1.0 - d) * exposure;
        if (impact <= 0.0) return 0f;
        return (float) (int) ((impact * impact + impact) / 2.0 * 7.0 * q + 1.0);
    }

    public static float scaleForDifficulty(float damage, Difficulty difficulty) {
        return switch (difficulty) {
            case PEACEFUL -> 0f;
            case EASY -> Math.min(damage / 2.0f + 1.0f, damage);
            case NORMAL -> damage;
            case HARD -> damage * 1.5f;
        };
    }

    public static float afterArmor(float damage, float armor, float toughness) {
        float f = 2.0f + toughness / 4.0f;
        float g = clamp(armor - damage / f, armor * 0.2f, 20.0f);
        return damage * (1.0f - g / 25.0f);
    }

    public static float afterResistance(float damage, int amplifier) {
        if (amplifier < 0) return damage;
        int k = 25 - (amplifier + 1) * 5;
        return Math.max(k, 0) / 25.0f * damage;
    }

    public static float afterEnchantments(float damage, float epf) {
        float g = clamp(epf, 0.0f, 20.0f);
        return damage * (1.0f - g / 25.0f);
    }

    public static float finalDamage(float raw, Difficulty difficulty, Defense def) {
        float d = scaleForDifficulty(raw, difficulty);
        d = afterArmor(d, def.armor(), def.toughness());
        d = afterResistance(d, def.resistanceAmplifier());
        d = afterEnchantments(d, def.enchantProtection());
        return Math.max(d, 0f);
    }

    /** Health (including absorption) left after taking damage. Can be negative. */
    public static float healthAfter(float health, float damage, Defense def) {
        return health + def.absorption() - damage;
    }

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : Math.min(v, hi);
    }
}
