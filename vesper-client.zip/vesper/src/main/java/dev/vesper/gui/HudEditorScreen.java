package dev.vesper.gui;

import dev.vesper.VesperClient;
import dev.vesper.hud.HudModule;
import dev.vesper.modules.ClientSettings;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/**
 * Visual HUD editor: drag to move, mouse wheel to scale, right-click to reset an element, arrows to nudge,
 * Ctrl+Z / Ctrl+Y undo/redo, G toggles grid snapping. Elements show sample content so no combat is needed.
 */
public final class HudEditorScreen extends Screen {
    private record Snap(HudModule m, HudModule.Anchor a, float ox, float oy, float scale) {
        static Snap of(HudModule m) { return new Snap(m, m.anchor, m.ox, m.oy, m.scale.f()); }
        void apply() { m.anchor = a; m.ox = ox; m.oy = oy; m.scale.set((double) scale); dev.vesper.core.setting.Setting.changeNotify(); }
    }
    private record Chip(HudModule m, int x, int y, int w, int h) {}

    private final Screen parent;
    private final Deque<Snap> undo = new ArrayDeque<>(), redo = new ArrayDeque<>();
    private final List<Chip> chips = new ArrayList<>();
    private HudModule dragging, active;
    private Snap dragStart;
    private int offX, offY, guideX = -1, guideY = -1;

    public HudEditorScreen(Screen parent) {
        super(Component.literal("HUD Editor"));
        this.parent = parent;
    }

    @Override public boolean isPauseScreen() { return false; }
    @Override public void onClose() { minecraft.setScreen(parent); }

    private ClientSettings cs() { return VesperClient.settings(); }

    private HudModule at(double mx, double my) {
        var list = VesperClient.modules().hudModules();
        for (int i = list.size() - 1; i >= 0; i--) {
            HudModule m = list.get(i);
            if (!m.enabled()) continue;
            int[] b = m.bounds(font, width, height, true);
            if (Draw.in(mx, my, b[0], b[1], b[2], b[3])) return m;
        }
        return null;
    }

    @Override public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        g.fill(0, 0, width, height, 0x66000000);
        int acc = Theme.accent();
        int grid = cs().gridSize.i();
        if (cs().hudSnap.on()) {
            int step = grid < 6 ? grid * 4 : grid;
            for (int x = 0; x < width; x += step) g.fill(x, 0, x + 1, height, 0x10FFFFFF);
            for (int y = 0; y < height; y += step) g.fill(0, y, width, y + 1, 0x10FFFFFF);
        }
        if (guideX >= 0) g.fill(guideX, 0, guideX + 1, height, Draw.alpha(acc, 0.8f));
        if (guideY >= 0) g.fill(0, guideY, width, guideY + 1, Draw.alpha(acc, 0.8f));

        HudModule hover = dragging != null ? dragging : at(mouseX, mouseY);
        for (HudModule m : VesperClient.modules().hudModules()) {
            if (!m.enabled()) continue;
            m.render(g, true);
            int[] b = m.bounds(font, width, height, true);
            Draw.outline(g, b[0] - 1, b[1] - 1, b[2] + 2, b[3] + 2, m == hover ? acc : Draw.alpha(acc, 0.35f));
            if (m == hover) Draw.text(g, m.name + "  (" + String.format("%.2fx", m.scale.f()) + ")", b[0], Math.max(0, b[1] - 10), acc);
        }

        // header hint
        String hint = "Drag: move   Wheel: scale   Right-click: reset element   Arrows: nudge   Ctrl+Z / Ctrl+Y: undo / redo   G: grid snap ("
            + (cs().hudSnap.on() ? "on" : "off") + ")   Esc: back";
        Draw.text(g, hint, (width - Draw.width(hint)) / 2, 6, Theme.DIM);

        // component palette
        chips.clear();
        int x = 10, rowH = 16, total = VesperClient.modules().hudModules().size();
        int rows = 1, cx = x;
        for (HudModule m : VesperClient.modules().hudModules()) {
            int w = Draw.width(m.name) + 12;
            if (cx + w > width - 10) { rows++; cx = x; }
            cx += w + 4;
        }
        int y = height - rows * (rowH + 4) - 4;
        Draw.text(g, "Components (click to show/hide)", 10, y - 11, Theme.DIM);
        cx = x;
        int cy = y;
        for (HudModule m : VesperClient.modules().hudModules()) {
            int w = Draw.width(m.name) + 12;
            if (cx + w > width - 10) { cx = x; cy += rowH + 4; }
            boolean over = Draw.in(mouseX, mouseY, cx, cy, w, rowH);
            Draw.panel(g, cx, cy, w, rowH, m.enabled() ? Draw.alpha(acc, over ? 1f : 0.85f) : (over ? Theme.PANEL_HOVER : Theme.PANEL), Theme.radius());
            Draw.text(g, m.name, cx + 6, cy + 4, m.enabled() ? 0xFF101018 : Theme.TEXT);
            chips.add(new Chip(m, cx, cy, w, rowH));
            cx += w + 4;
        }
    }

    @Override public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        double mx = e.x(), my = e.y();
        for (Chip c : chips) if (Draw.in(mx, my, c.x(), c.y(), c.w(), c.h())) {
            if (e.button() == 0) c.m().setEnabled(!c.m().enabled());
            return true;
        }
        HudModule m = at(mx, my);
        if (m == null) return super.mouseClicked(e, dbl);
        active = m;
        int[] b = m.bounds(font, width, height, true);
        if (e.button() == 1) { push(Snap.of(m)); m.resetLayout(); return true; }
        if (e.button() == 0) { dragging = m; dragStart = Snap.of(m); offX = (int) mx - b[0]; offY = (int) my - b[1]; return true; }
        return false;
    }

    @Override public boolean mouseDragged(MouseButtonEvent e, double dx, double dy) {
        if (dragging == null) return false;
        int[] b = dragging.bounds(font, width, height, true);
        int w = b[2], h = b[3];
        int x = (int) e.x() - offX, y = (int) e.y() - offY;
        if (cs().hudSnap.on()) {
            int gs = cs().gridSize.i();
            x = Math.round(x / (float) gs) * gs; y = Math.round(y / (float) gs) * gs;
        }
        guideX = guideY = -1;
        if (cs().guides.on()) {
            List<Integer> xs = new ArrayList<>(List.of(0, width / 2, width)), ys = new ArrayList<>(List.of(0, height / 2, height));
            for (HudModule o : VesperClient.modules().hudModules()) {
                if (o == dragging || !o.enabled()) continue;
                int[] ob = o.bounds(font, width, height, true);
                xs.add(ob[0]); xs.add(ob[0] + ob[2] / 2); xs.add(ob[0] + ob[2]);
                ys.add(ob[1]); ys.add(ob[1] + ob[3] / 2); ys.add(ob[1] + ob[3]);
            }
            int bestDx = 5, bestDy = 5;
            for (int t : xs) for (int c : new int[]{x, x + w / 2, x + w}) if (Math.abs(c - t) < Math.abs(bestDx)) { bestDx = t - c; guideX = t; }
            for (int t : ys) for (int c : new int[]{y, y + h / 2, y + h}) if (Math.abs(c - t) < Math.abs(bestDy)) { bestDy = t - c; guideY = t; }
            if (Math.abs(bestDx) < 5) x += bestDx; else guideX = -1;
            if (Math.abs(bestDy) < 5) y += bestDy; else guideY = -1;
        }
        x = Math.max(0, Math.min(width - w, x)); y = Math.max(0, Math.min(height - h, y));
        dragging.setFromAbsolute(x, y, w, h, width, height);
        return true;
    }

    @Override public boolean mouseReleased(MouseButtonEvent e) {
        if (dragging != null) {
            Snap now = Snap.of(dragging);
            if (!now.equals(dragStart)) push(dragStart);
            dragging = null; guideX = guideY = -1;
            return true;
        }
        return false;
    }

    @Override public boolean mouseScrolled(double x, double y, double sx, double sy) {
        HudModule m = at(x, y);
        if (m == null) return false;
        push(Snap.of(m));
        m.scale.set(m.scale.get() + Math.signum(sy) * 0.05);
        return true;
    }

    @Override public boolean keyPressed(KeyEvent e) {
        int k = e.key();
        boolean ctrl = (e.modifiers() & GLFW.GLFW_MOD_CONTROL) != 0, shift = (e.modifiers() & GLFW.GLFW_MOD_SHIFT) != 0;
        if (k == GLFW.GLFW_KEY_ESCAPE) { onClose(); return true; }
        if (ctrl && k == GLFW.GLFW_KEY_Z) { step(undo, redo); return true; }
        if (ctrl && k == GLFW.GLFW_KEY_Y) { step(redo, undo); return true; }
        if (k == GLFW.GLFW_KEY_G) { cs().hudSnap.set(!cs().hudSnap.on()); return true; }
        if (active != null && active.enabled() && (k == GLFW.GLFW_KEY_LEFT || k == GLFW.GLFW_KEY_RIGHT || k == GLFW.GLFW_KEY_UP || k == GLFW.GLFW_KEY_DOWN)) {
            int d = shift ? 8 : 1;
            int[] b = active.bounds(font, width, height, true);
            int nx = b[0] + (k == GLFW.GLFW_KEY_LEFT ? -d : k == GLFW.GLFW_KEY_RIGHT ? d : 0);
            int ny = b[1] + (k == GLFW.GLFW_KEY_UP ? -d : k == GLFW.GLFW_KEY_DOWN ? d : 0);
            push(Snap.of(active));
            active.setFromAbsolute(Math.max(0, nx), Math.max(0, ny), b[2], b[3], width, height);
            return true;
        }
        return super.keyPressed(e);
    }

    private void push(Snap s) { undo.push(s); redo.clear(); while (undo.size() > 100) undo.removeLast(); }

    private void step(Deque<Snap> from, Deque<Snap> to) {
        if (from.isEmpty()) return;
        Snap s = from.pop();
        to.push(Snap.of(s.m()));
        s.apply();
    }
}
