package dev.vesper.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.awt.Color;

/** Immediate-mode drawing helpers (rounded panels, text, color math). */
public final class Draw {
    private Draw() {}

    public static void panel(GuiGraphics g, int x, int y, int w, int h, int color, int r) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        if (r == 0) { g.fill(x, y, x + w, y + h, color); return; }
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
            g.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            g.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, color);
        }
        g.fill(x, y + r, x + w, y + h - r, color);
    }

    public static void bordered(GuiGraphics g, int x, int y, int w, int h, int fill, int border, int r) {
        panel(g, x, y, w, h, border, r);
        panel(g, x + 1, y + 1, w - 2, h - 2, fill, Math.max(0, r - 1));
    }

    public static void outline(GuiGraphics g, int x, int y, int w, int h, int c) {
        g.fill(x, y, x + w, y + 1, c); g.fill(x, y + h - 1, x + w, y + h, c);
        g.fill(x, y, x + 1, y + h, c); g.fill(x + w - 1, y, x + w, y + h, c);
    }

    public static void text(GuiGraphics g, String s, int x, int y, int color) {
        g.drawString(Minecraft.getInstance().font, s, x, y, color, false);
    }

    public static int width(String s) { return Minecraft.getInstance().font.width(s); }

    public static String ellipsize(String s, int maxW) {
        var f = Minecraft.getInstance().font;
        if (f.width(s) <= maxW) return s;
        while (s.length() > 1 && f.width(s + "...") > maxW) s = s.substring(0, s.length() - 1);
        return s + "...";
    }

    public static int alpha(int color, float a) {
        int na = Math.max(0, Math.min(255, Math.round(((color >>> 24) & 255) * a)));
        return (na << 24) | (color & 0xFFFFFF);
    }

    public static int withAlpha(int color, int a) { return (a << 24) | (color & 0xFFFFFF); }

    public static float[] hsva(int argb) {
        float[] hsb = Color.RGBtoHSB((argb >> 16) & 255, (argb >> 8) & 255, argb & 255, null);
        return new float[]{hsb[0], hsb[1], hsb[2], ((argb >>> 24) & 255) / 255f};
    }

    public static int fromHsva(float h, float s, float v, float a) {
        return (Math.round(a * 255) << 24) | (Color.HSBtoRGB(h, s, v) & 0xFFFFFF);
    }

    public static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }
}
