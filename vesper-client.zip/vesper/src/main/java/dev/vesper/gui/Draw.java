package dev.vesper.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.awt.Color;

/** Immediate-mode drawing helpers (rounded panels, text, color math). */
public final class Draw {
    private Draw() {}

    public static void panel(GuiGraphics g, int x, int y, int w, int h, int color, int r) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        if (r == 0) { g.fill(x, y, x + w, y + h, color); return; }
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
            g.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            g.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, color);
        }
        g.fill(x, y + r, x + w, y + h - r, color);
    }

    public static void bordered(GuiGraphics g, int x, int y, int w, int h, int fill, int border, int r) {
        panel(g, x, y, w, h, border, r);
        panel(g, x + 1, y + 1, w - 2, h - 2, fill, Math.max(0, r - 1));
    }

    public static void outline(GuiGraphics g, int x, int y, int w, int h, int c) {
        g.fill(x, y, x + w, y + 1, c); g.fill(x, y + h - 1, x + w, y + h, c);
        g.fill(x, y, x + 1, y + h, c); g.fill(x + w - 1, y, x + w, y + h, c);
    }

    public static void text(GuiGraphics g, String s, int x, int y, int color) {
        g.drawString(Minecraft.getInstance().font, s, x, y, color, false);
    }

    public static int width(String s) { return Minecraft.getInstance().font.width(s); }

    public static String ellipsize(String s, int maxW) {
        var f = Minecraft.getInstance().font;
        if (f.width(s) <= maxW) return s;
        while (s.length() > 1 && f.width(s + "...") > maxW) s = s.substring(0, s.length() - 1);
        return s + "...";
    }

    public static int alpha(int color, float a) {
        int na = Math.max(0, Math.min(255, Math.round(((color >>> 24) & 255) * a)));
        return (na << 24) | (color & 0xFFFFFF);
    }

    public static int withAlpha(int color, int a) { return (a << 24) | (color & 0xFFFFFF); }

    public static float[] hsva(int argb) {
        float[] hsb = Color.RGBtoHSB((argb >> 16) & 255, (argb >> 8) & 255, argb & 255, null);
        return new float[]{hsb[0], hsb[1], hsb[2], ((argb >>> 24) & 255) / 255f};
    }

    public static int fromHsva(float h, float s, float v, float a) {
        return (Math.round(a * 255) << 24) | (Color.HSBtoRGB(h, s, v) & 0xFFFFFF);
    }

    public static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    // ------------------------------------------------------------------ vector-style logo drawing
    /** Thick line made of small squares (fine for logo-sized shapes). */
    public static void line(GuiGraphics g, float x1, float y1, float x2, float y2, float thick, int color) {
        float dx = x2 - x1, dy = y2 - y1;
        int n = Math.max(1, (int) Math.ceil(Math.max(Math.abs(dx), Math.abs(dy)) / Math.max(1f, thick * 0.5f)));
        int t = Math.max(1, Math.round(thick));
        for (int i = 0; i <= n; i++) {
            float f = i / (float) n;
            int x = Math.round(x1 + dx * f - t / 2f), y = Math.round(y1 + dy * f - t / 2f);
            g.fill(x, y, x + t, y + t, color);
        }
    }

    /** Soft accent glow around a rectangle (stacked translucent frames). */
    public static void glow(GuiGraphics g, int x, int y, int w, int h, int color, float intensity, int radius) {
        if (intensity <= 0.01f) return;
        for (int i = 1; i <= 6; i++) {
            float a = intensity * 0.10f * (1f - i / 7f);
            int c = alpha(color | 0xFF000000, a);
            outline(g, x - i, y - i, w + 2 * i, h + 2 * i, c);
        }
    }

    /** The Vesper mark: a crystal diamond, a bold V and an evening star. size = overall height in px. */
    public static void logoMark(GuiGraphics g, float cx, float cy, float size, int accent, float twinkle) {
        float r = size / 2f, k = size / 100f;
        int edge = accent | 0xFF000000, soft = alpha(edge, 0.35f);
        float th = Math.max(1.5f, 3.2f * k);
        line(g, cx, cy - r, cx + r * 0.58f, cy, th, edge);
        line(g, cx + r * 0.58f, cy, cx, cy + r, th, edge);
        line(g, cx, cy + r, cx - r * 0.58f, cy, th, edge);
        line(g, cx - r * 0.58f, cy, cx, cy - r, th, edge);
        float ir = r * 0.78f;
        line(g, cx, cy - ir, cx + ir * 0.58f, cy, Math.max(1f, th * 0.45f), soft);
        line(g, cx + ir * 0.58f, cy, cx, cy + ir, Math.max(1f, th * 0.45f), soft);
        line(g, cx, cy + ir, cx - ir * 0.58f, cy, Math.max(1f, th * 0.45f), soft);
        line(g, cx - ir * 0.58f, cy, cx, cy - ir, Math.max(1f, th * 0.45f), soft);
        // V
        float vt = Math.max(2f, 8f * k);
        line(g, cx - 20 * k, cy - 6 * k, cx, cy + 22 * k, vt, 0xFFF4F1FF);
        line(g, cx + 20 * k, cy - 6 * k, cx, cy + 22 * k, vt, 0xFFF4F1FF);
        // evening star
        float sr = 9 * k * (0.9f + 0.2f * twinkle);
        for (int dy = -Math.round(sr); dy <= Math.round(sr); dy++) {
            float f = 1f - Math.abs(dy) / sr;
            int hw = Math.max(0, Math.round(sr * f * f));
            g.fill(Math.round(cx - hw), Math.round(cy - 24 * k + dy), Math.round(cx + hw + 1), Math.round(cy - 24 * k + dy + 1), 0xFFFFFFFF);
        }
        for (int dx = -Math.round(sr); dx <= Math.round(sr); dx++) {
            float f = 1f - Math.abs(dx) / sr;
            int hh = Math.max(0, Math.round(sr * f * f));
            g.fill(Math.round(cx + dx), Math.round(cy - 24 * k - hh), Math.round(cx + dx + 1), Math.round(cy - 24 * k + hh + 1), 0xFFFFFFFF);
        }
    }

    private static final float[][][] LETTERS = {
        /* V */ {{0, 0}, {22, 56}, {44, 0}},
        /* E */ {{44, 0}, {0, 0}, {0, 56}, {44, 56}}, {{0, 28}, {34, 28}},
        /* S */ {{42, 12}, {36, 4}, {22, 0}, {10, 3}, {4, 12}, {8, 22}, {22, 28}, {38, 34}, {42, 44}, {36, 54}, {22, 58}, {8, 55}, {0, 48}},
        /* P */ {{0, 56}, {0, 0}, {26, 0}, {40, 6}, {44, 15}, {40, 24}, {26, 30}, {0, 30}},
        /* R */ {{0, 56}, {0, 0}, {26, 0}, {40, 6}, {44, 15}, {40, 24}, {26, 30}, {0, 30}}, {{24, 30}, {44, 56}},
    };
    // which polylines belong to which glyph of V,E,S,P,E,R (indices into LETTERS)
    private static final int[][] WORD = {{0}, {1, 2}, {3}, {4}, {1, 2}, {5, 6}};

    /** Draws "VESPER" with geometric strokes. height = letter height in px. Returns the drawn width. */
    public static int wordmark(GuiGraphics g, float x, float y, float height, int color) {
        float s = height / 58f, gap = 30 * s, cx = x;
        float th = Math.max(1.5f, 6.5f * s);
        for (int[] glyph : WORD) {
            for (int idx : glyph) {
                float[][] pts = LETTERS[idx];
                for (int i = 0; i + 1 < pts.length; i++)
                    line(g, cx + pts[i][0] * s, y + pts[i][1] * s, cx + pts[i + 1][0] * s, y + pts[i + 1][1] * s, th, color);
            }
            cx += 44 * s + gap;
        }
        return Math.round(cx - gap - x);
    }
}
