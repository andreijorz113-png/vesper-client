package dev.vesper.gui;

import dev.vesper.ModuleManager;
import dev.vesper.VesperClient;
import dev.vesper.config.ConfigManager;
import dev.vesper.core.Category;
import dev.vesper.core.Module;
import dev.vesper.core.setting.*;
import dev.vesper.hud.HudModule;
import dev.vesper.mc.Keys;
import dev.vesper.modules.ClientSettings;
import dev.vesper.modules.ThemeModule;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.*;

/**
 * The main menu. Immediate-mode: every frame rebuilds a list of hit regions that the input handlers use.
 * Pages: All / Favorites / Recent / each category / Profiles. Search filters the module list.
 */
public final class ClickGui extends Screen {
    private interface Click { void on(int button, double mx, double my); }
    private interface Drag { void on(double mx, double my); }
    private record Hit(int x, int y, int w, int h, Click click, Drag drag, String tip) {}

    // window geometry survives re-opening the menu
    private static int wx = Integer.MIN_VALUE, wy, ww = 560, wh = 340;

    private final ClientSettings cs = VesperClient.settings();
    private final ModuleManager mm = VesperClient.modules();
    private final ConfigManager cfg = VesperClient.config();

    private String page = "All", search = "";
    private boolean enabledOnly, welcome;
    private float scroll, targetScroll, maxScroll;
    private final Map<Module, Float> anim = new HashMap<>();
    private final Set<Module> expanded = new HashSet<>();
    private final Set<Setting<?>> colorOpen = new HashSet<>();
    private ColorSetting dragColor;
    private float[] dragHsva;
    private Module listening, selected;
    private StringSetting editing;
    private List<Module> visible = new ArrayList<>();
    private final List<Hit> hits = new ArrayList<>();
    private Drag activeDrag;
    private double dragOffX, dragOffY;
    private String hoverKey = "", hoverTip;
    private long hoverSince, opened = System.currentTimeMillis(), lastFrame = opened, statusUntil, confirmUntil;
    private String status = "", confirmKey = "";
    private int clipTop = 0, clipBottom = 0;

    public ClickGui() {
        super(Component.literal("Vesper"));
        welcome = !cfg.welcomeDone();
        if (mm.get("theme") instanceof ThemeModule tm) tm.takeSnapshot();
    }

    @Override public boolean isPauseScreen() { return false; }
    @Override public void onClose() { minecraft.setScreen(null); }

    // ------------------------------------------------------------------ helpers
    private void hit(int x, int y, int w, int h, Click c, Drag d, String tip) {
        if (clipBottom > clipTop) {   // clamp to the visible part of a scrolling region
            int ny = Math.max(y, clipTop), nb = Math.min(y + h, clipBottom);
            if (nb <= ny) return;
            y = ny; h = nb - ny;
        }
        hits.add(new Hit(x, y, w, h, c, d, tip));
    }

    private void say(String s) { status = s; statusUntil = System.currentTimeMillis() + 4000; }

    private boolean confirm(String key) {
        long now = System.currentTimeMillis();
        if (key.equals(confirmKey) && now < confirmUntil) { confirmKey = ""; return true; }
        confirmKey = key; confirmUntil = now + 3000;
        return false;
    }

    private static String fmt(NumberSetting n) {
        String v = n.step >= 1 ? String.valueOf(n.i()) : n.step >= 0.1 ? String.format(Locale.ROOT, "%.1f", n.get()) : String.format(Locale.ROOT, "%.2f", n.get());
        return v + n.unit;
    }

    private void pill(GuiGraphics g, int x, int y, boolean on, int acc) {
        Draw.panel(g, x, y, 22, 10, on ? acc : Theme.OFF, 5);
        Draw.panel(g, on ? x + 13 : x + 1, y + 1, 8, 8, 0xFFFFFFFF, 4);
    }

    private void button(GuiGraphics g, int mx, int my, int x, int y, int w, int h, String label, boolean primary, Click c, String tip) {
        boolean over = Draw.in(mx, my, x, y, w, h);
        int acc = Theme.accent();
        Draw.panel(g, x, y, w, h, primary ? Draw.alpha(acc, over ? 1f : 0.85f) : (over ? Theme.PANEL_HOVER : Theme.PANEL), Theme.radius());
        Draw.text(g, label, x + (w - Draw.width(label)) / 2, y + (h - 8) / 2, primary ? 0xFF101018 : Theme.TEXT);
        hit(x, y, w, h, c, null, tip);
    }

    private List<Module> filtered() {
        List<Module> out = new ArrayList<>();
        String q = search.toLowerCase(Locale.ROOT);
        if (page.equals("Recent")) {
            for (String id : mm.recent()) { Module m = mm.get(id); if (m != null) out.add(m); }
        } else {
            for (Module m : mm.all()) {
                switch (page) {
                    case "All" -> {}
                    case "Favorites" -> { if (!mm.isFavorite(m)) continue; }
                    default -> { if (!m.category.label.equals(page)) continue; }
                }
                out.add(m);
            }
        }
        out.removeIf(m -> (enabledOnly && !m.enabled())
            || (!q.isEmpty() && !m.name.toLowerCase(Locale.ROOT).contains(q) && !m.description.toLowerCase(Locale.ROOT).contains(q)));
        return out;
    }

    // ------------------------------------------------------------------ render
    @Override public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        float s = cs.guiScale.f();
        int mx = (int) (mouseX / s), my = (int) (mouseY / s);
        int W = (int) (width / s), H = (int) (height / s);
        long now = System.currentTimeMillis();
        float dt = Math.min(100, now - lastFrame); lastFrame = now;
        boolean reduced = cs.reducedMotion.on();
        float speed = cs.animSpeed.f();
        float open = reduced ? 1f : Math.min(1f, (now - opened) * speed / 180f);
        open = 1 - (1 - open) * (1 - open);

        g.pose().pushMatrix();
        g.pose().scale(s, s);
        g.fill(0, 0, W, H, ((int) (0x99 * open)) << 24);

        ww = Math.max(420, Math.min(ww, W - 8)); wh = Math.max(310, Math.min(wh, H - 8));
        if (wx == Integer.MIN_VALUE) { wx = (W - ww) / 2; wy = (H - wh) / 2; }
        wx = Math.max(0, Math.min(wx, W - ww)); wy = Math.max(0, Math.min(wy, H - wh));
        int x = wx, y = wy + (int) ((1 - open) * 10);
        int acc = Theme.accent(), r = Theme.radius();
        hits.clear(); clipTop = clipBottom = 0; hoverTip = null;

        Draw.glow(g, x, y, ww, wh, acc, Theme.GLOW, r);
        Draw.bordered(g, x, y, ww, wh, (Math.round(cs.guiOpacity.f() * 255) << 24) | (Theme.BG & 0xFFFFFF), Theme.BORDER, r + 2);
        // title bar
        Draw.logoMark(g, x + 20, y + 14, 22, acc, 0.5f);
        Draw.text(g, "VESPER", x + 36, y + 9, acc);
        Draw.text(g, "client", x + 36 + Draw.width("VESPER") + 4, y + 9, Theme.DIM);
        hit(x, y, ww - 24, 26, (b, cx, cy) -> { dragOffX = cx - wx; dragOffY = cy - wy; },
            (cx, cy) -> { wx = (int) (cx - dragOffX); wy = (int) (cy - dragOffY); }, null);
        boolean overClose = Draw.in(mx, my, x + ww - 22, y + 5, 16, 16);
        Draw.text(g, "x", x + ww - 17, y + 9, overClose ? Theme.BAD : Theme.DIM);
        hit(x + ww - 22, y + 5, 16, 16, (b, cx, cy) -> onClose(), null, "Close (Esc)");
        g.fill(x + 1, y + 26, x + ww - 1, y + 27, Theme.BORDER);

        // sidebar
        String[] pages = {"All", "Favorites", "Recent", "-", Category.COMBAT.label, Category.QOL.label, Category.VISUAL.label, Category.INTEGRATIONS.label, Category.CLIENT.label, "-", "Profiles"};
        int sy = y + 34;
        for (String p : pages) {
            if (p.equals("-")) { sy += 8; continue; }
            boolean sel = page.equals(p), over = Draw.in(mx, my, x + 6, sy, 106, 20);
            if (sel) Draw.panel(g, x + 6, sy, 106, 20, Draw.alpha(acc, 0.22f), r);
            else if (over) Draw.panel(g, x + 6, sy, 106, 20, Theme.PANEL_HOVER, r);
            if (sel) g.fill(x + 6, sy + 4, x + 8, sy + 16, acc);
            Draw.text(g, p, x + 16, sy + 6, sel ? Theme.TEXT : Theme.DIM);
            final String target = p;
            hit(x + 6, sy, 106, 20, (b, cx, cy) -> { page = target; targetScroll = scroll = 0; }, null, null);
            sy += 21;
        }
        button(g, mx, my, x + 8, y + wh - 30, 102, 22, "HUD Editor", true, (b, cx, cy) -> minecraft.setScreen(new HudEditorScreen(this)),
            "Drag, scale and toggle HUD elements with live previews.");
        g.fill(x + 118, y + 27, x + 119, y + wh - 1, Theme.BORDER);

        int cx = x + 126, cw = ww - 126 - 10;
        boolean profiles = page.equals("Profiles");
        int ly, lh;
        if (!profiles) {
            // search + filter chip
            int sw = cw - 94;
            Draw.panel(g, cx, y + 33, sw, 20, Theme.PANEL, r);
            boolean blink = (now / 500) % 2 == 0 && listening == null;
            String shown = search.isEmpty() ? "Type to search modules..." : search + (blink ? "_" : "");
            Draw.text(g, Draw.ellipsize(shown, sw - 12), cx + 6, y + 39, search.isEmpty() ? Theme.DIM : Theme.TEXT);
            hit(cx, y + 33, sw, 20, (b, a, c) -> { if (b == 1) search = ""; }, null, "Right-click to clear the search.");
            int chipX = cx + sw + 6;
            Draw.panel(g, chipX, y + 33, 88, 20, enabledOnly ? Draw.alpha(acc, 0.9f) : Theme.PANEL, r);
            Draw.text(g, "Enabled only", chipX + 8, y + 39, enabledOnly ? 0xFF101018 : Theme.DIM);
            hit(chipX, y + 33, 88, 20, (b, a, c) -> { enabledOnly = !enabledOnly; targetScroll = 0; }, null, "Show only modules that are switched on.");
            ly = y + 60;
        } else ly = y + 36;
        lh = y + wh - 22 - ly;

        // scrolling content
        scroll = reduced ? targetScroll : scroll + (targetScroll - scroll) * Math.min(1f, dt * 0.02f * speed + 0.15f);
        g.enableScissor(cx, ly, cx + cw, ly + lh);
        clipTop = ly; clipBottom = ly + lh;
        int content = profiles ? drawProfiles(g, mx, my, cx, ly - (int) scroll, cw) : drawModules(g, mx, my, cx, ly - (int) scroll, cw, ly, lh, dt, reduced, speed);
        g.disableScissor();
        clipTop = clipBottom = 0;
        maxScroll = Math.max(0, content - lh);
        targetScroll = Math.max(0, Math.min(targetScroll, maxScroll));
        if (maxScroll > 0) {   // scrollbar
            int bh = Math.max(16, (int) (lh * (lh / (float) content))), by = ly + (int) ((lh - bh) * (scroll / maxScroll));
            Draw.panel(g, cx + cw + 3, by, 3, bh, Draw.alpha(acc, 0.6f), 1);
        }

        // status line
        if (now < statusUntil) Draw.text(g, Draw.ellipsize(status, cw), cx, y + wh - 15, acc);
        else Draw.text(g, mm.all().stream().filter(Module::enabled).count() + " modules enabled  -  profile: " + cfg.active(), cx, y + wh - 15, Theme.DIM);

        // resize grip
        g.fill(x + ww - 9, y + wh - 3, x + ww - 3, y + wh - 2, Theme.DIM);
        g.fill(x + ww - 6, y + wh - 6, x + ww - 3, y + wh - 5, Theme.DIM);
        hit(x + ww - 14, y + wh - 14, 14, 14, null, (a, c) -> { ww = (int) (a - wx); wh = (int) (c - wy); }, "Drag to resize");

        if (welcome) drawWelcome(g, mx, my, W, H);

        // hover + tooltip
        hoverTip = null;
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (Draw.in(mx, my, h.x(), h.y(), h.w(), h.h())) {
                if (h.tip() != null) {
                    String key = h.tip() + h.x() + "," + h.y();
                    if (!key.equals(hoverKey)) { hoverKey = key; hoverSince = now; }
                    hoverTip = h.tip();
                }
                break;
            }
        }
        if (hoverTip == null) hoverKey = "";
        if (hoverTip != null && cs.tooltips.on() && now - hoverSince > 350 && !welcome) drawTooltip(g, mx, my, W, H, hoverTip);
        g.pose().popMatrix();
    }

    private void drawTooltip(GuiGraphics g, int mx, int my, int W, int H, String text) {
        List<String> lines = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String word : text.split(" ")) {
            if (Draw.width(cur + word) > 190 && cur.length() > 0) { lines.add(cur.toString().trim()); cur.setLength(0); }
            cur.append(word).append(' ');
        }
        lines.add(cur.toString().trim());
        int w = 0;
        for (String l : lines) w = Math.max(w, Draw.width(l));
        int h = lines.size() * 10 + 6;
        int x = Math.min(mx + 10, W - w - 14), y = Math.min(my + 12, H - h - 4);
        Draw.bordered(g, x, y, w + 10, h, 0xF0101018, Theme.accent(), Math.min(3, Theme.radius()));
        int ty = y + 4;
        for (String l : lines) { Draw.text(g, l, x + 5, ty, Theme.TEXT); ty += 10; }
    }

    // ------------------------------------------------------------------ modules page
    private int drawModules(GuiGraphics g, int mx, int my, int x, int top, int w, int ly, int lh, float dt, boolean reduced, float speed) {
        visible = filtered();
        int acc = Theme.accent(), r = Theme.radius();
        int cy = top;
        if (visible.isEmpty()) {
            String msg = page.equals("Favorites") ? "No favorites yet. Click the star on a module." : page.equals("Recent") ? "Modules you toggle will appear here." : "No modules match.";
            Draw.text(g, msg, x + 4, top + 8, Theme.DIM);
            return 30;
        }
        for (Module m : visible) {
            boolean open = expanded.contains(m);
            float target = open ? 1f : 0f, p = anim.getOrDefault(m, target);
            p = reduced ? target : (p < target ? Math.min(target, p + dt * 0.006f * speed) : Math.max(target, p - dt * 0.006f * speed));
            anim.put(m, p);
            boolean over = Draw.in(mx, my, x, cy, w, 26) && my >= ly && my < ly + lh;
            boolean sel = m == selected;

            int bg = over ? Theme.PANEL_HOVER : Theme.PANEL;
            Draw.panel(g, x, cy, w, 26, bg, r);
            if (m.enabled()) g.fill(x, cy + 5, x + 2, cy + 21, acc);
            if (sel) Draw.outline(g, x, cy, w, 26, Draw.alpha(acc, 0.8f));

            boolean fav = mm.isFavorite(m);
            Draw.text(g, fav ? "\u2605" : "\u2606", x + 8, cy + 9, fav ? Theme.WARN : Theme.DIM);
            Draw.text(g, m.name, x + 24, cy + 4, m.enabled() ? Theme.TEXT : 0xFFC4C4D4);
            Draw.text(g, Draw.ellipsize(m.description, w - 130), x + 24, cy + 15, Theme.DIM);
            if (m.canToggle()) pill(g, x + w - 32, cy + 8, m.enabled(), acc);
            if (m.key() > 0) {
                String k = Keys.name(m.key());
                Draw.text(g, k, x + w - 38 - Draw.width(k), cy + 9, Theme.DIM);
            }
            Draw.text(g, p > 0.5f ? "v" : ">", x + w - (m.canToggle() ? 54 : 18) - (m.key() > 0 ? Draw.width(Keys.name(m.key())) + 6 : 0), cy + 9, Theme.DIM);

            final Module mod = m;
            final String tip = m.description + (m instanceof HudModule ? " This is a HUD element." : "") + (m.canToggle() ? " Click to toggle, right-click for settings." : " Click for settings.");
            hit(x, cy, w, 26, (b, a, c) -> {
                selected = mod;
                if (b == 1 || !mod.canToggle()) toggleExpand(mod);
                else if (b == 0) { mod.toggle(); mm.touch(mod); }
            }, null, tip);
            hit(x, cy, 22, 26, (b, a, c) -> { if (b == 0) mm.toggleFavorite(mod); }, null, "Favorite");

            int used = 26;
            if (p > 0.001f) {
                int full = settings(g, mx, my, m, x + 8, cy + 28, w - 16, false, ly, lh);
                int shown = (int) (full * p);
                int savedTop = clipTop, savedBottom = clipBottom;
                int rowTop = Math.max(savedTop, cy + 28), rowBottom = Math.min(savedBottom, cy + 28 + shown);
                if (rowBottom > rowTop) {
                    g.enableScissor(x, rowTop, x + w, rowBottom);
                    clipTop = rowTop; clipBottom = rowBottom;
                    Draw.panel(g, x, cy + 28, w, shown, Theme.ROW, r);
                    settings(g, mx, my, m, x + 8, cy + 28, w - 16, true, ly, lh);
                    g.disableScissor();
                    clipTop = savedTop; clipBottom = savedBottom;
                }
                used += 2 + shown;
            }
            cy += used + 4;
        }
        return cy - top;
    }

    private void toggleExpand(Module m) { if (!expanded.remove(m)) expanded.add(m); }

    /** Draws (or only measures) a module's settings; returns total height. */
    private int settings(GuiGraphics g, int mx, int my, Module m, int x, int y, int w, boolean draw, int ly, int lh) {
        int cy = y + 4, acc = Theme.accent();
        for (Setting<?> s : m.settings()) {
            if (!s.isVisible()) continue;
            if (s instanceof BoolSetting b) {
                if (draw) {
                    Draw.text(g, s.name, x + 2, cy + 5, Theme.TEXT);
                    pill(g, x + w - 24, cy + 4, b.on(), acc);
                    hit(x, cy, w, 18, (btn, a, c) -> { if (btn == 0) b.set(!b.on()); else if (btn == 1) b.reset(); }, null, s.description + " Right-click to reset.");
                }
                cy += 18;
            } else if (s instanceof NumberSetting n) {
                if (draw) {
                    Draw.text(g, s.name, x + 2, cy + 5, Theme.TEXT);
                    int sx = x + w - 112, sw = 108;
                    Draw.panel(g, sx, cy + 3, sw, 12, Theme.OFF, Math.min(3, Theme.radius()));
                    int fillW = (int) (sw * n.fraction());
                    if (fillW > 0) Draw.panel(g, sx, cy + 3, Math.max(fillW, 3), 12, Draw.alpha(acc, 0.85f), Math.min(3, Theme.radius()));
                    String v = fmt(n);
                    Draw.text(g, v, sx + (sw - Draw.width(v)) / 2, cy + 5, 0xFFFFFFFF);
                    final int fsx = sx, fsw = sw;
                    hit(x, cy, w, 18, (btn, a, c) -> { if (btn == 1) n.reset(); }, null, s.description + " Drag the bar; right-click to reset.");
                    hit(sx, cy + 3, sw, 12, (btn, a, c) -> { if (btn == 1) n.reset(); },
                        (a, c) -> n.setFraction((a - fsx) / fsw), s.description + " Drag the bar; right-click to reset.");
                }
                cy += 18;
            } else if (s instanceof ModeSetting md) {
                if (draw) {
                    Draw.text(g, s.name, x + 2, cy + 5, Theme.TEXT);
                    int cw = Draw.width(md.get()) + 14, cx2 = x + w - cw - 2;
                    Draw.panel(g, cx2, cy + 2, cw, 14, Theme.OFF, Math.min(3, Theme.radius()));
                    Draw.text(g, md.get(), cx2 + 7, cy + 5, Theme.TEXT);
                    hit(x, cy, w, 18, (btn, a, c) -> { if (btn == 0) md.cycle(1); else if (btn == 1) md.cycle(-1); }, null, s.description + " Left-click: next, right-click: previous.");
                }
                cy += 18;
            } else if (s instanceof StringSetting st) {
                if (draw) {
                    Draw.text(g, s.name, x + 2, cy + 5, Theme.TEXT);
                    int bw2 = 118, bx2 = x + w - bw2 - 2;
                    boolean ed = editing == st;
                    Draw.bordered(g, bx2, cy + 1, bw2, 16, Theme.PANEL, ed ? acc : Theme.BORDER, Math.min(3, Theme.radius()));
                    boolean blink = (System.currentTimeMillis() / 500) % 2 == 0;
                    String shown = st.get().isEmpty() && !ed ? st.hint : st.get() + (ed && blink ? "_" : "");
                    String cut = shown;
                    while (cut.length() > 1 && Draw.width(cut) > bw2 - 10) cut = cut.substring(1);
                    Draw.text(g, cut, bx2 + 5, cy + 5, st.get().isEmpty() && !ed ? Theme.DIM : Theme.TEXT);
                    hit(x, cy, w, 18, (btn, a, c) -> { if (btn == 0) editing = st; else if (btn == 1) { st.reset(); editing = null; } }, null, s.description + " Click to type, Enter to finish, right-click to clear.");
                }
                cy += 18;
            } else if (s instanceof ActionSetting act) {
                if (draw) {
                    Draw.text(g, s.name, x + 2, cy + 5, Theme.TEXT);
                    button(g, mx, my, x + w - Draw.width(act.label) - 22, cy + 2, Draw.width(act.label) + 20, 14, act.label, false, (btn, a, c) -> { if (btn == 0) act.run(); }, s.description);
                }
                cy += 18;
            } else if (s instanceof ColorSetting c) {
                boolean open = colorOpen.contains(c);
                if (draw) {
                    Draw.text(g, s.name, x + 2, cy + 5, Theme.TEXT);
                    Draw.bordered(g, x + w - 26, cy + 3, 24, 12, c.argb(), Theme.BORDER, 2);
                    hit(x, cy, w, 18, (btn, a, d) -> { if (btn == 0) { if (!colorOpen.remove(c)) colorOpen.add(c); } else if (btn == 1) c.reset(); }, null, s.description + " Click to open the picker; right-click to reset.");
                }
                cy += 18;
                if (open) {
                    float[] hv = dragColor == c ? dragHsva : Draw.hsva(c.argb());
                    String[] names = {"Hue", "Sat", "Val", "Alpha"};
                    for (int i = 0; i < 4; i++) {
                        if (draw) {
                            int bx = x + 34, bw = w - 40;
                            Draw.text(g, names[i], x + 4, cy + 3, Theme.DIM);
                            int seg = 24;
                            for (int k = 0; k < seg; k++) {
                                float t = k / (float) (seg - 1);
                                int col = switch (i) {
                                    case 0 -> Draw.fromHsva(t, 1, 1, 1);
                                    case 1 -> Draw.fromHsva(hv[0], t, hv[2], 1);
                                    case 2 -> Draw.fromHsva(hv[0], hv[1], t, 1);
                                    default -> Draw.fromHsva(hv[0], hv[1], hv[2], 1) & 0xFFFFFF | ((int) (t * 255) << 24);
                                };
                                if (i == 3) g.fill(bx + k * bw / seg, cy + 1, bx + (k + 1) * bw / seg, cy + 11, 0xFF2A2A36);
                                g.fill(bx + k * bw / seg, cy + 1, bx + (k + 1) * bw / seg, cy + 11, col);
                            }
                            int tx = bx + (int) (hv[i] * (bw - 2));
                            g.fill(tx, cy, tx + 2, cy + 12, 0xFFFFFFFF);
                            final int idx = i, fbx = bx, fbw = bw;
                            hit(bx, cy, bw, 12, (btn, a, d) -> { if (btn == 0) { dragColor = c; dragHsva = Draw.hsva(c.argb()); } },
                                (a, d) -> {
                                    if (dragColor != c) return;
                                    dragHsva[idx] = (float) Math.max(0, Math.min(1, (a - fbx) / (fbw - 2)));
                                    c.set(Draw.fromHsva(dragHsva[0], dragHsva[1], dragHsva[2], dragHsva[3]));
                                }, "Drag to adjust " + names[i].toLowerCase(Locale.ROOT) + ".");
                        }
                        cy += 14;
                    }
                }
            }
        }
        // keybind
        if (draw) {
            Draw.text(g, "Keybind", x + 2, cy + 5, Theme.TEXT);
            String label = listening == m ? "Press a key..." : Keys.name(m.key());
            int cw = Draw.width(label) + 14, cx2 = x + w - cw - 2;
            Draw.panel(g, cx2, cy + 2, cw, 14, listening == m ? Draw.alpha(acc, 0.8f) : Theme.OFF, Math.min(3, Theme.radius()));
            Draw.text(g, label, cx2 + 7, cy + 5, listening == m ? 0xFF101018 : Theme.TEXT);
            hit(x, cy, w, 18, (btn, a, c) -> { if (btn == 0) listening = m; else if (btn == 1) { m.setKey(-1); listening = null; } }, null,
                "Click, then press a key. Delete or right-click unbinds, Esc cancels. Keybinds are saved per profile.");
        }
        cy += 18;
        if (m instanceof HudModule hm) {
            if (draw) {
                Draw.text(g, "Position and size", x + 2, cy + 5, Theme.TEXT);
                button(g, mx, my, x + w - 52, cy + 2, 50, 14, "Reset", false, (btn, a, c) -> { if (btn == 0) hm.resetLayout(); }, "Put this element back at its default position and size.");
            }
            cy += 18;
        }
        if (draw) {
            Draw.text(g, "Module", x + 2, cy + 5, Theme.TEXT);
            button(g, mx, my, x + w - 92, cy + 2, 90, 14, "Reset to defaults", false, (btn, a, c) -> { if (btn == 0) { m.resetToDefaults(); say(m.name + " reset to defaults."); } }, "Reset every setting, the keybind and the enabled state of this module.");
        }
        cy += 18;
        return cy - y + 2;
    }

    // ------------------------------------------------------------------ profiles page
    private int drawProfiles(GuiGraphics g, int mx, int my, int x, int top, int w) {
        int cy = top, r = Theme.radius(), acc = Theme.accent();
        Draw.text(g, "PROFILES", x + 2, cy + 2, Theme.DIM); cy += 14;
        for (String name : cfg.profiles()) {
            boolean act = name.equals(cfg.active()), over = Draw.in(mx, my, x, cy, w, 22);
            Draw.panel(g, x, cy, w, 22, act ? Draw.alpha(acc, 0.22f) : over ? Theme.PANEL_HOVER : Theme.PANEL, r);
            if (act) g.fill(x, cy + 4, x + 2, cy + 18, acc);
            Draw.text(g, name, x + 10, cy + 7, Theme.TEXT);
            if (act) Draw.text(g, "ACTIVE", x + w - 8 - Draw.width("ACTIVE"), cy + 7, acc);
            final String n = name;
            hit(x, cy, w, 22, (b, a, c) -> {
                if (b == 0) { cfg.switchTo(n); say("Switched to profile " + n + "."); }
                else if (b == 1) {
                    if (n.equals(cfg.active())) say("Switch to another profile before deleting this one.");
                    else if (confirm("del:" + n)) { cfg.delete(n); say("Deleted " + n + "."); }
                    else say("Right-click again to delete " + n + ".");
                }
            }, null, "Click to switch. Each profile stores module states, settings, keybinds and HUD layout. Right-click twice to delete.");
            cy += 25;
        }
        cy += 6;
        int bw = (w - 8) / 3;
        button(g, mx, my, x, cy, bw, 22, "New (copy)", false, (b, a, c) -> say("Created " + cfg.createFromCurrent() + " from your current settings."), "Create a new profile from the current settings and switch to it.");
        button(g, mx, my, x + bw + 4, cy, bw, 22, "Export active", false, (b, a, c) -> { var p = cfg.exportActive(); say("Exported to " + p.getParent().getFileName() + "/" + p.getFileName()); },
            "Writes the active profile as JSON into config/vesper/exports/ so you can share it.");
        button(g, mx, my, x + 2 * (bw + 4), cy, bw, 22, "Reset active", false, (b, a, c) -> {
            if (confirm("reset")) { cfg.resetActive(); say("Active profile reset to defaults."); } else say("Click Reset active again to confirm.");
        }, "Reset every module in the active profile to defaults. Click twice to confirm.");
        cy += 30;
        Draw.text(g, "IMPORT  (drop .json files into config/vesper/exports/)", x + 2, cy + 2, Theme.DIM); cy += 14;
        List<String> files = cfg.listImports();
        if (files.isEmpty()) { Draw.text(g, "No files found.", x + 4, cy + 4, Theme.DIM); cy += 18; }
        for (String f : files) {
            boolean over = Draw.in(mx, my, x, cy, w, 20);
            Draw.panel(g, x, cy, w, 20, over ? Theme.PANEL_HOVER : Theme.PANEL, r);
            Draw.text(g, f, x + 10, cy + 6, Theme.TEXT);
            Draw.text(g, "Import", x + w - 8 - Draw.width("Import"), cy + 6, Theme.DIM);
            hit(x, cy, w, 20, (b, a, c) -> { String n = cfg.importFile(f); say(n != null ? "Imported as profile " + n + "." : "Import failed: see the notification for the reason."); },
                null, "Imports this file as a new profile (validated as data only) and switches to it.");
            cy += 23;
        }
        cy += 8;
        Draw.text(g, Draw.ellipsize("Folder: " + cfg.root().toString(), w), x + 2, cy, Theme.DIM);
        return cy + 12 - top;
    }

    // ------------------------------------------------------------------ welcome card
    private void drawWelcome(GuiGraphics g, int mx, int my, int W, int H) {
        hits.clear(); clipTop = clipBottom = 0;
        g.fill(0, 0, W, H, 0xAA000000);
        int w = 320, h = 160, x = (W - w) / 2, y = (H - h) / 2, acc = Theme.accent();
        Draw.bordered(g, x, y, w, h, 0xFF14141C, acc, Theme.radius() + 2);
        Draw.text(g, "Welcome to VESPER", x + 16, y + 14, acc);
        String[] lines = {
            "Press " + Keys.name(cs.key()) + " any time to open this menu.",
            "Right-click a module for its settings. Hover for help.",
            "Use HUD Editor to place elements. Profiles save everything.",
            "Pick a starting point (you can change it any time):" };
        int ly = y + 34;
        for (String l : lines) { Draw.text(g, l, x + 16, ly, Theme.TEXT); ly += 13; }
        int bw = 92, by = y + h - 36;
        button(g, mx, my, x + 16, by, bw, 22, "CPvP preset", true, (b, a, c) -> { mm.applyPreset("cpvp"); finishWelcome(); }, "Enables crystal damage, target info, counters, armor, alerts, combat timer and notifications.");
        button(g, mx, my, x + 16 + bw + 6, by, bw, 22, "Minimal", false, (b, a, c) -> { mm.applyPreset("minimal"); finishWelcome(); }, "Enables just FPS/ping, coordinates and notifications.");
        button(g, mx, my, x + 16 + 2 * (bw + 6), by, bw, 22, "Skip", false, (b, a, c) -> finishWelcome(), null);
    }

    private void finishWelcome() { welcome = false; cfg.setWelcomeDone(); }

    // ------------------------------------------------------------------ input
    @Override public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        float s = cs.guiScale.f();
        double mx = e.x() / s, my = e.y() / s;
        if (listening != null) { listening = null; return true; }
        editing = null;   // clicking anywhere ends text entry (a click on a text row re-focuses it below)
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (!Draw.in(mx, my, h.x(), h.y(), h.w(), h.h())) continue;
            if (h.click() == null && h.drag() == null) continue;
            if (h.click() != null) h.click().on(e.button(), mx, my);
            if (h.drag() != null && e.button() == 0) { activeDrag = h.drag(); h.drag().on(mx, my); }
            return true;
        }
        return true;
    }

    @Override public boolean mouseDragged(MouseButtonEvent e, double dx, double dy) {
        if (activeDrag == null) return false;
        float s = cs.guiScale.f();
        activeDrag.on(e.x() / s, e.y() / s);
        return true;
    }

    @Override public boolean mouseReleased(MouseButtonEvent e) {
        activeDrag = null; dragColor = null;
        return true;
    }

    @Override public boolean mouseScrolled(double x, double y, double sx, double sy) {
        targetScroll = Math.max(0, Math.min(maxScroll, targetScroll - (float) sy * 28));
        return true;
    }

    @Override public boolean keyPressed(KeyEvent e) {
        int k = e.key();
        if (welcome) { if (k == GLFW.GLFW_KEY_ESCAPE) finishWelcome(); return true; }
        if (editing != null) {
            if (k == GLFW.GLFW_KEY_ENTER || k == GLFW.GLFW_KEY_KP_ENTER || k == GLFW.GLFW_KEY_ESCAPE) editing = null;
            else if (k == GLFW.GLFW_KEY_BACKSPACE && !editing.get().isEmpty()) editing.set(editing.get().substring(0, editing.get().length() - 1));
            return true;
        }
        if (listening != null) {
            if (k == GLFW.GLFW_KEY_ESCAPE) { /* cancel */ }
            else if (k == GLFW.GLFW_KEY_DELETE || k == GLFW.GLFW_KEY_BACKSPACE) listening.setKey(-1);
            else listening.setKey(k);
            listening = null;
            return true;
        }
        if (k == GLFW.GLFW_KEY_ESCAPE) { onClose(); return true; }
        if (k == cs.key() && search.isEmpty()) { onClose(); return true; }
        switch (k) {
            case GLFW.GLFW_KEY_BACKSPACE -> { if (!search.isEmpty()) search = search.substring(0, search.length() - 1); return true; }
            case GLFW.GLFW_KEY_TAB -> {
                List<String> order = List.of("All", "Favorites", "Recent", "Combat", "QoL", "Visual", "Integrations", "Client", "Profiles");
                int i = order.indexOf(page);
                page = order.get(Math.floorMod(i + ((e.modifiers() & GLFW.GLFW_MOD_SHIFT) != 0 ? -1 : 1), order.size()));
                targetScroll = scroll = 0;
                return true;
            }
            case GLFW.GLFW_KEY_DOWN, GLFW.GLFW_KEY_UP -> {
                if (visible.isEmpty()) return true;
                int i = visible.indexOf(selected), d = k == GLFW.GLFW_KEY_DOWN ? 1 : -1;
                selected = visible.get(i < 0 ? 0 : Math.floorMod(i + d, visible.size()));
                return true;
            }
            case GLFW.GLFW_KEY_ENTER, GLFW.GLFW_KEY_KP_ENTER -> {
                if (selected != null && selected.canToggle()) { selected.toggle(); mm.touch(selected); }
                else if (selected != null) toggleExpand(selected);
                return true;
            }
            case GLFW.GLFW_KEY_RIGHT -> { if (selected != null) expanded.add(selected); return true; }
            case GLFW.GLFW_KEY_LEFT -> { if (selected != null) expanded.remove(selected); return true; }
            default -> { return super.keyPressed(e); }
        }
    }

    @Override public boolean charTyped(CharacterEvent e) {
        if (welcome || listening != null) return true;
        int cp = e.codepoint();
        if (editing != null) { if (cp >= 32 && cp != 127) editing.set(editing.get() + new String(Character.toChars(cp))); return true; }
        if (page.equals("Profiles")) return true;
        if (cp >= 32 && cp != 127 && search.length() < 24) { search += new String(Character.toChars(cp)); targetScroll = 0; }
        return true;
    }
}
