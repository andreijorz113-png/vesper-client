package dev.vesper.gui;

import dev.vesper.VesperClient;
import dev.vesper.modules.ClientSettings;
import dev.vesper.theme.ThemeData;

import java.awt.Color;

/**
 * Live design tokens. The palette fields are updated by ThemeModule whenever the user changes a preset or color,
 * so the whole interface (click GUI, main menu, editor) recolors immediately. They are plain static ints so
 * drawing code can read them cheaply every frame.
 */
public final class Theme {
    private Theme() {}

    public static int BG = 0xFF121218, PANEL = 0xFF1B1B24, PANEL_HOVER = 0xFF252532, BORDER = 0xFF2C2C3A,
        TEXT = 0xFFECECF4, DIM = 0xFF8C8CA0, ROW = 0xFF171720, OFF = 0xFF3A3A48;
    public static float GLOW = 0.25f;
    public static final int GOOD = 0xFF5FD38D, WARN = 0xFFF2C14E, BAD = 0xFFFF5C6C;

    private static int mix(int a, int b, float t) { return dev.vesper.mc.McUtil.mixColor(a, b, t); }

    /** Applies the non-accent colors (the accent comes from ClientSettings so HUD and menus share it). */
    public static void apply(ThemeData d) {
        BG = d.bg(); PANEL = d.panel(); PANEL_HOVER = d.hover(); BORDER = d.border(); TEXT = d.text(); DIM = d.dim();
        ROW = mix(d.bg(), d.panel(), 0.5f);
        OFF = mix(d.border(), d.dim(), 0.25f);
        GLOW = d.glow();
    }

    public static int accent() {
        ClientSettings s = VesperClient.settings();
        int base = s.accent.argb() | 0xFF000000;
        if (!s.animatedAccent.on() || s.reducedMotion.on()) return base;
        float[] hsb = Color.RGBtoHSB((base >> 16) & 255, (base >> 8) & 255, base & 255, null);
        float t = (System.currentTimeMillis() % 9000L) / 9000f;
        float h = hsb[0] + 0.06f * (float) Math.sin(t * Math.PI * 2);
        return 0xFF000000 | (Color.HSBtoRGB(h, hsb[1], hsb[2]) & 0xFFFFFF);
    }

    public static int radius() { return VesperClient.settings().radius.i(); }
}
