package dev.vesper.gui;

import dev.vesper.VesperClient;
import dev.vesper.modules.ClientSettings;

import java.awt.Color;

/** Design tokens. The accent, radius, opacity, scale and motion come from Interface settings. */
public final class Theme {
    private Theme() {}

    public static final int BORDER = 0xFF2C2C3A, PANEL = 0xFF1B1B24, PANEL_HOVER = 0xFF252532, ROW = 0xFF171720,
        TEXT = 0xFFECECF4, DIM = 0xFF8C8CA0, OFF = 0xFF3A3A48, GOOD = 0xFF5FD38D, WARN = 0xFFF2C14E, BAD = 0xFFFF5C6C;

    public static int accent() {
        ClientSettings s = VesperClient.settings();
        int base = s.accent.argb() | 0xFF000000;
        if (!s.animatedAccent.on() || s.reducedMotion.on()) return base;
        float[] hsb = Color.RGBtoHSB((base >> 16) & 255, (base >> 8) & 255, base & 255, null);
        float t = (System.currentTimeMillis() % 9000L) / 9000f;
        float h = hsb[0] + 0.06f * (float) Math.sin(t * Math.PI * 2);
        return 0xFF000000 | (Color.HSBtoRGB(h, hsb[1], hsb[2]) & 0xFFFFFF);
    }

    public static int radius() { return VesperClient.settings().radius.i(); }
}
