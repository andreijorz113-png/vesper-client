package dev.vesper.modules;

import dev.vesper.core.Category;
import dev.vesper.core.setting.BoolSetting;
import dev.vesper.hud.TextHudModule;
import dev.vesper.mc.McUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.world.effect.MobEffectInstance;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class PotionTimers extends TextHudModule {
    public final BoolSetting hideAmbient = add(new BoolSetting("hideAmbient", "Hide beacon effects", "Skip ambient (beacon) effects.", false));
    private int tick;

    public PotionTimers() {
        super("potion_timers", "Potion Timers", "Active effects with remaining time.", Category.QOL, Anchor.TOP_RIGHT, 6, 6, false);
    }
    @Override protected void onDisable() { lines = List.of(); }

    @Override protected List<Line> sample() {
        return List.of(new Line("Speed II  1:42", 0xFFECECF4), new Line("Strength II  0:08", 0xFFFF5C6C), new Line("Fire Resistance  7:12", 0xFFECECF4));
    }

    private static String roman(int n) { return switch (n) { case 1 -> ""; case 2 -> " II"; case 3 -> " III"; case 4 -> " IV"; case 5 -> " V"; default -> " " + n; }; }

    @Override public void onTick() {
        if (++tick % 5 != 0) return;
        Minecraft mc = Minecraft.getInstance();
        if (!McUtil.inWorld()) { lines = List.of(); return; }
        List<Line> l = new ArrayList<>();
        for (MobEffectInstance e : mc.player.getActiveEffects()) {
            if (hideAmbient.on() && e.isAmbient()) continue;
            String name = e.getEffect().value().getDisplayName().getString() + roman(e.getAmplifier() + 1);
            if (e.isInfiniteDuration()) { l.add(new Line(name + "  inf", 0)); continue; }
            int s = e.getDuration() / 20;
            l.add(new Line(String.format(Locale.ROOT, "%s  %d:%02d", name, s / 60, s % 60), s < 10 ? 0xFFFF5C6C : 0));
        }
        lines = l;
    }
}
