package dev.vesper.modules;

import dev.vesper.core.Category;
import dev.vesper.core.setting.*;
import dev.vesper.hud.IconListHud;
import dev.vesper.mc.McUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;

public final class ArmorStatus extends IconListHud {
    public final BoolSetting showPercent = add(new BoolSetting("percent", "Show durability %", "Show remaining durability next to each piece.", true));
    public final BoolSetting mainHand = add(new BoolSetting("mainHand", "Include held item", "Also show the item in your main hand if it has durability.", false));
    private int tick;

    public ArmorStatus() {
        super("armor_status", "Armor Status", "Your armor pieces with durability.", Category.QOL, Anchor.BOTTOM_LEFT, 6, 110, false);
    }
    @Override protected void onDisable() { entries = List.of(); }
    @Override public void onWorldChange() { entries = List.of(); }

    @Override protected List<Entry> sample() {
        return List.of(new Entry(new ItemStack(Items.NETHERITE_HELMET), showPercent.on() ? "92%" : "", 0xFF5FD38D),
            new Entry(new ItemStack(Items.NETHERITE_CHESTPLATE), showPercent.on() ? "64%" : "", 0xFFF2C14E),
            new Entry(new ItemStack(Items.NETHERITE_LEGGINGS), showPercent.on() ? "80%" : "", 0xFF5FD38D),
            new Entry(new ItemStack(Items.NETHERITE_BOOTS), showPercent.on() ? "12%" : "", 0xFFFF5C6C));
    }

    @Override public void onTick() {
        if (++tick % 5 != 0) return;
        if (!McUtil.inWorld()) { entries = List.of(); return; }
        Minecraft mc = Minecraft.getInstance();
        List<Entry> l = new ArrayList<>(5);
        for (var slot : McUtil.ARMOR) addStack(l, mc.player.getItemBySlot(slot));
        if (mainHand.on()) addStack(l, mc.player.getMainHandItem());
        entries = l;
    }

    private void addStack(List<Entry> l, ItemStack s) {
        if (s.isEmpty()) return;
        int p = McUtil.durabilityPercent(s);
        l.add(new Entry(s, p < 0 || !showPercent.on() ? "" : p + "%", p < 0 ? 0 : McUtil.healthColor(p / 100f)));
    }
}
