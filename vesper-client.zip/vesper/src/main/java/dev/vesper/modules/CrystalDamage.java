package dev.vesper.modules;

import dev.vesper.calc.ExplosionMath;
import dev.vesper.calc.ExplosionMath.Defense;
import dev.vesper.calc.ExplosionMath.Difficulty;
import dev.vesper.core.Category;
import dev.vesper.core.setting.*;
import dev.vesper.hud.Notifications;
import dev.vesper.hud.TextHudModule;
import dev.vesper.mc.Exposure;
import dev.vesper.mc.McUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/**
 * INFORMATION ONLY: calculates what an end crystal explosion would do to you and the nearest player, and
 * previews the damage of a crystal placed on the obsidian/bedrock block you look at. It never places,
 * attacks or breaks anything.
 */
public final class CrystalDamage extends TextHudModule {
    public final ModeSetting source = add(new ModeSetting("source", "Crystal source", "Which existing crystal to report: the one dealing the most damage, or the closest.", "Highest damage", "Highest damage", "Nearest"));
    public final NumberSetting range = add(new NumberSetting("range", "Crystal range", "Only crystals within this distance of you are considered (explosions reach 12 blocks).", 12, 4, 16, 1, " blocks"));
    public final BoolSetting showSelf = add(new BoolSetting("showSelf", "Show self damage", "Estimate the damage you would take.", true));
    public final BoolSetting showTarget = add(new BoolSetting("showTarget", "Show target damage", "Estimate damage to the nearest other player.", true));
    public final NumberSetting targetRange = add(new NumberSetting("targetRange", "Target range", "Maximum distance to pick a target.", 12, 4, 32, 1, " blocks"), () -> showTarget.on());
    public final BoolSetting preview = add(new BoolSetting("preview", "Placement preview", "Show damage for a crystal placed on the obsidian/bedrock block you are looking at, and whether placement is possible.", true));
    public final NumberSetting dangerHp = add(new NumberSetting("dangerHp", "Danger threshold", "Self damage is shown in yellow when you would be left with this much health or less.", 6.0, 0.0, 20.0, 0.5, " HP"));
    public final BoolSetting notifyLethal = add(new BoolSetting("notifyLethal", "Lethal notifications", "Notify when a crystal would kill you or the target.", true));
    public final NumberSetting interval = add(new NumberSetting("interval", "Update interval", "Ticks between recalculations. Higher is cheaper (each calculation ray-casts ~45 times per crystal and player).", 2, 1, 10, 1, " ticks"));

    private int tick, lastNotify = -1000;

    public CrystalDamage() {
        super("crystal_damage", "Crystal Damage", "Estimated crystal damage to you and your target, with placement preview. Information only.",
            Category.COMBAT, Anchor.TOP_LEFT, 6, 60, false);
    }

    @Override protected void onDisable() { lines = List.of(); }
    @Override public void onWorldChange() { lines = List.of(); }

    @Override protected List<Line> sample() {
        return List.of(new Line("Crystal 3.2m", 0xFF8C8CA0), new Line("You  -7.5  (12.5 left)", 0xFF5FD38D), new Line("Target  -14.0  LETHAL", 0xFFFF5C6C));
    }

    @Override public void onTick() {
        if (++tick % interval.i() != 0) return;
        Minecraft mc = Minecraft.getInstance();
        if (!McUtil.inWorld()) { lines = List.of(); return; }

        Difficulty diff = McUtil.difficulty();
        Defense selfDef = McUtil.defense(mc.player);
        AbstractClientPlayer target = showTarget.on() ? McUtil.target(targetRange.get(), "Closest") : null;
        Defense tgtDef = target == null ? null : McUtil.defense(target);

        List<EndCrystal> crystals = mc.level.getEntitiesOfClass(EndCrystal.class, mc.player.getBoundingBox().inflate(range.get()), Entity::isAlive);
        crystals.sort(Comparator.comparingDouble(c -> c.distanceToSqr(mc.player)));
        if (crystals.size() > 6) crystals = crystals.subList(0, 6);

        List<Line> out = new ArrayList<>(4);
        if (!crystals.isEmpty()) {
            EndCrystal best = null; float bestSelf = 0, bestTgt = 0, bestScore = -1;
            for (EndCrystal c : crystals) {
                Vec3 pos = c.position();
                float s = showSelf.on() ? damage(pos, mc.player, diff, selfDef) : 0;
                float t = target != null ? damage(pos, target, diff, tgtDef) : 0;
                float score = source.is("Nearest") ? (best == null ? 1 : -1) : Math.max(s, t);
                if (best == null || score > bestScore) { best = c; bestSelf = s; bestTgt = t; bestScore = score; }
            }
            out.add(new Line(String.format(Locale.ROOT, "Crystal %.1fm", mc.player.distanceTo(best)), 0xFF8C8CA0));
            report(out, mc.player, target, bestSelf, bestTgt, selfDef, tgtDef, true);
        }

        if (preview.on() && mc.hitResult instanceof BlockHitResult hit && hit.getType() == HitResult.Type.BLOCK) {
            BlockPos base = hit.getBlockPos();
            BlockState st = mc.level.getBlockState(base);
            if (st.is(Blocks.OBSIDIAN) || st.is(Blocks.BEDROCK)) {
                String problem = placementProblem(mc, base);
                Vec3 center = new Vec3(base.getX() + 0.5, base.getY() + 1.0, base.getZ() + 0.5);
                out.add(new Line(problem == null ? "Preview: can place" : "Preview: " + problem, problem == null ? 0xFF8C8CA0 : 0xFFF2C14E));
                if (center.distanceTo(mc.player.position()) <= 12 || (target != null && center.distanceTo(target.position()) <= 12)) {
                    float s = showSelf.on() ? damage(center, mc.player, diff, selfDef) : 0;
                    float t = target != null ? damage(center, target, diff, tgtDef) : 0;
                    report(out, mc.player, target, s, t, selfDef, tgtDef, false);
                }
            }
        }
        lines = out.isEmpty() ? List.of() : out;
    }

    private void report(List<Line> out, LivingEntity me, AbstractClientPlayer target, float s, float t, Defense sd, Defense td, boolean notify) {
        if (showSelf.on()) {
            float left = ExplosionMath.healthAfter(me.getHealth(), s, sd);
            boolean lethal = left <= 0;
            int color = lethal ? 0xFFFF5C6C : left <= dangerHp.get() ? 0xFFF2C14E : 0xFF5FD38D;
            out.add(new Line(String.format(Locale.ROOT, "You  -%.1f  (%s)", s, lethal ? (McUtil.holdsTotem(me) ? "LETHAL, totem" : "LETHAL") : String.format(Locale.ROOT, "%.1f left", left)), color));
            if (notify && lethal && notifyLethal.on() && cooldownOk()) Notifications.push("A crystal nearby would kill you!", Notifications.BAD);
        }
        if (target != null && showTarget.on()) {
            float left = ExplosionMath.healthAfter(target.getHealth(), t, td);
            boolean lethal = left <= 0;
            out.add(new Line(String.format(Locale.ROOT, "%s  -%.1f  (%s)", target.getName().getString(), t,
                lethal ? (McUtil.holdsTotem(target) ? "LETHAL, totem" : "LETHAL") : String.format(Locale.ROOT, "%.1f left", left)),
                lethal ? 0xFF5FD38D : 0xFFECECF4));
            if (notify && lethal && notifyLethal.on() && cooldownOk()) Notifications.push("Crystal is lethal on " + target.getName().getString(), Notifications.GOOD);
        }
    }

    private boolean cooldownOk() {
        if (tick - lastNotify < 40) return false;
        lastNotify = tick;
        return true;
    }

    private static float damage(Vec3 c, LivingEntity e, Difficulty diff, Defense def) {
        double dist = e.position().distanceTo(c);
        if (dist > ExplosionMath.CRYSTAL_POWER * 2) return 0;
        double exposure = Exposure.of(Minecraft.getInstance().level, c, e);
        return ExplosionMath.finalDamage(ExplosionMath.rawDamage(dist, exposure, ExplosionMath.CRYSTAL_POWER), diff, def);
    }

    /** Mirrors vanilla end crystal placement rules: air above the base block and no entity in the 1x2x1 space. */
    private static String placementProblem(Minecraft mc, BlockPos base) {
        BlockPos above = base.above();
        if (!mc.level.isEmptyBlock(above)) return "blocked: block above";
        AABB box = new AABB(above.getX(), above.getY(), above.getZ(), above.getX() + 1, above.getY() + 2, above.getZ() + 1);
        if (!mc.level.getEntities((Entity) null, box).isEmpty()) return "blocked: entity in the way";
        return null;
    }
}
