package dev.vesper.modules;

import dev.vesper.core.Category;
import dev.vesper.core.setting.BoolSetting;
import dev.vesper.hud.TextHudModule;
import dev.vesper.mc.Keys;
import dev.vesper.mc.McUtil;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/** Clicks per second, measured by polling the mouse buttons every rendered frame. */
public final class CpsHud extends TextHudModule {
    public final BoolSetting left = add(new BoolSetting("left", "Left click", "Show left-click CPS.", true));
    public final BoolSetting right = add(new BoolSetting("right", "Right click", "Show right-click CPS.", true));
    private final ArrayDeque<Long> lmb = new ArrayDeque<>(), rmb = new ArrayDeque<>();
    private boolean lWas, rWas;

    public CpsHud() {
        super("cps", "CPS", "Clicks per second.", Category.QOL, Anchor.TOP_LEFT, 6, 90, false);
    }
    @Override protected void onDisable() { lmb.clear(); rmb.clear(); lines = List.of(); }
    @Override public void onWorldChange() { lmb.clear(); rmb.clear(); }

    @Override protected List<Line> sample() { return List.of(new Line("CPS 9 | 3", 0)); }

    @Override protected void onFrame() {
        if (!McUtil.inWorld() || McUtil.mc().screen != null) { lines = List.of(); return; }
        long now = System.currentTimeMillis();
        boolean l = Keys.mouseDown(0), r = Keys.mouseDown(1);
        if (l && !lWas) lmb.addLast(now);
        if (r && !rWas) rmb.addLast(now);
        lWas = l; rWas = r;
        while (!lmb.isEmpty() && now - lmb.peekFirst() > 1000) lmb.pollFirst();
        while (!rmb.isEmpty() && now - rmb.peekFirst() > 1000) rmb.pollFirst();
        List<String> parts = new ArrayList<>(2);
        if (left.on()) parts.add(String.valueOf(lmb.size()));
        if (right.on()) parts.add(String.valueOf(rmb.size()));
        lines = parts.isEmpty() ? List.of() : List.of(new Line("CPS " + String.join(" | ", parts), 0));
    }
}
