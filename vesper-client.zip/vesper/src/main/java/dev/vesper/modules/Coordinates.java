package dev.vesper.modules;

import dev.vesper.core.Category;
import dev.vesper.core.setting.BoolSetting;
import dev.vesper.hud.TextHudModule;
import dev.vesper.mc.McUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class Coordinates extends TextHudModule {
    public final BoolSetting direction = add(new BoolSetting("direction", "Direction", "Show the way you are facing.", true));
    public final BoolSetting converted = add(new BoolSetting("converted", "Nether/Overworld conversion", "Show the matching coordinates in the other dimension.", true));

    public Coordinates() {
        super("coordinates", "Coordinates", "Position, facing direction and Nether conversion.", Category.QOL, Anchor.TOP_LEFT, 6, 40, false);
    }
    @Override protected void onDisable() { lines = List.of(); }

    @Override protected List<Line> sample() {
        return List.of(new Line("XYZ 128 64 -304", 0), new Line("Nether 16 -38", 0xFFFF9A5C), new Line("Facing north (-Z)", 0xFF8C8CA0));
    }

    @Override public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (!McUtil.inWorld()) { lines = List.of(); return; }
        List<Line> l = new ArrayList<>(3);
        int x = (int) Math.floor(mc.player.getX()), y = (int) Math.floor(mc.player.getY()), z = (int) Math.floor(mc.player.getZ());
        l.add(new Line(String.format(Locale.ROOT, "XYZ %d %d %d", x, y, z), 0));
        if (converted.on()) {
            var dim = mc.level.dimension();
            if (dim == Level.OVERWORLD) l.add(new Line("Nether " + Math.floorDiv(x, 8) + " " + Math.floorDiv(z, 8), 0xFFFF9A5C));
            else if (dim == Level.NETHER) l.add(new Line("Overworld " + (x * 8) + " " + (z * 8), 0xFF5FD38D));
        }
        if (direction.on()) {
            Direction d = mc.player.getDirection();
            String axis = switch (d) { case NORTH -> "-Z"; case SOUTH -> "+Z"; case EAST -> "+X"; case WEST -> "-X"; default -> ""; };
            l.add(new Line("Facing " + d.getSerializedName() + " (" + axis + ")", 0xFF8C8CA0));
        }
        lines = l;
    }
}
