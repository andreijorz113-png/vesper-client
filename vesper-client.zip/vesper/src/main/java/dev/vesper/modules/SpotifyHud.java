package dev.vesper.modules;

import dev.vesper.VesperClient;
import dev.vesper.core.Category;
import dev.vesper.core.setting.*;
import dev.vesper.hud.HudModule;
import dev.vesper.hud.Notifications;
import dev.vesper.integration.SpotifyApi;
import dev.vesper.integration.SpotifyService;
import dev.vesper.gui.Draw;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

/**
 * Now-playing HUD using the official Spotify Web API (sign-in with PKCE, no client secret).
 * Setup: developer.spotify.com/dashboard > Create app > add redirect URI  http://127.0.0.1:8888/callback  > copy the Client ID here > Connect.
 * Shows real data only; the HUD editor uses clearly labelled sample text.
 */
public final class SpotifyHud extends HudModule {
    public final StringSetting clientId = add(new StringSetting("clientId", "Client ID", "Your Spotify app's Client ID (developer.spotify.com/dashboard). Add the redirect URI http://127.0.0.1:8888/callback to that app.", "", 40, "Client ID"));
    public final ActionSetting connect = add(new ActionSetting("connect", "Connect", "Open your browser to sign in with Spotify.", "Connect", this::doConnect));
    public final ActionSetting disconnect = add(new ActionSetting("disconnect", "Disconnect", "Forget the saved Spotify login on this computer.", "Disconnect", () -> { service().disconnect(); Notifications.push("Spotify disconnected.", Notifications.INFO); }));
    public final BoolSetting showArtist = add(new BoolSetting("showArtist", "Show artist", "Show the artist under the title.", true));
    public final BoolSetting showProgress = add(new BoolSetting("showProgress", "Progress bar", "Show a progress bar and time.", true));
    public final NumberSetting width = add(new NumberSetting("width", "Width", "Width of the element in pixels.", 130, 80, 260, 5, "px"));
    public final ColorSetting barColor = add(new ColorSetting("barColor", "Bar color", "Progress bar color.", 0xFF1ED760));

    private static SpotifyService svc;
    private int tick;

    public SpotifyHud() {
        super("spotify", "Spotify", "Shows the song playing on your Spotify account.", Category.INTEGRATIONS, Anchor.BOTTOM_LEFT, 6, 160, false);
    }

    private static SpotifyService service() {
        if (svc == null) svc = new SpotifyService(VesperClient.config().root());
        return svc;
    }

    private void doConnect() { service().setClientId(clientId.get()); service().connect(); Notifications.push("Spotify: finish signing in in your browser.", Notifications.INFO); }

    @Override protected void onEnable() { service().start(clientId.get()); }
    @Override protected void onDisable() { service().stop(); }
    @Override public void onTick() { if (++tick % 40 == 0) service().setClientId(clientId.get()); }

    private SpotifyApi.Track track(boolean preview) {
        if (preview) return new SpotifyApi.Track("Sample Song (preview)", "Sample Artist", 200_000, 72_000, true);
        return service().track();
    }

    private String statusLine() {
        SpotifyService.Status st = service().status();
        return switch (st) {
            case WAITING_FOR_BROWSER -> "Spotify: waiting for browser sign-in...";
            case ERROR -> "Spotify: " + service().message();
            case DISCONNECTED -> clientId.get().isBlank() ? "" : "Spotify: not connected (Integrations > Spotify > Connect)";
            default -> "";
        };
    }

    @Override protected boolean hasContent(boolean preview) { return preview || track(false) != null || !statusLine().isEmpty(); }

    @Override protected int contentWidth(Font f, boolean preview) { return width.i(); }
    @Override protected int contentHeight(Font f, boolean preview) {
        if (track(preview) == null) return f.lineHeight;
        return f.lineHeight + (showArtist.on() ? f.lineHeight + 1 : 0) + (showProgress.on() ? 7 : 0);
    }

    private static String time(long ms) { long s = ms / 1000; return (s / 60) + ":" + String.format("%02d", s % 60); }

    @Override protected void draw(GuiGraphics g, Font f, boolean preview) {
        SpotifyApi.Track t = track(preview);
        int w = width.i(), y = 0;
        if (t == null) { g.drawString(f, Draw.ellipsize(statusLine(), w), 0, 0, 0xFF8C8CA0, shadow.on()); return; }
        g.drawString(f, Draw.ellipsize((t.playing() ? "" : "|| ") + t.title(), w), 0, y, textColor.argb(), shadow.on());
        y += f.lineHeight + 1;
        if (showArtist.on()) { g.drawString(f, Draw.ellipsize(t.artist(), w), 0, y, 0xFF8C8CA0, shadow.on()); y += f.lineHeight + 1; }
        if (showProgress.on() && t.durationMs() > 0) {
            long p = preview ? t.progressMs() : service().progressNow();
            g.fill(0, y + 2, w, y + 4, 0x55FFFFFF);
            g.fill(0, y + 2, (int) (w * (p / (double) t.durationMs())), y + 4, barColor.argb());
        }
    }
}
