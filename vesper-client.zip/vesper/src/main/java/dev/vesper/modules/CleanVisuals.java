package dev.vesper.modules;

import dev.vesper.core.Category;
import dev.vesper.core.Module;
import dev.vesper.core.setting.BoolSetting;
import dev.vesper.core.setting.NumberSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import net.minecraft.client.ParticleStatus;

/**
 * Lowers visual noise by writing vanilla video options while enabled and restoring the originals when disabled.
 * Note: options.txt is saved by Minecraft, so if the game crashes while this is enabled the lowered values may persist.
 */
public final class CleanVisuals extends Module {
    public final BoolSetting particles = add(new BoolSetting("particles", "Minimal particles", "Set Particles to Minimal.", true));
    public final BoolSetting tilt = add(new BoolSetting("tilt", "Reduce damage tilt", "Lower the camera tilt when hurt.", true));
    public final NumberSetting tiltAmount = add(new NumberSetting("tiltAmount", "Damage tilt", "Camera tilt strength when hurt (vanilla 100%).", 0, 0, 100, 5, "%"), () -> tilt.on());
    public final BoolSetting fov = add(new BoolSetting("fov", "Reduce FOV effects", "Lower the FOV change from speed and sprinting.", false));
    public final NumberSetting fovAmount = add(new NumberSetting("fovAmount", "FOV effects", "Strength of FOV effects (vanilla 100%).", 0, 0, 100, 5, "%"), () -> fov.on());
    public final BoolSetting distortion = add(new BoolSetting("distortion", "Reduce distortion", "Lower nausea/portal screen distortion.", false));

    private ParticleStatus oldParticles;
    private Double oldTilt, oldFov, oldDistortion;

    public CleanVisuals() {
        super("clean_visuals", "Clean Visuals", "Reduces particles, damage tilt and FOV effects.", Category.VISUAL, -1, false);
    }

    @Override protected void onEnable() { apply(); }
    @Override protected void onDisable() { restore(); }
    @Override public void onTick() { apply(); }   // cheap; re-applies if the player changed options or toggled settings meanwhile

    private void apply() {
        var o = Minecraft.getInstance().options;
        if (particles.on()) { if (oldParticles == null) oldParticles = o.particles().get(); o.particles().set(ParticleStatus.MINIMAL); }
        else if (oldParticles != null) { o.particles().set(oldParticles); oldParticles = null; }
        oldTilt = set(o.damageTiltStrength(), tilt.on(), tiltAmount.get() / 100.0, oldTilt);
        oldFov = set(o.fovEffectScale(), fov.on(), fovAmount.get() / 100.0, oldFov);
        oldDistortion = set(o.screenEffectScale(), distortion.on(), 0.0, oldDistortion);
    }

    private static Double set(OptionInstance<Double> opt, boolean on, double value, Double saved) {
        if (on) {
            if (saved == null) saved = opt.get();
            if (Math.abs(opt.get() - value) > 1e-6) opt.set(value);
            return saved;
        }
        if (saved != null) opt.set(saved);
        return null;
    }

    private void restore() {
        var o = Minecraft.getInstance().options;
        if (oldParticles != null) { o.particles().set(oldParticles); oldParticles = null; }
        if (oldTilt != null) { o.damageTiltStrength().set(oldTilt); oldTilt = null; }
        if (oldFov != null) { o.fovEffectScale().set(oldFov); oldFov = null; }
        if (oldDistortion != null) { o.screenEffectScale().set(oldDistortion); oldDistortion = null; }
    }
}
