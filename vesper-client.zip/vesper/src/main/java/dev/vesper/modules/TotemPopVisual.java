package dev.vesper.modules;

import dev.vesper.core.Category;
import dev.vesper.core.setting.*;
import dev.vesper.hud.HudModule;
import dev.vesper.mc.PopTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;

/**
 * Small, elegant totem-pop indicator: an optional compact totem icon and one short line per pop that fades out.
 * Pops are inferred (see PopTracker), so rare false alarms are possible.
 */
public final class TotemPopVisual extends HudModule {
    private record Entry(String text, boolean self, int age) {}

    public final BoolSetting self = add(new BoolSetting("self", "Show my pops", "Show when you pop a totem.", true));
    public final BoolSetting others = add(new BoolSetting("others", "Show other players", "Show pops of other players.", true));
    public final NumberSetting range = add(new NumberSetting("range", "Range", "Only show other players within this distance.", 32, 4, 64, 1, " blocks"), () -> others.on());
    public final NumberSetting duration = add(new NumberSetting("duration", "Duration", "How long each pop stays.", 1.6, 0.5, 6.0, 0.1, "s"));
    public final BoolSetting fade = add(new BoolSetting("fade", "Fade out", "Fade each line out at the end (off while Reduced motion is on).", true));
    public final BoolSetting icon = add(new BoolSetting("icon", "Compact icon", "Show a tiny totem icon before the text.", true));
    public final BoolSetting count = add(new BoolSetting("count", "Show pop count", "Append the number of pops (x2, x3...).", true));
    public final ColorSetting selfColor = add(new ColorSetting("selfColor", "My color", "Color for your own pops.", 0xFFFF5C6C));
    public final ColorSetting otherColor = add(new ColorSetting("otherColor", "Other players color", "Color for other players' pops.", 0xFF5FD38D));
    public final BoolSetting sound = add(new BoolSetting("sound", "Sound", "Play a soft chime when a pop is detected.", false));

    private final List<Entry> entries = new ArrayList<>();
    private final java.util.function.Consumer<PopTracker.Pop> listener = this::onPop;
    private ItemStack totem;

    public TotemPopVisual() {
        super("totem_pop", "Totem Pop", "A compact, fading indicator when you or a nearby player pops a totem.", Category.VISUAL, Anchor.TOP_RIGHT, 6, 170, false);
    }

    @Override protected void onEnable() { PopTracker.subscribe(listener); }
    @Override protected void onDisable() { PopTracker.unsubscribe(listener); synchronized (entries) { entries.clear(); } }
    @Override public void onWorldChange() { synchronized (entries) { entries.clear(); } PopTracker.reset(); }

    private void onPop(PopTracker.Pop p) {
        if (p.self() ? !self.on() : (!others.on() || p.distance() > range.get())) return;
        String t = (p.self() ? "You" : p.name()) + " popped" + (count.on() && p.count() > 1 ? " x" + p.count() : "");
        synchronized (entries) { entries.add(new Entry(t, p.self(), 0)); if (entries.size() > 5) entries.remove(0); }
        if (sound.on()) Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.4f));
    }

    @Override public void onTick() {
        int max = (int) (duration.get() * 20);
        synchronized (entries) { for (int i = entries.size() - 1; i >= 0; i--) { Entry e = entries.get(i); if (e.age() + 1 > max) entries.remove(i); else entries.set(i, new Entry(e.text(), e.self(), e.age() + 1)); } }
    }

    private List<Entry> shown(boolean preview) {
        if (preview) return List.of(new Entry("Steve popped x2", false, 0), new Entry("You popped", true, 0));
        synchronized (entries) { return new ArrayList<>(entries); }
    }

    @Override protected boolean hasContent(boolean preview) { if (preview) return true; synchronized (entries) { return !entries.isEmpty(); } }
    private int rowH(Font f) { return Math.max(f.lineHeight, icon.on() ? 9 : 0) + 1; }
    @Override protected int contentWidth(Font f, boolean preview) {
        int w = 0;
        for (Entry e : shown(preview)) w = Math.max(w, f.width(e.text()) + (icon.on() ? 11 : 0));
        return w;
    }
    @Override protected int contentHeight(Font f, boolean preview) { int n = shown(preview).size(); return n == 0 ? 0 : n * rowH(f) - 1; }

    @Override protected void draw(GuiGraphics g, Font f, boolean preview) {
        if (totem == null) totem = new ItemStack(Items.TOTEM_OF_UNDYING);
        int max = Math.max(1, (int) (duration.get() * 20));
        boolean doFade = fade.on() && !dev.vesper.VesperClient.settings().reducedMotion.on();
        int y = 0;
        for (Entry e : shown(preview)) {
            int left = max - e.age();
            float a = preview || !doFade ? 1f : Math.max(0.05f, Math.min(1f, left / 8f));
            int base = e.self() ? selfColor.argb() : otherColor.argb();
            int color = (Math.max(8, Math.round(255 * a)) << 24) | (base & 0xFFFFFF);
            int x = 0;
            if (icon.on()) {
                g.pose().pushMatrix();
                g.pose().translate(0, y);
                g.pose().scale(0.5625f, 0.5625f);   // 16px item drawn at 9px
                g.renderItem(totem, 0, 0);
                g.pose().popMatrix();
                x = 11;
            }
            g.drawString(f, e.text(), x, y + (rowH(f) - 1 - f.lineHeight) / 2 + 1, color, shadow.on());
            y += rowH(f);
        }
    }
}
