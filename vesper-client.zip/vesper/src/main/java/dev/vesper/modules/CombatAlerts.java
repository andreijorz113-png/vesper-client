package dev.vesper.modules;

import dev.vesper.core.Category;
import dev.vesper.core.Module;
import dev.vesper.core.setting.*;
import dev.vesper.hud.Notifications;
import dev.vesper.mc.McUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;

import java.util.*;

/**
 * Notifications for combat events. Totem pops are INFERRED (player had a totem in hand, no longer has one,
 * and was just hurt); this can occasionally misfire if someone swaps items at the same moment they are hit.
 */
public final class CombatAlerts extends Module {
    public final BoolSetting pops = add(new BoolSetting("pops", "Totem pops", "Notify when you or a nearby player appears to pop a totem.", true));
    public final NumberSetting popRange = add(new NumberSetting("popRange", "Pop range", "Only track players within this distance.", 32, 8, 64, 1, " blocks"), () -> pops.on());
    public final NumberSetting lowTotems = add(new NumberSetting("lowTotems", "Low totem alert", "Alert when your total totems drops to this number or fewer (0 = off).", 2, 0, 10, 1, ""));
    public final NumberSetting lowArmor = add(new NumberSetting("lowArmor", "Low armor alert", "Alert when a worn armor piece falls below this durability percent (0 = off).", 15, 0, 50, 1, "%"));
    public final BoolSetting offhand = add(new BoolSetting("offhand", "Empty offhand warning", "Warn if you carry totems but hold none in your offhand.", false));

    private final Map<UUID, Boolean> hadTotem = new HashMap<>();
    private final Map<UUID, Integer> popCount = new HashMap<>();
    private final boolean[] armorAlerted = new boolean[4];
    private int tick, lastTotems = -1, lastOffhandWarn = -1000;

    public CombatAlerts() {
        super("combat_alerts", "Combat Alerts", "Totem pop, low totem, low armor and offhand notifications.", Category.COMBAT, -1, false);
    }

    @Override protected void onDisable() { onWorldChange(); }
    @Override public void onWorldChange() { hadTotem.clear(); popCount.clear(); Arrays.fill(armorAlerted, false); lastTotems = -1; }

    @Override public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (!McUtil.inWorld()) return;
        tick++;
        if (pops.on()) {
            check(mc.player, true);
            for (AbstractClientPlayer p : mc.level.players())
                if (p != mc.player && !p.isSpectator() && mc.player.distanceTo(p) <= popRange.get()) check(p, false);
        }
        if (tick % 10 != 0) return;
        int totems = McUtil.count(mc.player, Items.TOTEM_OF_UNDYING);
        if (lowTotems.i() > 0 && lastTotems >= 0 && totems < lastTotems && totems <= lowTotems.i())
            Notifications.push(totems == 0 ? "Out of totems!" : "Low on totems: " + totems + " left", Notifications.BAD);
        lastTotems = totems;
        if (lowArmor.i() > 0) {
            String[] names = {"Helmet", "Chestplate", "Leggings", "Boots"};
            for (int i = 0; i < 4; i++) {
                int p = McUtil.durabilityPercent(mc.player.getItemBySlot(McUtil.ARMOR[i]));
                if (p >= 0 && p < lowArmor.i()) {
                    if (!armorAlerted[i]) { armorAlerted[i] = true; Notifications.push(names[i] + " durability low: " + p + "%", Notifications.WARN); }
                } else armorAlerted[i] = false;
            }
        }
        if (offhand.on() && totems > 0 && !mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING) && tick - lastOffhandWarn > 200) {
            lastOffhandWarn = tick;
            Notifications.push("No totem in your offhand", Notifications.WARN);
        }
    }

    private void check(Player p, boolean self) {
        boolean has = McUtil.holdsTotem(p);
        Boolean prev = hadTotem.put(p.getUUID(), has);
        if (Boolean.TRUE.equals(prev) && !has && p.isAlive() && p.hurtTime > 0) {
            int n = popCount.merge(p.getUUID(), 1, Integer::sum);
            Notifications.push((self ? "You" : p.getName().getString()) + " popped a totem (" + n + ")", self ? Notifications.BAD : Notifications.GOOD);
        }
    }
}
