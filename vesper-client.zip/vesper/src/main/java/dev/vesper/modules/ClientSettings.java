package dev.vesper.modules;

import dev.vesper.core.Category;
import dev.vesper.core.Module;
import dev.vesper.core.setting.*;
import dev.vesper.gui.ClickGui;
import net.minecraft.client.Minecraft;

/** Always-on module holding interface/accessibility options. Its keybind opens the click GUI. */
public final class ClientSettings extends Module {
    public final ColorSetting accent = add(new ColorSetting("accent", "Accent color", "Main highlight color of the interface and HUD editor.", 0xFF8B7CFF));
    public final BoolSetting animatedAccent = add(new BoolSetting("animatedAccent", "Animated accent", "Slowly shift the accent color. Disabled automatically by Reduced motion.", false));
    public final NumberSetting guiScale = add(new NumberSetting("guiScale", "GUI scale", "Size of the click GUI relative to Minecraft's GUI scale.", 1.0, 0.75, 2.0, 0.05, "x"));
    public final NumberSetting guiOpacity = add(new NumberSetting("guiOpacity", "GUI opacity", "Opacity of the click GUI window.", 0.96, 0.5, 1.0, 0.01, ""));
    public final NumberSetting radius = add(new NumberSetting("radius", "Corner radius", "Roundness of panels and buttons.", 4, 0, 8, 1, "px"));
    public final BoolSetting reducedMotion = add(new BoolSetting("reducedMotion", "Reduced motion", "Turns off GUI animations and accent shifting.", false));
    public final NumberSetting animSpeed = add(new NumberSetting("animSpeed", "Animation speed", "Speed of GUI transitions.", 1.0, 0.25, 2.0, 0.05, "x"), () -> !reducedMotion.on());
    public final NumberSetting notifySeconds = add(new NumberSetting("notifySeconds", "Notification time", "How long notifications stay on screen.", 4.0, 1.0, 15.0, 0.5, "s"));
    public final BoolSetting toggleNotifications = add(new BoolSetting("toggleNotifications", "Toggle notifications", "Show a notification when a module is toggled with its keybind.", true));
    public final BoolSetting tooltips = add(new BoolSetting("tooltips", "Tooltips", "Show explanations when hovering over modules and settings.", true));
    public final BoolSetting hudSnap = add(new BoolSetting("hudSnap", "HUD grid snap", "Snap HUD elements to a grid in the HUD editor (G toggles).", true));
    public final NumberSetting gridSize = add(new NumberSetting("gridSize", "HUD grid size", "Grid spacing for snapping.", 8, 2, 32, 1, "px"), () -> hudSnap.on());
    public final BoolSetting guides = add(new BoolSetting("guides", "HUD alignment guides", "Snap to the edges and centers of other HUD elements.", true));

    public ClientSettings() {
        super("client", "Interface", "Appearance, accessibility and editor options. The keybind opens this menu.", Category.CLIENT, 344 /* RIGHT SHIFT */, true);
    }

    @Override public boolean canToggle() { return false; }

    @Override public void onKeyPressed() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen == null) mc.setScreen(new ClickGui());
    }
}
