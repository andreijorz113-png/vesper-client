package dev.vesper.modules;

import dev.vesper.core.Category;
import dev.vesper.core.setting.*;
import dev.vesper.hud.TextHudModule;
import dev.vesper.mc.McUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Items;

import java.util.*;

public final class TargetInfo extends TextHudModule {
    public final NumberSetting range = add(new NumberSetting("range", "Target range", "Maximum distance to pick a target.", 24, 4, 64, 1, " blocks"));
    public final ModeSetting priority = add(new ModeSetting("priority", "Target priority", "How the target is chosen.", "Closest", "Closest", "Lowest health", "Crosshair"));
    public final BoolSetting armor = add(new BoolSetting("armor", "Armor durability", "Show the lowest armor durability and per-piece values.", true));
    public final BoolSetting hands = add(new BoolSetting("hands", "Totems in hands", "Show how many totems the target holds.", true));
    public final BoolSetting ping = add(new BoolSetting("ping", "Ping and distance", "Show the target's ping and distance.", true));
    public final NumberSetting interval = add(new NumberSetting("interval", "Update interval", "Ticks between updates.", 2, 1, 10, 1, " ticks"));
    private int tick;

    public TargetInfo() {
        super("target_info", "Target Info", "Health, armor durability, totems and ping of your current target.", Category.COMBAT, Anchor.TOP_RIGHT, 6, 60, false);
    }
    @Override protected void onDisable() { lines = List.of(); }
    @Override public void onWorldChange() { lines = List.of(); }

    @Override protected List<Line> sample() {
        return List.of(new Line("Steve", 0xFFECECF4), new Line("HP 17.0 (+4.0)", 0xFF5FD38D), new Line("Armor H85 C70 L90 B60", 0xFFF2C14E),
            new Line("Totems in hand: 1", 0xFF5FD38D), new Line("4.2m  48ms", 0xFF8C8CA0));
    }

    @Override public void onTick() {
        if (++tick % interval.i() != 0) return;
        AbstractClientPlayer t = McUtil.target(range.get(), priority.get());
        if (t == null) { lines = List.of(); return; }
        List<Line> out = new ArrayList<>(5);
        out.add(new Line(t.getName().getString(), 0));
        float hp = t.getHealth(), abs = t.getAbsorptionAmount();
        out.add(new Line(String.format(Locale.ROOT, "HP %.1f%s", hp, abs > 0 ? String.format(Locale.ROOT, " (+%.1f)", abs) : ""), McUtil.healthColor(hp / t.getMaxHealth())));
        if (armor.on()) {
            StringBuilder sb = new StringBuilder("Armor");
            int min = 101; String[] tag = {"H", "C", "L", "B"};
            for (int i = 0; i < 4; i++) {
                int p = McUtil.durabilityPercent(t.getItemBySlot(McUtil.ARMOR[i]));
                sb.append(' ').append(tag[i]).append(p < 0 ? "-" : String.valueOf(p));
                if (p >= 0) min = Math.min(min, p);
            }
            out.add(new Line(sb.toString(), min > 100 ? 0xFF8C8CA0 : McUtil.healthColor(min / 100f)));
        }
        if (hands.on()) {
            int n = (t.getMainHandItem().is(Items.TOTEM_OF_UNDYING) ? 1 : 0) + (t.getOffhandItem().is(Items.TOTEM_OF_UNDYING) ? 1 : 0);
            out.add(new Line("Totems in hand: " + n, n > 0 ? 0xFF5FD38D : 0xFF8C8CA0));
        }
        if (ping.on()) {
            Minecraft mc = Minecraft.getInstance();
            PlayerInfo info = mc.getConnection() == null ? null : mc.getConnection().getPlayerInfo(t.getUUID());
            out.add(new Line(String.format(Locale.ROOT, "%.1fm%s", mc.player.distanceTo(t), info == null ? "" : "  " + info.getLatency() + "ms"), 0xFF8C8CA0));
        }
        lines = out;
    }
}
