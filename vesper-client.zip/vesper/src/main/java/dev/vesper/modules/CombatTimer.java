package dev.vesper.modules;

import dev.vesper.core.Category;
import dev.vesper.core.setting.*;
import dev.vesper.hud.TextHudModule;
import dev.vesper.mc.McUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;

import java.util.List;
import java.util.Locale;

/** Counts down from when you were hurt, or a player near you was hurt. Approximates server combat-tag timers; it is not server-authoritative. */
public final class CombatTimer extends TextHudModule {
    public final NumberSetting duration = add(new NumberSetting("duration", "Duration", "Length of the timer (match your server's combat-tag time).", 10, 1, 60, 1, "s"));
    public final NumberSetting range = add(new NumberSetting("range", "Opponent range", "Players this close that take damage also start the timer.", 8, 2, 32, 1, " blocks"));
    public final BoolSetting hideIdle = add(new BoolSetting("hideIdle", "Hide when idle", "Hide the element when the timer is not running.", true));
    private int ticksLeft;

    public CombatTimer() {
        super("combat_timer", "Combat Timer", "Countdown after you or a nearby player takes damage.", Category.COMBAT, Anchor.BOTTOM_LEFT, 6, 60, false);
    }
    @Override protected void onDisable() { ticksLeft = 0; lines = List.of(); }
    @Override public void onWorldChange() { ticksLeft = 0; lines = List.of(); }

    @Override protected List<Line> sample() { return List.of(new Line("Combat 7.3s", 0xFFFF5C6C)); }

    @Override public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (!McUtil.inWorld()) return;
        boolean hit = mc.player.hurtTime > 0;
        if (!hit) for (AbstractClientPlayer p : mc.level.players())
            if (p != mc.player && !p.isSpectator() && p.hurtTime > 0 && mc.player.distanceTo(p) <= range.get()) { hit = true; break; }
        if (hit) ticksLeft = duration.i() * 20;
        else if (ticksLeft > 0) ticksLeft--;
        if (ticksLeft > 0) lines = List.of(new Line(String.format(Locale.ROOT, "Combat %.1fs", ticksLeft / 20f), 0xFFFF5C6C));
        else lines = hideIdle.on() ? List.of() : List.of(new Line("Out of combat", 0xFF5FD38D));
    }
}
