package dev.vesper.modules;

import dev.vesper.core.Category;
import dev.vesper.core.Module;
import dev.vesper.core.setting.*;
import net.minecraft.client.gui.GuiGraphics;

/** Replaces the vanilla crosshair (including its attack-cooldown indicator) with a configurable one. */
public final class CrosshairModule extends Module {
    public final ModeSetting style = add(new ModeSetting("style", "Style", "Shape of the crosshair.", "Cross", "Cross", "Dot", "Circle", "Square", "Cross + Dot"));
    public final NumberSetting size = add(new NumberSetting("size", "Size", "Length of arms or radius.", 5, 1, 16, 1, "px"));
    public final NumberSetting gap = add(new NumberSetting("gap", "Center gap", "Empty space in the middle of the cross.", 2, 0, 10, 1, "px"), () -> style.is("Cross") || style.is("Cross + Dot"));
    public final NumberSetting thickness = add(new NumberSetting("thickness", "Thickness", "Line thickness.", 1, 1, 4, 1, "px"));
    public final ColorSetting color = add(new ColorSetting("color", "Color", "Crosshair color and opacity.", 0xFFFFFFFF));
    public final BoolSetting outline = add(new BoolSetting("outline", "Outline", "Draw a dark outline for contrast on bright backgrounds.", true));

    public CrosshairModule() {
        super("crosshair", "Custom Crosshair", "A configurable crosshair replacing the vanilla one.", Category.VISUAL, -1, false);
    }

    private void rect(GuiGraphics g, int x, int y, int w, int h, int c) {
        if (outline.on()) g.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xCC000000);
        g.fill(x, y, x + w, y + h, c);
    }

    public void draw(GuiGraphics g) {
        int cx = g.guiWidth() / 2, cy = g.guiHeight() / 2, t = thickness.i(), s = size.i(), gp = gap.i(), c = color.argb();
        int o = t / 2;
        String st = style.get();
        if (st.equals("Cross") || st.equals("Cross + Dot")) {
            // outlines first so overlapping arms do not show seams
            if (outline.on()) {
                g.fill(cx - o - gp - s - 1, cy - o - 1, cx - o - gp + 1, cy - o + t + 1, 0xCC000000);
                g.fill(cx - o + t + gp - 1, cy - o - 1, cx - o + t + gp + s + 1, cy - o + t + 1, 0xCC000000);
                g.fill(cx - o - 1, cy - o - gp - s - 1, cx - o + t + 1, cy - o - gp + 1, 0xCC000000);
                g.fill(cx - o - 1, cy - o + t + gp - 1, cx - o + t + 1, cy - o + t + gp + s + 1, 0xCC000000);
            }
            g.fill(cx - o - gp - s, cy - o, cx - o - gp, cy - o + t, c);
            g.fill(cx - o + t + gp, cy - o, cx - o + t + gp + s, cy - o + t, c);
            g.fill(cx - o, cy - o - gp - s, cx - o + t, cy - o - gp, c);
            g.fill(cx - o, cy - o + t + gp, cx - o + t, cy - o + t + gp + s, c);
        }
        if (st.equals("Dot") || st.equals("Cross + Dot")) rect(g, cx - o, cy - o, Math.max(t, 2), Math.max(t, 2), c);
        if (st.equals("Square")) {
            int r = s;
            if (outline.on()) { g.fill(cx - r - 1, cy - r - 1, cx + r + 1, cy + r + 1, 0xCC000000); g.fill(cx - r + t, cy - r + t, cx + r - t, cy + r - t, 0x00000000); }
            g.fill(cx - r, cy - r, cx + r, cy - r + t, c); g.fill(cx - r, cy + r - t, cx + r, cy + r, c);
            g.fill(cx - r, cy - r, cx - r + t, cy + r, c); g.fill(cx + r - t, cy - r, cx + r, cy + r, c);
        }
        if (st.equals("Circle")) {
            int r = s + 2;
            for (int i = 0; i < 48; i++) {
                double a = i * Math.PI * 2 / 48;
                int px = cx + (int) Math.round(Math.cos(a) * r) - o, py = cy + (int) Math.round(Math.sin(a) * r) - o;
                if (outline.on()) g.fill(px - 1, py - 1, px + t + 1, py + t + 1, 0x88000000);
            }
            for (int i = 0; i < 48; i++) {
                double a = i * Math.PI * 2 / 48;
                int px = cx + (int) Math.round(Math.cos(a) * r) - o, py = cy + (int) Math.round(Math.sin(a) * r) - o;
                g.fill(px, py, px + t, py + t, c);
            }
        }
    }
}
