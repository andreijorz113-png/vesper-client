package dev.vesper.modules;

import dev.vesper.VesperClient;
import dev.vesper.core.Category;
import dev.vesper.core.Module;
import dev.vesper.core.setting.BoolSetting;
import dev.vesper.hud.HudModule;
import dev.vesper.hud.TextHudModule;
import dev.vesper.mc.Keys;
import dev.vesper.mc.McUtil;
import net.minecraft.client.Minecraft;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class ModuleListHud extends TextHudModule {
    public final BoolSetting showKeys = add(new BoolSetting("showKeys", "Show keybinds", "Append each module's keybind.", true));
    public final BoolSetting includeHud = add(new BoolSetting("includeHud", "Include HUD elements", "List HUD-only modules too.", false));
    private int tick;

    public ModuleListHud() {
        super("module_list", "Module List", "Enabled modules and their keybinds.", Category.QOL, Anchor.BOTTOM_RIGHT, 6, 6, false);
    }
    @Override protected void onDisable() { lines = List.of(); }

    @Override protected List<Line> sample() { return List.of(new Line("Crystal Damage [R]", 0), new Line("Combat Alerts", 0)); }

    @Override public void onTick() {
        if (++tick % 10 != 0) return;
        Minecraft mc = Minecraft.getInstance();
        if (!McUtil.inWorld()) { lines = List.of(); return; }
        List<Line> l = new ArrayList<>();
        List<Module> on = new ArrayList<>();
        for (Module m : VesperClient.modules().all())
            if (m.enabled() && m.canToggle() && m != this && (includeHud.on() || !(m instanceof HudModule))) on.add(m);
        on.sort(Comparator.comparingInt((Module m) -> -mc.font.width(m.name)));
        for (Module m : on) l.add(new Line(m.name + (showKeys.on() && m.key() > 0 ? " [" + Keys.name(m.key()) + "]" : ""), 0));
        lines = l;
    }
}
