package dev.vesper.modules;

import dev.vesper.core.Category;
import dev.vesper.core.Module;
import dev.vesper.core.setting.*;
import dev.vesper.menu.BackgroundImages;
import dev.vesper.menu.VesperTitleScreen;
import net.minecraft.client.Minecraft;

/** Replaces Minecraft's title screen with the Vesper main menu. Disable to get the vanilla title screen back. */
public final class MainMenu extends Module {
    public final ModeSetting background = add(new ModeSetting("background", "Background", "Minecraft panorama, your own image, or a theme gradient.", "Minecraft panorama", "Minecraft panorama", "Custom image", "Gradient", "Solid"));
    public final StringSetting image = add(new StringSetting("image", "Image file", "File name inside config/vesper/backgrounds (PNG, JPG, GIF or BMP, up to 8192x8192).", "", 64, "background.png"), () -> background.is("Custom image"));
    public final BoolSetting rotate = add(new BoolSetting("rotate", "Panorama rotation", "Slowly rotate the Minecraft panorama.", true), () -> background.is("Minecraft panorama"));
    public final NumberSetting drift = add(new NumberSetting("drift", "Image movement", "How far the custom image slowly drifts (0 = still).", 0.5, 0.0, 1.0, 0.05, ""), () -> background.is("Custom image"));
    public final ColorSetting tint = add(new ColorSetting("tint", "Background tint", "Color laid over the background. The alpha slider sets its strength.", 0x400A0A14));
    public final NumberSetting dim = add(new NumberSetting("dim", "Darkening", "Extra darkening for readability (0 = none).", 0.25, 0.0, 0.9, 0.05, ""));
    public final NumberSetting menuOpacity = add(new NumberSetting("menuOpacity", "Menu opacity", "Opacity of the left navigation panel.", 0.80, 0.2, 1.0, 0.05, ""));
    public final NumberSetting anim = add(new NumberSetting("anim", "Animation intensity", "Strength of hover, logo and fade animations. Reduced motion forces 0.", 1.0, 0.0, 1.5, 0.1, ""));
    public final BoolSetting logoAnim = add(new BoolSetting("logoAnim", "Logo animation", "Subtle twinkle on the logo star.", true));
    public final NumberSetting transition = add(new NumberSetting("transition", "Transition time", "Fade-in time when the menu opens.", 0.35, 0.05, 1.5, 0.05, "s"));
    public final ActionSetting preview = add(new ActionSetting("preview", "Preview", "Open the main menu on top of the current screen to test these settings. Esc returns here.", "Preview", () -> {
        Minecraft mc = Minecraft.getInstance();
        mc.setScreen(new VesperTitleScreen(mc.screen));
    }));

    public MainMenu() {
        super("main_menu", "Main Menu", "A redesigned title screen with custom backgrounds. Turn off to use the vanilla title screen.", Category.VISUAL, -1, true);
    }

    @Override protected void onDisable() { BackgroundImages.release(); }
}
