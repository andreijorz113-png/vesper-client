package dev.vesper.modules;

import dev.vesper.VesperClient;
import dev.vesper.core.Category;
import dev.vesper.core.Module;
import dev.vesper.core.setting.*;
import dev.vesper.gui.Theme;
import dev.vesper.hud.Notifications;
import dev.vesper.theme.ThemeData;
import dev.vesper.theme.ThemeStore;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Theme engine. Pick a preset, tweak any color (the preset flips to "Custom"), then save/load/export/import your own.
 * The in-game sky is separate and never changes with the theme.
 * Saved themes live in config/vesper/themes; shared files go through config/vesper/exports (theme-<name>.json).
 */
public final class ThemeModule extends Module {
    private static final List<String> OPTIONS = new ArrayList<>(ThemeData.presetNames());
    static { OPTIONS.add("Custom"); }

    public final ModeSetting preset = add(new ModeSetting("preset", "Preset", "Obsidian, Eclipse, Midnight, Violet, Frost, Ember or Monochrome. Editing any color switches to Custom.", "Obsidian", OPTIONS.toArray(new String[0])));
    public final ColorSetting bg = add(new ColorSetting("bg", "Main background", "Window background.", 0xFF121218));
    public final ColorSetting panel = add(new ColorSetting("panel", "Panel background", "Module cards and buttons.", 0xFF1B1B24));
    public final ColorSetting hover = add(new ColorSetting("hover", "Hover color", "Highlight when hovering.", 0xFF252532));
    public final ColorSetting border = add(new ColorSetting("border", "Border color", "Thin outlines.", 0xFF2C2C3A));
    public final ColorSetting text = add(new ColorSetting("text", "Primary text", "Main text color.", 0xFFECECF4));
    public final ColorSetting dim = add(new ColorSetting("dim", "Secondary text", "Descriptions and hints.", 0xFF8C8CA0));
    public final NumberSetting glow = add(new NumberSetting("glow", "Glow intensity", "Soft accent glow around the window (0 = off). The accent color itself is under Interface.", 0.25, 0.0, 1.0, 0.05, ""));
    public final StringSetting themeName = add(new StringSetting("themeName", "Theme name", "Name used by Save, Load, Delete, Export and Import below (letters, numbers, spaces, - and _).", "My Theme", 32, "name"));
    public final ActionSetting save = add(new ActionSetting("save", "Save theme", "Save the current colors under the theme name (overwrites).", "Save", this::doSave));
    public final ActionSetting load = add(new ActionSetting("load", "Load theme", "Apply the saved theme with this name.", "Load", this::doLoad));
    public final ActionSetting delete = add(new ActionSetting("delete", "Delete theme", "Delete the saved theme with this name.", "Delete", this::doDelete));
    public final ActionSetting export = add(new ActionSetting("export", "Export theme", "Write the saved theme to config/vesper/exports/theme-<name>.json to share it.", "Export", this::doExport));
    public final ActionSetting imp = add(new ActionSetting("import", "Import theme", "Import config/vesper/exports/theme-<name>.json (or the file name) as a saved theme.", "Import", this::doImport));
    public final ActionSetting revert = add(new ActionSetting("revert", "Revert", "Go back to the theme you had when the menu was opened.", "Revert", this::doRevert));

    private String lastPreset;
    private ThemeData applied, snapshot;

    public ThemeModule() {
        super("theme", "Theme", "Colors of the whole interface, with presets and saveable custom themes.", Category.CLIENT, -1, true);
    }

    @Override public boolean canToggle() { return false; }

    public ThemeData current() {
        return new ThemeData(preset.get(), bg.argb(), panel.argb(), hover.argb(), border.argb(), text.argb(), dim.argb(),
            VesperClient.settings().accent.argb(), glow.f());
    }

    /** Called when the click GUI opens so Revert has something to return to. */
    public void takeSnapshot() { snapshot = current(); }

    @Override public void onTick() { sync(); }

    /** Keeps settings, preset name and the live Theme tokens consistent. Cheap: no work unless something changed. */
    public void sync() {
        ThemeData cur = current();
        if (lastPreset == null) lastPreset = preset.get();
        if (!preset.get().equals(lastPreset)) {
            lastPreset = preset.get();
            ThemeData p = ThemeData.preset(lastPreset);
            if (p != null) { setPalette(p); cur = current(); }
        } else if (!"Custom".equals(preset.get())) {
            ThemeData p = ThemeData.preset(preset.get());
            if (p != null && !p.samePalette(cur)) { preset.set("Custom"); lastPreset = "Custom"; cur = current(); }
        }
        if (applied == null || !applied.samePalette(cur)) { Theme.apply(cur); applied = cur; }
    }

    private void setPalette(ThemeData p) {
        bg.set(p.bg()); panel.set(p.panel()); hover.set(p.hover()); border.set(p.border()); text.set(p.text()); dim.set(p.dim());
        glow.set((double) p.glow());
        VesperClient.settings().accent.set(p.accent());
    }

    // ------------------------------------------------------------------ actions
    private ThemeStore store() { return VesperClient.themes(); }
    private void say(String s, int color) { Notifications.push(s, color); }

    private void doSave() {
        try { store().save(current().named(themeName.get().trim())); say("Saved theme '" + themeName.get().trim() + "'.", Notifications.GOOD); }
        catch (IOException e) { say(e.getMessage(), Notifications.BAD); }
    }
    private void doLoad() {
        try {
            ThemeData d = store().load(themeName.get().trim());
            preset.set("Custom"); lastPreset = "Custom"; setPalette(d);
            say("Loaded theme '" + d.name() + "'.", Notifications.GOOD);
        } catch (IOException e) { say(e.getMessage() + " Saved themes: " + store().list(), Notifications.WARN); }
    }
    private void doDelete() {
        try { say(store().delete(themeName.get().trim()) ? "Deleted theme." : "No such theme.", Notifications.INFO); }
        catch (IOException e) { say(e.getMessage(), Notifications.BAD); }
    }
    private void doExport() {
        try { var p = store().export(themeName.get().trim(), VesperClient.config().exportsDir()); say("Exported to exports/" + p.getFileName(), Notifications.GOOD); }
        catch (IOException e) { say(e.getMessage(), Notifications.BAD); }
    }
    private void doImport() {
        try {
            String n = themeName.get().trim();
            String file = n.endsWith(".json") ? n : "theme-" + n + ".json";
            String saved = store().importFile(file, VesperClient.config().exportsDir());
            themeName.set(saved);
            say("Imported theme '" + saved + "'. Press Load to apply it.", Notifications.GOOD);
        } catch (IOException e) { say(e.getMessage(), Notifications.BAD); }
    }
    private void doRevert() {
        if (snapshot == null) return;
        preset.set(snapshot.name()); lastPreset = snapshot.name(); setPalette(snapshot);
        say("Theme reverted.", Notifications.INFO);
    }
}
