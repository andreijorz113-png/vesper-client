package dev.vesper.modules;

import com.google.gson.JsonObject;
import dev.vesper.VesperClient;
import dev.vesper.core.Category;
import dev.vesper.core.Module;
import dev.vesper.core.setting.*;
import dev.vesper.hud.Notifications;
import dev.vesper.integration.DiscordIpc;
import dev.vesper.mc.McUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.world.item.Items;

import java.io.IOException;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Real Discord Rich Presence over Discord's local IPC. You need a free Discord application:
 * discord.com/developers/applications > New Application > copy the Application ID into this module.
 * (Optional: upload an image named in "Large image key" under Rich Presence > Art Assets.)
 * Discord limits updates to one per 15 seconds. Server addresses are hidden by default.
 */
public final class DiscordPresence extends Module {
    public final StringSetting appId = add(new StringSetting("appId", "Application ID", "From discord.com/developers/applications (a long number). Required.", "", 24, "123456789012345678"));
    public final StringSetting largeImage = add(new StringSetting("largeImage", "Large image key", "Optional: name of an image uploaded under Rich Presence > Art Assets.", "", 64, "vesper"));
    public final ModeSetting details = add(new ModeSetting("details", "Top line", "What the first line shows.", "Where I am", "Where I am", "Custom text", "Hidden"));
    public final ModeSetting state = add(new ModeSetting("state", "Second line", "What the second line shows.", "Health and totems", "Health and totems", "Enabled modules", "Custom text", "Hidden"));
    public final StringSetting custom = add(new StringSetting("custom", "Custom text", "Used when a line is set to Custom text.", "Crystal PvP with Vesper", 64, "text"), () -> details.is("Custom text") || state.is("Custom text"));
    public final BoolSetting showServer = add(new BoolSetting("showServer", "Show server address", "Reveal the server IP/name. Off shows just 'Playing multiplayer'.", false));
    public final BoolSetting elapsed = add(new BoolSetting("elapsed", "Show elapsed time", "Show how long you have been playing.", true));
    public final ActionSetting reconnect = add(new ActionSetting("reconnect", "Reconnect", "Retry the connection to Discord now.", "Reconnect", this::kick));

    private final AtomicReference<String> latest = new AtomicReference<>("");
    private volatile Thread worker;
    private volatile boolean stop, kick;
    private volatile String status = "";
    private long startMs;
    private int tick;
    private boolean told;

    public DiscordPresence() {
        super("discord", "Discord Rich Presence", "Shows what you are doing in Minecraft on your Discord profile.", Category.INTEGRATIONS, -1, false);
    }

    @Override protected void onEnable() {
        startMs = System.currentTimeMillis(); stop = false; told = false;
        Thread t = new Thread(this::loop, "Vesper-Discord");
        t.setDaemon(true); worker = t; t.start();
    }

    @Override protected void onDisable() {
        stop = true;
        Thread t = worker;
        if (t != null) t.interrupt();
        worker = null;
    }

    private void kick() { kick = true; Thread t = worker; if (t != null) t.interrupt(); }

    // ------------------------------------------------------------------ game thread: build the payload
    @Override public void onTick() {
        if (++tick % 40 != 0) return;
        String id = appId.get().trim();
        if (id.isEmpty()) {
            if (!told) { told = true; Notifications.push("Discord: enter your Application ID in Integrations > Discord.", Notifications.WARN); }
            latest.set("");
            return;
        }
        if (!status.isEmpty() && !status.equals("ok")) { Notifications.push("Discord: " + status, Notifications.WARN); status = ""; }
        JsonObject a = new JsonObject();
        String d = line(details.get()), s = line(state.get());
        if (!d.isEmpty()) a.addProperty("details", d);
        if (!s.isEmpty()) a.addProperty("state", s);
        if (elapsed.on()) { JsonObject ts = new JsonObject(); ts.addProperty("start", startMs / 1000); a.add("timestamps", ts); }
        if (!largeImage.get().isBlank()) { JsonObject as = new JsonObject(); as.addProperty("large_image", largeImage.get().trim()); as.addProperty("large_text", "Vesper Client"); a.add("assets", as); }
        latest.set(id + "\n" + a);
    }

    private String line(String mode) {
        Minecraft mc = Minecraft.getInstance();
        switch (mode) {
            case "Custom text": return custom.get();
            case "Where I am": {
                if (mc.level == null) return "In the main menu";
                if (mc.getCurrentServer() == null) return "Playing singleplayer";
                return showServer.on() ? "Playing on " + mc.getCurrentServer().ip : "Playing multiplayer";
            }
            case "Health and totems":
                if (!McUtil.inWorld()) return "";
                return String.format(Locale.ROOT, "%.0f HP  -  %d totems", mc.player.getHealth(), McUtil.count(mc.player, Items.TOTEM_OF_UNDYING));
            case "Enabled modules": {
                long n = VesperClient.modules().all().stream().filter(m -> m.enabled() && m.canToggle()).count();
                return n + " Vesper modules on";
            }
            default: return "";
        }
    }

    // ------------------------------------------------------------------ background thread: talk to Discord
    private void loop() {
        DiscordIpc ipc = null; String sentId = "", sentPayload = "";
        long lastSend = 0, nextTry = 0;
        while (!stop) {
            try {
                String cur = latest.get();
                int nl = cur.indexOf('\n');
                String id = nl < 0 ? "" : cur.substring(0, nl), payload = nl < 0 ? "" : cur.substring(nl + 1);
                long now = System.currentTimeMillis();
                if (kick) { kick = false; if (ipc != null) { ipc.close(); ipc = null; } nextTry = 0; sentPayload = ""; }
                if (id.isEmpty()) { if (ipc != null) { try { ipc.setActivity(null); } catch (IOException ignored) {} ipc.close(); ipc = null; } sentPayload = ""; sleep(1000); continue; }
                if (ipc != null && !id.equals(sentId)) { ipc.close(); ipc = null; }
                if (ipc == null && now >= nextTry) {
                    try { ipc = DiscordIpc.connect(DiscordIpc.openAny(), id, ProcessHandle.current().pid()); sentId = id; sentPayload = ""; status = "ok"; }
                    catch (IOException e) { status = "could not connect (" + e.getMessage() + "). Is Discord running? Retrying every 30s."; nextTry = now + 30_000; }
                }
                if (ipc != null && (!payload.equals(sentPayload) || now - lastSend > 60_000) && now - lastSend >= 15_000) {
                    ipc.setActivity(com.google.gson.JsonParser.parseString(payload).getAsJsonObject());
                    sentPayload = payload; lastSend = now;
                }
                sleep(1000);
            } catch (IOException e) {
                if (ipc != null) { ipc.close(); ipc = null; }
                status = "connection lost (" + e.getMessage() + "). Reconnecting...";
                sleep(5000);
            } catch (RuntimeException e) {
                VesperClient.LOG.warn("Discord presence error", e);
                sleep(5000);
            }
        }
        if (ipc != null) { try { ipc.setActivity(null); } catch (IOException ignored) {} ipc.close(); }
    }

    private static void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException ignored) { /* woken by kick/stop */ } }
}
