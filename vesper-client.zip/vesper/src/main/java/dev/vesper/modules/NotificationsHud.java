package dev.vesper.modules;

import dev.vesper.VesperClient;
import dev.vesper.core.Category;
import dev.vesper.hud.Notifications;
import dev.vesper.hud.TextHudModule;

import java.util.ArrayList;
import java.util.List;

/** Renders the notification queue. Duration comes from Interface > Notification time. */
public final class NotificationsHud extends TextHudModule {
    public NotificationsHud() {
        super("notifications", "Notifications", "Where combat and client notifications appear.", Category.QOL, Anchor.TOP_RIGHT, 6, 120, true);
    }
    @Override protected void onDisable() { lines = List.of(); }

    @Override protected List<Line> sample() { return List.of(new Line("Steve popped a totem (1)", Notifications.GOOD), new Line("Low on totems: 2 left", Notifications.WARN)); }

    @Override public void onTick() {
        List<Notifications.Entry> es = Notifications.snapshot();
        if (es.isEmpty()) { lines = List.of(); return; }
        int max = (int) (VesperClient.settings().notifySeconds.f() * 20);
        boolean fade = !VesperClient.settings().reducedMotion.on();
        List<Line> l = new ArrayList<>(es.size());
        for (Notifications.Entry e : es) {
            int left = max - e.age();
            int color = e.color();
            if (fade && left < 10) { int a = Math.max(8, 255 * left / 10); color = (a << 24) | (color & 0xFFFFFF); }
            l.add(new Line(e.text(), color));
        }
        lines = l;
    }
}
