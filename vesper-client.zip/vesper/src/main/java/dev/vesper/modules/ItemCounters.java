package dev.vesper.modules;

import dev.vesper.core.Category;
import dev.vesper.core.setting.*;
import dev.vesper.hud.IconListHud;
import dev.vesper.mc.McUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;

public final class ItemCounters extends IconListHud {
    public final BoolSetting obsidian = add(new BoolSetting("obsidian", "Obsidian", "Count obsidian.", true));
    public final BoolSetting crystals = add(new BoolSetting("crystals", "End crystals", "Count end crystals.", true));
    public final BoolSetting totems = add(new BoolSetting("totems", "Totems", "Count totems of undying (whole inventory including offhand).", true));
    public final BoolSetting gapples = add(new BoolSetting("gapples", "Golden apples", "Count golden apples.", false));
    public final BoolSetting xp = add(new BoolSetting("xp", "XP bottles", "Count bottles o' enchanting.", false));
    public final NumberSetting lowTotems = add(new NumberSetting("lowTotems", "Low totem color", "Totem count turns yellow at this many or fewer, red at 0.", 2, 0, 10, 1, ""));
    public final NumberSetting interval = add(new NumberSetting("interval", "Update interval", "Ticks between inventory scans.", 5, 1, 20, 1, " ticks"));
    private int tick;
    private ItemStack sObs, sCry, sTot, sGap, sXp;

    public ItemCounters() {
        super("item_counters", "Item Counters", "Counts of obsidian, crystals, totems and more.", Category.COMBAT, Anchor.BOTTOM_RIGHT, 6, 80, false);
    }
    @Override protected void onDisable() { entries = List.of(); }
    @Override public void onWorldChange() { entries = List.of(); }

    private void stacks() {
        if (sObs != null) return;
        sObs = new ItemStack(Items.OBSIDIAN); sCry = new ItemStack(Items.END_CRYSTAL); sTot = new ItemStack(Items.TOTEM_OF_UNDYING);
        sGap = new ItemStack(Items.GOLDEN_APPLE); sXp = new ItemStack(Items.EXPERIENCE_BOTTLE);
    }

    @Override protected List<Entry> sample() {
        stacks();
        List<Entry> l = new ArrayList<>();
        if (obsidian.on()) l.add(new Entry(sObs, "128", 0));
        if (crystals.on()) l.add(new Entry(sCry, "12", 0));
        if (totems.on()) l.add(new Entry(sTot, "4", 0xFF5FD38D));
        if (gapples.on()) l.add(new Entry(sGap, "6", 0));
        if (xp.on()) l.add(new Entry(sXp, "64", 0));
        return l;
    }

    @Override public void onTick() {
        if (++tick % interval.i() != 0) return;
        if (!McUtil.inWorld()) { entries = List.of(); return; }
        stacks();
        Minecraft mc = Minecraft.getInstance();
        List<Entry> l = new ArrayList<>(5);
        add(l, obsidian.on(), sObs, Items.OBSIDIAN, mc, false);
        add(l, crystals.on(), sCry, Items.END_CRYSTAL, mc, false);
        add(l, totems.on(), sTot, Items.TOTEM_OF_UNDYING, mc, true);
        add(l, gapples.on(), sGap, Items.GOLDEN_APPLE, mc, false);
        add(l, xp.on(), sXp, Items.EXPERIENCE_BOTTLE, mc, false);
        entries = l;
    }

    private void add(List<Entry> l, boolean on, ItemStack icon, Item item, Minecraft mc, boolean warn) {
        if (!on) return;
        int n = McUtil.count(mc.player, item);
        int color = 0;
        if (warn) color = n == 0 ? 0xFFFF5C6C : n <= lowTotems.i() ? 0xFFF2C14E : 0xFF5FD38D;
        l.add(new Entry(icon, String.valueOf(n), color));
    }
}
