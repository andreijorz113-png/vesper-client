package dev.vesper.modules;

import dev.vesper.core.Category;
import dev.vesper.core.setting.BoolSetting;
import dev.vesper.hud.TextHudModule;
import dev.vesper.mc.McUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerInfo;

import java.util.ArrayList;
import java.util.List;

public final class InfoHud extends TextHudModule {
    public final BoolSetting fps = add(new BoolSetting("fps", "FPS", "Show frames per second.", true));
    public final BoolSetting ping = add(new BoolSetting("ping", "Ping", "Show your latency to the server.", true));
    public final BoolSetting server = add(new BoolSetting("server", "Server", "Show the server address.", true));
    private int tick;

    public InfoHud() {
        super("info", "Info", "FPS, ping and server address.", Category.QOL, Anchor.TOP_LEFT, 6, 6, false);
    }
    @Override protected void onDisable() { lines = List.of(); }

    @Override protected List<Line> sample() {
        List<Line> l = new ArrayList<>();
        if (fps.on()) l.add(new Line("FPS 240", 0xFF5FD38D));
        if (ping.on()) l.add(new Line("Ping 42ms", 0xFF5FD38D));
        if (server.on()) l.add(new Line("play.example.net", 0xFF8C8CA0));
        return l;
    }

    @Override public void onTick() {
        if (++tick % 5 != 0) return;
        Minecraft mc = Minecraft.getInstance();
        if (!McUtil.inWorld()) { lines = List.of(); return; }
        List<Line> l = new ArrayList<>(3);
        if (fps.on()) { int f = mc.getFps(); l.add(new Line("FPS " + f, f >= 60 ? 0xFF5FD38D : f >= 30 ? 0xFFF2C14E : 0xFFFF5C6C)); }
        if (ping.on()) {
            PlayerInfo info = mc.getConnection() == null ? null : mc.getConnection().getPlayerInfo(mc.player.getUUID());
            if (info != null) { int p = info.getLatency(); l.add(new Line("Ping " + p + "ms", p <= 80 ? 0xFF5FD38D : p <= 160 ? 0xFFF2C14E : 0xFFFF5C6C)); }
        }
        if (server.on()) l.add(new Line(mc.getCurrentServer() == null ? "Singleplayer" : mc.getCurrentServer().ip, 0xFF8C8CA0));
        lines = l;
    }
}
