package dev.vesper.modules;

import dev.vesper.core.Category;
import dev.vesper.core.Module;
import dev.vesper.core.setting.*;
import dev.vesper.render.ParticleClass;

/**
 * Filters particles as the game creates them (via ParticleEngineMixin), so dropped particles cost nothing to simulate or draw.
 * Each category keeps a percentage of its particles. Presets fill the sliders; editing a slider switches to Custom.
 */
public final class ParticleControl extends Module {
    public static volatile ParticleControl INSTANCE;

    public final ModeSetting preset = add(new ModeSetting("preset", "Preset", "Vanilla keeps everything. Reduced and Minimal thin out clutter. Moving a slider switches to Custom.", "Vanilla", "Vanilla", "Reduced", "Minimal", "Custom"));
    public final NumberSetting general = add(new NumberSetting("general", "General particles", "Percent kept: flames, dust, block breaking and everything not listed below.", 100, 0, 100, 5, "%"));
    public final NumberSetting explosion = add(new NumberSetting("explosion", "Explosion particles", "Percent kept: explosions, poofs, fireworks.", 100, 0, 100, 5, "%"));
    public final NumberSetting ambient = add(new NumberSetting("ambient", "Ambient particles", "Percent kept: smoke, ash, bubbles, spores, rain splashes, potion swirls.", 100, 0, 100, 5, "%"));
    public final NumberSetting crit = add(new NumberSetting("crit", "Critical-hit particles", "Percent kept: crit and enchanted-hit stars.", 100, 0, 100, 5, "%"));
    public final NumberSetting combat = add(new NumberSetting("combat", "Combat effects", "Percent kept: sweep attacks, damage indicators, totem pops, hearts.", 100, 0, 100, 5, "%"));
    public final BoolSetting keepTotem = add(new BoolSetting("keepTotem", "Always keep totem pops", "Never filter the totem-of-undying particles, even at low settings, so pops stay visible.", true));

    private String lastPreset;

    public ParticleControl() {
        super("particle_control", "Particle Control", "Keep a percentage of each kind of particle to reduce clutter and lag.", Category.VISUAL, -1, false);
    }

    @Override protected void onEnable() { INSTANCE = this; }
    @Override protected void onDisable() { if (INSTANCE == this) INSTANCE = null; }

    @Override public void onTick() {
        if (lastPreset == null) lastPreset = preset.get();
        if (!preset.get().equals(lastPreset)) {
            lastPreset = preset.get();
            switch (lastPreset) {
                case "Vanilla" -> set(100, 100, 100, 100, 100);
                case "Reduced" -> set(60, 50, 40, 100, 100);
                case "Minimal" -> set(15, 25, 0, 60, 60);
                default -> {}
            }
        } else if (!preset.is("Custom") && !matches(preset.get())) {
            preset.set("Custom"); lastPreset = "Custom";
        }
    }

    private boolean matches(String p) {
        int[] v = switch (p) { case "Vanilla" -> new int[]{100, 100, 100, 100, 100}; case "Reduced" -> new int[]{60, 50, 40, 100, 100}; case "Minimal" -> new int[]{15, 25, 0, 60, 60}; default -> null; };
        return v != null && general.i() == v[0] && explosion.i() == v[1] && ambient.i() == v[2] && crit.i() == v[3] && combat.i() == v[4];
    }

    private void set(int g, int e, int a, int c, int cb) { general.set((double) g); explosion.set((double) e); ambient.set((double) a); crit.set((double) c); combat.set((double) cb); }

    /** Called by the mixin for every particle the game wants to create. */
    public boolean shouldDrop(String path) {
        ParticleClass cls = ParticleClass.of(path);
        if (keepTotem.on() && path.equals("totem_of_undying")) return false;
        int keep = switch (cls) { case EXPLOSION -> explosion.i(); case CRIT -> crit.i(); case COMBAT -> combat.i(); case AMBIENT -> ambient.i(); default -> general.i(); };
        return ParticleClass.shouldDrop(keep, Math.random());
    }
}
