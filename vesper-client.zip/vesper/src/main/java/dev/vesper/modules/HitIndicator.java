package dev.vesper.modules;

import dev.vesper.core.Category;
import dev.vesper.core.Module;
import dev.vesper.core.setting.*;
import dev.vesper.hud.ScreenOverlay;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.EntityHitResult;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Hit marker and floating damage number at the crosshair. A "hit" is detected when the living entity under your
 * crosshair loses health, so damage from other sources to the same target can also trigger it.
 */
public final class HitIndicator extends Module implements ScreenOverlay {
    public final BoolSetting marker = add(new BoolSetting("marker", "Hit marker", "Four small ticks around the crosshair when the target loses health.", true));
    public final BoolSetting numbers = add(new BoolSetting("numbers", "Damage numbers", "Show how much health the target lost.", true));
    public final ColorSetting color = add(new ColorSetting("color", "Marker color", "Color of the hit marker.", 0xFFFFFFFF));
    public final ColorSetting numberColor = add(new ColorSetting("numberColor", "Number color", "Color of damage numbers.", 0xFFFF5C6C), () -> numbers.on());
    public final NumberSetting size = add(new NumberSetting("size", "Marker size", "Length of the marker ticks.", 4, 2, 10, 1, "px"), () -> marker.on());
    public final NumberSetting duration = add(new NumberSetting("duration", "Duration", "How long the effect lasts.", 0.45, 0.15, 1.5, 0.05, "s"));

    private final Map<Integer, Float> hp = new HashMap<>();
    private int hitAge = 999;
    private float lastDamage;

    public HitIndicator() {
        super("hit_indicator", "Hit Indicator", "Hit marker and damage numbers at the crosshair.", Category.VISUAL, -1, false);
    }

    @Override protected void onDisable() { hp.clear(); hitAge = 999; }
    @Override public void onWorldChange() { hp.clear(); hitAge = 999; }

    @Override public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        hitAge++;
        if (mc.player == null) return;
        if (mc.hitResult instanceof EntityHitResult r && r.getEntity() instanceof LivingEntity le && le != mc.player) {
            float now = le.getHealth() + le.getAbsorptionAmount();
            Float prev = hp.put(le.getId(), now);
            if (prev != null && now < prev - 0.01f) { lastDamage = prev - now; hitAge = 0; }
            if (hp.size() > 24) { hp.clear(); hp.put(le.getId(), now); }
        }
    }

    @Override public void renderOverlay(GuiGraphics g) {
        int max = Math.max(1, (int) (duration.get() * 20));
        if (hitAge > max) return;
        boolean still = dev.vesper.VesperClient.settings().reducedMotion.on();
        float p = hitAge / (float) max, a = 1f - p * p;
        int cx = g.guiWidth() / 2, cy = g.guiHeight() / 2;
        if (marker.on()) {
            int c = (Math.round(255 * a) << 24) | (color.argb() & 0xFFFFFF), s = size.i(), gap = 3 + (still ? 0 : Math.round(p * 3));
            for (int i = 1; i <= s; i++) {
                g.fill(cx - gap - i, cy - gap - i, cx - gap - i + 1, cy - gap - i + 1, c);
                g.fill(cx + gap + i - 1, cy - gap - i, cx + gap + i, cy - gap - i + 1, c);
                g.fill(cx - gap - i, cy + gap + i - 1, cx - gap - i + 1, cy + gap + i, c);
                g.fill(cx + gap + i - 1, cy + gap + i - 1, cx + gap + i, cy + gap + i, c);
            }
        }
        if (numbers.on()) {
            String t = String.format(Locale.ROOT, "-%.1f", lastDamage);
            int rise = still ? 0 : Math.round(p * 10);
            var f = Minecraft.getInstance().font;
            g.drawString(f, t, cx - f.width(t) / 2, cy + 12 - rise, (Math.round(255 * a) << 24) | (numberColor.argb() & 0xFFFFFF), true);
        }
    }
}
