package dev.vesper.mixin;

import dev.vesper.modules.ParticleControl;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleEngine;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.registries.BuiltInRegistries;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Lets ParticleControl drop particles before they are created. require = 0: if the target ever changes, the filter just goes inactive instead of crashing the game. */
@Mixin(ParticleEngine.class)
public abstract class ParticleEngineMixin {
    @Inject(method = "createParticle", at = @At("HEAD"), cancellable = true, require = 0)
    private void vesper$filter(ParticleOptions options, double x, double y, double z, double vx, double vy, double vz, CallbackInfoReturnable<Particle> cir) {
        ParticleControl pc = ParticleControl.INSTANCE;
        if (pc == null) return;
        var key = BuiltInRegistries.PARTICLE_TYPE.getKey(options.getType());
        if (key != null && pc.shouldDrop(key.getPath())) cir.setReturnValue(null);
    }
}
