package dev.vesper.mc;

import dev.vesper.calc.ExplosionMath;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.core.Holder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.phys.Vec3;

/** Small, allocation-light helpers for reading game state. */
public final class McUtil {
    private McUtil() {}

    public static final EquipmentSlot[] ARMOR = {
        EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET };

    public static Minecraft mc() { return Minecraft.getInstance(); }

    public static boolean inWorld() { Minecraft m = mc(); return m.player != null && m.level != null; }

    /** Summed enchantment protection factor vs explosions (Protection 1/level, Blast Protection 2/level). Cap applied in ExplosionMath. */
    public static int explosionEpf(LivingEntity e) {
        int epf = 0;
        for (EquipmentSlot slot : ARMOR) {
            ItemEnchantments ench = e.getItemBySlot(slot).getEnchantments();
            for (Object2IntMap.Entry<Holder<Enchantment>> en : ench.entrySet()) {
                Holder<Enchantment> h = en.getKey();
                if (h.is(Enchantments.PROTECTION)) epf += en.getIntValue();
                else if (h.is(Enchantments.BLAST_PROTECTION)) epf += 2 * en.getIntValue();
            }
        }
        return epf;
    }

    public static int resistanceAmplifier(LivingEntity e) {
        for (MobEffectInstance inst : e.getActiveEffects())
            if ("effect.minecraft.resistance".equals(inst.getDescriptionId())) return inst.getAmplifier();
        return -1;
    }

    public static ExplosionMath.Defense defense(LivingEntity e) {
        return new ExplosionMath.Defense(
            e.getArmorValue(),
            (float) e.getAttributeValue(Attributes.ARMOR_TOUGHNESS),
            explosionEpf(e),
            resistanceAmplifier(e),
            e.getAbsorptionAmount());
    }

    public static ExplosionMath.Difficulty difficulty() {
        Minecraft m = mc();
        return m.level == null ? ExplosionMath.Difficulty.NORMAL : ExplosionMath.Difficulty.parse(m.level.getDifficulty().name());
    }

    /** Durability remaining 0..100, or -1 for items without durability. */
    public static int durabilityPercent(ItemStack s) {
        if (s.isEmpty() || !s.isDamageableItem()) return -1;
        int max = s.getMaxDamage();
        return Math.round(100f * (max - s.getDamageValue()) / max);
    }

    public static int count(Player p, Item item) {
        int n = 0;
        var inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (s.is(item)) n += s.getCount();
        }
        return n;
    }

    public static boolean holdsTotem(LivingEntity e) {
        return e.getMainHandItem().is(Items.TOTEM_OF_UNDYING) || e.getOffhandItem().is(Items.TOTEM_OF_UNDYING);
    }

    public static float effectiveHealth(LivingEntity e) { return e.getHealth() + e.getAbsorptionAmount(); }

    /** Nearest/lowest-health/crosshair-aligned other player within range. */
    public static AbstractClientPlayer target(double range, String priority) {
        Minecraft m = mc();
        if (m.player == null || m.level == null) return null;
        AbstractClientPlayer best = null;
        double bestScore = Double.MAX_VALUE;
        Vec3 look = m.player.getLookAngle();
        for (AbstractClientPlayer p : m.level.players()) {
            if (p == m.player || p.isSpectator() || p.isRemoved() || !p.isAlive()) continue;
            double d = m.player.distanceTo(p);
            if (d > range) continue;
            double score;
            switch (priority) {
                case "Lowest health" -> score = effectiveHealth(p);
                case "Crosshair" -> {
                    Vec3 dir = p.getEyePosition().subtract(m.player.getEyePosition()).normalize();
                    score = -look.dot(dir);
                }
                default -> score = d;
            }
            if (score < bestScore) { bestScore = score; best = p; }
        }
        return best;
    }

    public static int mixColor(int from, int to, float t) {
        int a = (int) (((from >>> 24) & 255) * (1 - t) + ((to >>> 24) & 255) * t);
        int r = (int) (((from >> 16) & 255) * (1 - t) + ((to >> 16) & 255) * t);
        int g = (int) (((from >> 8) & 255) * (1 - t) + ((to >> 8) & 255) * t);
        int b = (int) ((from & 255) * (1 - t) + (to & 255) * t);
        return a << 24 | r << 16 | g << 8 | b;
    }

    /** Red (0%) -> yellow -> green (100%). */
    public static int healthColor(float fraction) {
        fraction = Math.max(0, Math.min(1, fraction));
        return fraction < 0.5f ? mixColor(0xFFFF5C6C, 0xFFF2C14E, fraction * 2) : mixColor(0xFFF2C14E, 0xFF5FD38D, (fraction - 0.5f) * 2);
    }
}
