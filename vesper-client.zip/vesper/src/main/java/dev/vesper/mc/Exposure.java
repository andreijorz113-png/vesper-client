package dev.vesper.mc;

import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Fraction (0..1) of an entity's bounding box visible from an explosion center, sampled the same way
 * vanilla does (grid of rays against block collision). Costs ~45 ray casts for a player, so callers must cache.
 * Uses the client's view of the world; blocks the client has not loaded count as air.
 */
public final class Exposure {
    private Exposure() {}

    public static double of(Level level, Vec3 center, Entity entity) {
        AABB box = entity.getBoundingBox();
        double dx = 1.0 / ((box.maxX - box.minX) * 2.0 + 1.0);
        double dy = 1.0 / ((box.maxY - box.minY) * 2.0 + 1.0);
        double dz = 1.0 / ((box.maxZ - box.minZ) * 2.0 + 1.0);
        double offX = (1.0 - Math.floor(1.0 / dx) * dx) / 2.0;
        double offZ = (1.0 - Math.floor(1.0 / dz) * dz) / 2.0;
        if (dx < 0 || dy < 0 || dz < 0) return 0;
        int hit = 0, total = 0;
        for (double x = 0; x <= 1.0; x += dx) {
            for (double y = 0; y <= 1.0; y += dy) {
                for (double z = 0; z <= 1.0; z += dz) {
                    Vec3 p = new Vec3(
                        Mth.lerp(x, box.minX, box.maxX) + offX,
                        Mth.lerp(y, box.minY, box.maxY),
                        Mth.lerp(z, box.minZ, box.maxZ) + offZ);
                    if (level.clip(new ClipContext(p, center, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, entity))
                            .getType() == HitResult.Type.MISS) hit++;
                    total++;
                }
            }
        }
        return total == 0 ? 0 : (double) hit / total;
    }
}
