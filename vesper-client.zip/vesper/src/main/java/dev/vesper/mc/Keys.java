package dev.vesper.mc;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

/** All raw-input access lives here. If a Minecraft update breaks window/input APIs, fix them in this file only. */
public final class Keys {
    private Keys() {}

    private static long window() { return Minecraft.getInstance().getWindow().handle(); }

    public static boolean isDown(int key) {
        return key > 0 && GLFW.glfwGetKey(window(), key) == GLFW.GLFW_PRESS;
    }

    public static boolean mouseDown(int button) {
        return GLFW.glfwGetMouseButton(window(), button) == GLFW.GLFW_PRESS;
    }

    public static String name(int key) {
        if (key <= 0) return "None";
        try {
            return InputConstants.Type.KEYSYM.getOrCreate(key).getDisplayName().getString().toUpperCase(java.util.Locale.ROOT);
        } catch (RuntimeException e) {
            return "KEY " + key;
        }
    }
}
