package dev.vesper.mc;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.entity.player.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

/**
 * Infers totem pops: a player who held a totem and now does not, while alive and just hurt.
 * This is a heuristic (it can misfire if someone swaps items on the exact tick they are hit).
 * Runs only while at least one module is subscribed.
 */
public final class PopTracker {
    private PopTracker() {}

    public record Pop(UUID id, String name, boolean self, int count, double distance) {}

    private static final CopyOnWriteArrayList<Consumer<Pop>> SUBS = new CopyOnWriteArrayList<>();
    private static final Map<UUID, Boolean> HAD = new HashMap<>();
    private static final Map<UUID, Integer> COUNTS = new HashMap<>();

    public static void subscribe(Consumer<Pop> c) { if (!SUBS.contains(c)) SUBS.add(c); }
    public static void unsubscribe(Consumer<Pop> c) { SUBS.remove(c); if (SUBS.isEmpty()) reset(); }
    public static void reset() { HAD.clear(); COUNTS.clear(); }

    public static void tick() {
        if (SUBS.isEmpty() || !McUtil.inWorld()) return;
        Minecraft mc = Minecraft.getInstance();
        check(mc.player, true, 0);
        for (AbstractClientPlayer p : mc.level.players()) {
            if (p == mc.player || p.isSpectator()) continue;
            double d = mc.player.distanceTo(p);
            if (d <= 64) check(p, false, d);
        }
    }

    private static void check(Player p, boolean self, double dist) {
        boolean has = McUtil.holdsTotem(p);
        Boolean prev = HAD.put(p.getUUID(), has);
        if (Boolean.TRUE.equals(prev) && !has && p.isAlive() && p.hurtTime > 0) {
            int n = COUNTS.merge(p.getUUID(), 1, Integer::sum);
            Pop pop = new Pop(p.getUUID(), p.getName().getString(), self, n, dist);
            for (Consumer<Pop> c : SUBS) c.accept(pop);
        }
    }
}
