package dev.vesper.core.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public final class NumberSetting extends Setting<Double> {
    public final double min, max, step;
    public final String unit;

    public NumberSetting(String id, String name, String description, double def, double min, double max, double step, String unit) {
        super(id, name, description, def);
        this.min = min; this.max = max; this.step = step; this.unit = unit;
        this.value = sanitize(def);
    }

    @Override protected Double sanitize(Double v) {
        double x = (v == null || v.isNaN() || v.isInfinite()) ? def : v;
        if (step > 0) x = Math.round((x - min) / step) * step + min;
        x = Math.max(min, Math.min(max, x));
        return Math.round(x * 1e6) / 1e6;
    }
    @Override public JsonElement toJson() { return new JsonPrimitive(value); }
    @Override public void fromJson(JsonElement e) {
        if (e == null || !e.isJsonPrimitive() || !e.getAsJsonPrimitive().isNumber())
            throw new IllegalArgumentException("expected a number between " + min + " and " + max);
        double v = e.getAsDouble();
        if (v < min || v > max) throw new IllegalArgumentException(v + " is outside " + min + ".." + max);
        set(v);
    }
    public float f() { return value.floatValue(); }
    public int i() { return (int) Math.round(value); }
    public double fraction() { return (value - min) / (max - min); }
    public void setFraction(double f) { set(min + Math.max(0, Math.min(1, f)) * (max - min)); }
}
