package dev.vesper.core.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

/** Short free text (IDs, names). Control characters are stripped and the length is capped. */
public final class StringSetting extends Setting<String> {
    public final int maxLength;
    public final String hint;

    public StringSetting(String id, String name, String description, String def, int maxLength, String hint) {
        super(id, name, description, def);
        this.maxLength = maxLength; this.hint = hint;
        this.value = sanitize(def);
    }
    @Override protected String sanitize(String v) {
        if (v == null) return def == null ? "" : def;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < v.length() && sb.length() < maxLength; i++) {
            char c = v.charAt(i);
            if (c >= 32 && c != 127) sb.append(c);
        }
        return sb.toString();
    }
    @Override public JsonElement toJson() { return new JsonPrimitive(value); }
    @Override public void fromJson(JsonElement e) {
        if (e == null || !e.isJsonPrimitive() || !e.getAsJsonPrimitive().isString())
            throw new IllegalArgumentException("expected text");
        if (e.getAsString().length() > maxLength) throw new IllegalArgumentException("longer than " + maxLength + " characters");
        set(e.getAsString());
    }
    public String text() { return value; }
}
