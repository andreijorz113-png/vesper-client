package dev.vesper.core.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.util.List;

public final class ModeSetting extends Setting<String> {
    public final List<String> options;

    public ModeSetting(String id, String name, String description, String def, String... options) {
        super(id, name, description, def);
        this.options = List.of(options);
        if (!this.options.contains(def)) throw new IllegalArgumentException("default not in options: " + id);
    }
    @Override protected String sanitize(String v) { return options.contains(v) ? v : def; }
    @Override public JsonElement toJson() { return new JsonPrimitive(value); }
    @Override public void fromJson(JsonElement e) {
        if (e == null || !e.isJsonPrimitive() || !e.getAsJsonPrimitive().isString() || !options.contains(e.getAsString()))
            throw new IllegalArgumentException("expected one of " + options);
        set(e.getAsString());
    }
    public boolean is(String o) { return value.equals(o); }
    public void cycle(int dir) {
        int i = options.indexOf(value);
        set(options.get(Math.floorMod(i + dir, options.size())));
    }
}
