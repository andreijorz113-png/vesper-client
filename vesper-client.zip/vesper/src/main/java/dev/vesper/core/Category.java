package dev.vesper.core;

public enum Category {
    COMBAT("Combat"), QOL("QoL"), VISUAL("Visual"), CLIENT("Client");

    public final String label;
    Category(String label) { this.label = label; }
}
