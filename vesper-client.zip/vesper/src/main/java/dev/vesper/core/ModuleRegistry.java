package dev.vesper.core;

import java.util.List;

/** What the config system needs to know about the client. */
public interface ModuleRegistry {
    List<Module> all();
    List<String> favorites();
    List<String> recent();
}
