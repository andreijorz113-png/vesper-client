package dev.vesper.core.setting;

import com.google.gson.JsonElement;
import java.util.Objects;
import java.util.function.BooleanSupplier;

/** A persisted, validated module option. fromJson throws IllegalArgumentException on bad input. */
public abstract class Setting<T> {
    private static Runnable changeHook = () -> {};
    public static void setChangeHook(Runnable r) { changeHook = r == null ? () -> {} : r; }

    public static void changeNotify() { changeHook.run(); }

    public final String id, name, description;
    protected T value;
    protected final T def;
    private BooleanSupplier visible = () -> true;

    protected Setting(String id, String name, String description, T def) {
        this.id = id; this.name = name; this.description = description;
        this.def = def; this.value = def;
    }

    public T get() { return value; }
    public T defaultValue() { return def; }

    public void set(T v) {
        T nv = sanitize(v);
        if (!Objects.equals(nv, value)) { value = nv; changeHook.run(); }
    }

    public void reset() { set(def); }
    /** False for settings that are buttons or other non-data controls (not saved or exported). */
    public boolean persistent() { return true; }
    public boolean isDefault() { return Objects.equals(value, def); }

    public Setting<T> visibleWhen(BooleanSupplier s) { this.visible = s; return this; }
    public boolean isVisible() { return visible.getAsBoolean(); }

    protected abstract T sanitize(T v);
    public abstract JsonElement toJson();
    public abstract void fromJson(JsonElement e);
}
