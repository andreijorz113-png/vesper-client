package dev.vesper.core.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

/** ARGB color, stored as "#AARRGGBB". */
public final class ColorSetting extends Setting<Integer> {
    public ColorSetting(String id, String name, String description, int argb) { super(id, name, description, argb); }
    @Override protected Integer sanitize(Integer v) { return v == null ? def : v; }
    @Override public JsonElement toJson() { return new JsonPrimitive(String.format("#%08X", value)); }
    @Override public void fromJson(JsonElement e) {
        if (e == null || !e.isJsonPrimitive() || !e.getAsJsonPrimitive().isString())
            throw new IllegalArgumentException("expected a color like #FF33AAFF");
        String s = e.getAsString().trim();
        if (s.startsWith("#")) s = s.substring(1);
        try {
            if (s.length() == 6) set(0xFF000000 | (int) Long.parseLong(s, 16));
            else if (s.length() == 8) set((int) Long.parseLong(s, 16));
            else throw new NumberFormatException();
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("'" + e.getAsString() + "' is not a valid #RRGGBB or #AARRGGBB color");
        }
    }
    public int argb() { return value; }
}
