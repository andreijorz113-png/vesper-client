package dev.vesper.core.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public final class BoolSetting extends Setting<Boolean> {
    public BoolSetting(String id, String name, String description, boolean def) { super(id, name, description, def); }
    @Override protected Boolean sanitize(Boolean v) { return v != null && v; }
    @Override public JsonElement toJson() { return new JsonPrimitive(value); }
    @Override public void fromJson(JsonElement e) {
        if (e == null || !e.isJsonPrimitive() || !e.getAsJsonPrimitive().isBoolean())
            throw new IllegalArgumentException("expected true/false");
        set(e.getAsBoolean());
    }
    public boolean on() { return value; }
}
