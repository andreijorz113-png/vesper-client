package dev.vesper.core;

import com.google.gson.JsonObject;
import dev.vesper.core.setting.Setting;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Base class for every feature. Contains no Minecraft types so it can be unit-tested.
 * Lifecycle: onEnable/onDisable are called exactly once per state change; onTick only while enabled.
 */
public abstract class Module {
    public final String id, name, description;
    public final Category category;
    private final List<Setting<?>> settings = new ArrayList<>();
    private boolean enabled;
    private int key;
    private final int defaultKey;
    private final boolean defaultEnabled;
    private int consecutiveErrors;

    protected Module(String id, String name, String description, Category category, int defaultKey, boolean defaultEnabled) {
        this.id = id; this.name = name; this.description = description; this.category = category;
        this.defaultKey = defaultKey; this.key = defaultKey; this.defaultEnabled = defaultEnabled;
    }

    protected <S extends Setting<?>> S add(S s) {
        for (Setting<?> o : settings) if (o.id.equals(s.id)) throw new IllegalStateException("duplicate setting " + id + "." + s.id);
        settings.add(s);
        return s;
    }

    /** Adds a setting that is only shown while {@code visible} returns true. */
    protected <S extends Setting<?>> S add(S s, java.util.function.BooleanSupplier visible) {
        add(s);
        s.visibleWhen(visible);
        return s;
    }

    public List<Setting<?>> settings() { return Collections.unmodifiableList(settings); }

    // ---- state ----
    public boolean enabled() { return enabled; }
    public boolean canToggle() { return true; }

    public final void setEnabled(boolean v) {
        if (v == enabled || (!v && !canToggle())) return;
        enabled = v;
        try {
            if (v) onEnable(); else onDisable();
        } catch (RuntimeException e) {
            enabled = false;
            throw e;
        }
        Setting.changeNotify();
    }
    public final void toggle() { setEnabled(!enabled); }

    public int key() { return key; }
    public void setKey(int k) { if (k != key) { key = k; Setting.changeNotify(); } }
    public int defaultKey() { return defaultKey; }
    /** Invoked when this module's keybind is pressed in-game (no screen open). */
    public void onKeyPressed() { toggle(); }

    // ---- hooks ----
    protected void onEnable() {}
    protected void onDisable() {}
    public void onTick() {}
    /** World/dimension changed or disconnected: drop any cached world state. */
    public void onWorldChange() {}

    // ---- error isolation ----
    public int noteError() { return ++consecutiveErrors; }
    public void noteOk() { consecutiveErrors = 0; }

    // ---- persistence extension points ----
    public void extraToJson(JsonObject o) {}
    public void extraFromJson(JsonObject o) {}
    protected void extraReset() {}

    public final void resetToDefaults() {
        for (Setting<?> s : settings) s.reset();
        key = defaultKey;
        extraReset();
        if (!canToggle()) { if (!enabled) setEnabled(true); }
        else setEnabled(defaultEnabled);
    }
}
