package dev.vesper.core.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;

/** A button in a module's settings. Not saved, not exported. */
public final class ActionSetting extends Setting<Boolean> {
    private final Runnable action;
    public final String label;

    public ActionSetting(String id, String name, String description, String label, Runnable action) {
        super(id, name, description, Boolean.FALSE);
        this.label = label; this.action = action;
    }
    @Override public boolean persistent() { return false; }
    @Override protected Boolean sanitize(Boolean v) { return Boolean.FALSE; }
    @Override public JsonElement toJson() { return JsonNull.INSTANCE; }
    @Override public void fromJson(JsonElement e) { /* never loaded */ }
    public void run() { action.run(); }
}
