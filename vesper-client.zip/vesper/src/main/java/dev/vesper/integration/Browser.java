package dev.vesper.integration;

import java.io.IOException;

/** Opens a URL in the user's default browser without needing java.awt.Desktop (unavailable in some launchers). */
public final class Browser {
    private Browser() {}

    public static boolean open(String url) {
        if (!url.startsWith("https://") && !url.startsWith("http://")) return false;
        String os = System.getProperty("os.name", "").toLowerCase();
        try {
            if (os.contains("win")) new ProcessBuilder("rundll32", "url.dll,FileProtocolHandler", url).start();
            else if (os.contains("mac")) new ProcessBuilder("open", url).start();
            else new ProcessBuilder("xdg-open", url).start();
            return true;
        } catch (IOException e) { return false; }
    }
}
