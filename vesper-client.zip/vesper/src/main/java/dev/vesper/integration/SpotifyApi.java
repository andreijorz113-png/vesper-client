package dev.vesper.integration;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.StringJoiner;

/** Pure helpers for the Spotify Web API: PKCE and response parsing. (Network code lives in SpotifyService.) */
public final class SpotifyApi {
    private SpotifyApi() {}

    public static final String REDIRECT_URI = "http://127.0.0.1:8888/callback";
    public static final String SCOPES = "user-read-currently-playing user-read-playback-state";

    public record Track(String title, String artist, long durationMs, long progressMs, boolean playing) {}

    // ------------------------------------------------------------------ PKCE (RFC 7636)
    public static String newVerifier() {
        byte[] b = new byte[64];
        new SecureRandom().nextBytes(b);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(b);
    }

    public static String challenge(String verifier) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII));
            return Base64.getUrlEncoder().withoutPadding().encodeToString(d);
        } catch (NoSuchAlgorithmException e) { throw new IllegalStateException(e); }
    }

    public static String authorizeUrl(String clientId, String challenge, String state) {
        StringJoiner q = new StringJoiner("&");
        q.add("response_type=code").add("client_id=" + enc(clientId)).add("scope=" + enc(SCOPES))
         .add("redirect_uri=" + enc(REDIRECT_URI)).add("code_challenge_method=S256")
         .add("code_challenge=" + enc(challenge)).add("state=" + enc(state));
        return "https://accounts.spotify.com/authorize?" + q;
    }

    public static String enc(String s) { return java.net.URLEncoder.encode(s, StandardCharsets.UTF_8); }

    // ------------------------------------------------------------------ parsing
    /** Parses GET /v1/me/player/currently-playing. Returns null when nothing (or a non-track such as an ad) is playing. */
    public static Track parseCurrentlyPlaying(String json) {
        try {
            JsonElement root = JsonParser.parseString(json);
            if (!root.isJsonObject()) return null;
            JsonObject o = root.getAsJsonObject();
            if (!o.has("item") || o.get("item").isJsonNull()) return null;
            JsonObject item = o.getAsJsonObject("item");
            String title = item.has("name") ? item.get("name").getAsString() : "";
            if (title.isEmpty()) return null;
            StringJoiner artists = new StringJoiner(", ");
            if (item.has("artists") && item.get("artists").isJsonArray()) {
                JsonArray arr = item.getAsJsonArray("artists");
                for (JsonElement a : arr) if (a.isJsonObject() && a.getAsJsonObject().has("name")) artists.add(a.getAsJsonObject().get("name").getAsString());
            } else if (item.has("show") && item.get("show").isJsonObject() && item.getAsJsonObject("show").has("name")) {
                artists.add(item.getAsJsonObject("show").get("name").getAsString());   // podcast episode
            }
            long dur = item.has("duration_ms") ? item.get("duration_ms").getAsLong() : 0;
            long prog = o.has("progress_ms") && !o.get("progress_ms").isJsonNull() ? o.get("progress_ms").getAsLong() : 0;
            boolean playing = o.has("is_playing") && o.get("is_playing").getAsBoolean();
            return new Track(title, artists.toString(), dur, Math.min(prog, dur > 0 ? dur : prog), playing);
        } catch (JsonParseException | IllegalStateException | UnsupportedOperationException | ClassCastException e) {
            return null;
        }
    }

    /** Extracts "code" and "state" from a request line like "GET /callback?code=X&state=Y HTTP/1.1". Returns {code, state, error}. */
    public static String[] parseCallback(String requestLine) {
        String[] out = new String[3];
        if (requestLine == null) return out;
        String[] parts = requestLine.split(" ");
        if (parts.length < 2 || !parts[1].startsWith("/callback")) return out;
        int q = parts[1].indexOf('?');
        if (q < 0) return out;
        for (String kv : parts[1].substring(q + 1).split("&")) {
            int eq = kv.indexOf('=');
            if (eq < 0) continue;
            String k = kv.substring(0, eq), v = java.net.URLDecoder.decode(kv.substring(eq + 1), StandardCharsets.UTF_8);
            switch (k) { case "code" -> out[0] = v; case "state" -> out[1] = v; case "error" -> out[2] = v; default -> {} }
        }
        return out;
    }
}
