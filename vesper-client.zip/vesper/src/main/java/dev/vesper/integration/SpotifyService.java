package dev.vesper.integration;

import com.google.gson.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.net.*;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Duration;
import java.util.UUID;
import java.util.concurrent.*;

/**
 * Signs in with Spotify (Authorization Code + PKCE, so there is NO client secret) and polls the currently playing track.
 * The refresh token is stored only in <configDir>/spotify.json, never in profiles or exports. Tokens are never logged.
 */
public final class SpotifyService {
    private static final Logger LOG = LoggerFactory.getLogger("Vesper/Spotify");
    public enum Status { DISCONNECTED, WAITING_FOR_BROWSER, CONNECTED, ERROR }

    private final Path tokenFile;
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).build();
    private ScheduledExecutorService poller;
    private volatile ExecutorService authThread;

    private volatile Status status = Status.DISCONNECTED;
    private volatile String message = "";
    private volatile SpotifyApi.Track track;
    private volatile long trackFetchedAt;
    private volatile String clientId = "";
    private String accessToken, refreshToken;
    private long accessExpiresAt;
    private volatile long retryAfter;

    public SpotifyService(Path configDir) { this.tokenFile = configDir.resolve("spotify.json"); }

    public Status status() { return status; }
    public String message() { return message; }
    public SpotifyApi.Track track() { return track; }
    /** Progress extrapolated since the last poll so the bar moves smoothly. */
    public long progressNow() {
        SpotifyApi.Track t = track;
        if (t == null) return 0;
        long p = t.progressMs() + (t.playing() ? System.currentTimeMillis() - trackFetchedAt : 0);
        return t.durationMs() > 0 ? Math.min(p, t.durationMs()) : p;
    }

    // ------------------------------------------------------------------ lifecycle
    public synchronized void start(String clientId) {
        this.clientId = clientId == null ? "" : clientId.trim();
        loadTokens();
        if (poller != null) return;
        poller = Executors.newSingleThreadScheduledExecutor(r -> { Thread t = new Thread(r, "Vesper-Spotify"); t.setDaemon(true); return t; });
        poller.scheduleWithFixedDelay(this::pollSafe, 1, 4, TimeUnit.SECONDS);
        if (refreshToken != null) status = Status.CONNECTED;
    }

    public synchronized void stop() {
        if (poller != null) { poller.shutdownNow(); poller = null; }
        ExecutorService a = authThread;
        if (a != null) a.shutdownNow();
        track = null;
        if (status != Status.DISCONNECTED) status = refreshToken != null ? Status.CONNECTED : Status.DISCONNECTED;
    }

    public synchronized void disconnect() {
        refreshToken = null; accessToken = null; track = null;
        try { Files.deleteIfExists(tokenFile); } catch (IOException ignored) {}
        status = Status.DISCONNECTED; message = "Disconnected.";
    }

    public void setClientId(String id) { this.clientId = id == null ? "" : id.trim(); }

    // ------------------------------------------------------------------ sign-in
    public void connect() {
        if (clientId.isEmpty()) { fail("Enter your Spotify Client ID first (Integrations > Spotify)."); return; }
        if (status == Status.WAITING_FOR_BROWSER) return;
        ExecutorService ex = Executors.newSingleThreadExecutor(r -> { Thread t = new Thread(r, "Vesper-SpotifyAuth"); t.setDaemon(true); return t; });
        authThread = ex;
        status = Status.WAITING_FOR_BROWSER; message = "Finish signing in in your browser...";
        ex.submit(() -> {
            try { signIn(); }
            catch (Exception e) { fail("Sign-in failed: " + e.getMessage()); }
            finally { ex.shutdown(); }
        });
    }

    private void signIn() throws Exception {
        String verifier = SpotifyApi.newVerifier(), state = UUID.randomUUID().toString();
        try (ServerSocket server = new ServerSocket(8888, 1, InetAddress.getByName("127.0.0.1"))) {
            server.setSoTimeout(180_000);
            String url = SpotifyApi.authorizeUrl(clientId, SpotifyApi.challenge(verifier), state);
            if (!Browser.open(url)) throw new IOException("could not open your browser. Open this link manually: " + url);
            try (Socket s = server.accept()) {
                BufferedReader r = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
                String[] cb = SpotifyApi.parseCallback(r.readLine());
                boolean ok = cb[0] != null && state.equals(cb[1]);
                String body = ok ? "<h3>Vesper is connected to Spotify. You can close this tab.</h3>" : "<h3>Spotify sign-in did not complete. You can close this tab and try again.</h3>";
                s.getOutputStream().write(("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nConnection: close\r\nContent-Length: "
                    + body.getBytes(StandardCharsets.UTF_8).length + "\r\n\r\n" + body).getBytes(StandardCharsets.UTF_8));
                s.getOutputStream().flush();
                if (cb[2] != null) throw new IOException("Spotify said: " + cb[2]);
                if (!ok) throw new IOException("the sign-in response was invalid or did not match");
                exchange("grant_type=authorization_code&code=" + SpotifyApi.enc(cb[0]) + "&redirect_uri=" + SpotifyApi.enc(SpotifyApi.REDIRECT_URI)
                    + "&client_id=" + SpotifyApi.enc(clientId) + "&code_verifier=" + SpotifyApi.enc(verifier));
            }
        } catch (BindException e) {
            throw new IOException("port 8888 is in use. Close the other program using it and try again.");
        } catch (SocketTimeoutException e) {
            throw new IOException("timed out waiting for the browser. Try again.");
        }
        saveTokens();
        status = Status.CONNECTED; message = "Connected.";
    }

    /** Token endpoint call; fills access/refresh tokens. */
    private void exchange(String form) throws IOException, InterruptedException {
        HttpRequest req = HttpRequest.newBuilder(URI.create("https://accounts.spotify.com/api/token"))
            .header("Content-Type", "application/x-www-form-urlencoded").timeout(Duration.ofSeconds(10))
            .POST(HttpRequest.BodyPublishers.ofString(form)).build();
        HttpResponse<String> res = http.send(req, HttpResponse.BodyHandlers.ofString());
        if (res.statusCode() != 200) {
            String why = "HTTP " + res.statusCode();
            try { JsonObject o = JsonParser.parseString(res.body()).getAsJsonObject(); if (o.has("error_description")) why = o.get("error_description").getAsString(); } catch (RuntimeException ignored) {}
            throw new IOException(why);
        }
        JsonObject o = JsonParser.parseString(res.body()).getAsJsonObject();
        accessToken = o.get("access_token").getAsString();
        accessExpiresAt = System.currentTimeMillis() + (o.has("expires_in") ? o.get("expires_in").getAsLong() : 3600) * 1000L - 30_000;
        if (o.has("refresh_token")) refreshToken = o.get("refresh_token").getAsString();
    }

    // ------------------------------------------------------------------ polling
    private void pollSafe() {
        try { poll(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        catch (Exception e) { LOG.debug("poll failed: {}", e.toString()); }
    }

    private void poll() throws Exception {
        if (refreshToken == null || clientId.isEmpty() || System.currentTimeMillis() < retryAfter) return;
        if (accessToken == null || System.currentTimeMillis() >= accessExpiresAt) {
            try { exchange("grant_type=refresh_token&refresh_token=" + SpotifyApi.enc(refreshToken) + "&client_id=" + SpotifyApi.enc(clientId)); saveTokens(); }
            catch (IOException e) { fail("Spotify session expired. Click Connect again. (" + e.getMessage() + ")"); refreshToken = null; return; }
        }
        HttpRequest req = HttpRequest.newBuilder(URI.create("https://api.spotify.com/v1/me/player/currently-playing"))
            .header("Authorization", "Bearer " + accessToken).timeout(Duration.ofSeconds(8)).GET().build();
        HttpResponse<String> res = http.send(req, HttpResponse.BodyHandlers.ofString());
        switch (res.statusCode()) {
            case 200 -> { track = SpotifyApi.parseCurrentlyPlaying(res.body()); trackFetchedAt = System.currentTimeMillis(); status = Status.CONNECTED; message = ""; }
            case 204 -> { track = null; status = Status.CONNECTED; message = ""; }
            case 401 -> accessToken = null;
            case 429 -> retryAfter = System.currentTimeMillis() + res.headers().firstValueAsLong("Retry-After").orElse(10) * 1000L;
            default -> { status = Status.ERROR; message = "Spotify returned HTTP " + res.statusCode(); }
        }
    }

    private void fail(String msg) { status = Status.ERROR; message = msg; LOG.warn(msg); }

    // ------------------------------------------------------------------ token file
    private void loadTokens() {
        try {
            if (!Files.exists(tokenFile)) return;
            JsonObject o = JsonParser.parseString(Files.readString(tokenFile, StandardCharsets.UTF_8)).getAsJsonObject();
            if (o.has("clientId") && o.get("clientId").getAsString().equals(clientId) && o.has("refreshToken")) refreshToken = o.get("refreshToken").getAsString();
        } catch (IOException | RuntimeException e) { LOG.warn("Could not read spotify.json: {}", e.getMessage()); }
    }

    private void saveTokens() {
        try {
            Files.createDirectories(tokenFile.getParent());
            JsonObject o = new JsonObject();
            o.addProperty("clientId", clientId);
            o.addProperty("refreshToken", refreshToken);
            Files.writeString(tokenFile, o.toString(), StandardCharsets.UTF_8);
        } catch (IOException e) { LOG.warn("Could not save spotify.json: {}", e.getMessage()); }
    }
}
