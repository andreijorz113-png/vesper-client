package dev.vesper.integration;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.*;
import java.net.StandardProtocolFamily;
import java.net.UnixDomainSocketAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.Channels;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.UUID;

/**
 * Minimal Discord Rich Presence client over Discord's local IPC (named pipe on Windows, unix socket elsewhere).
 * Frame format: int32 LE opcode, int32 LE payload length, UTF-8 JSON payload. No external library, no network access.
 */
public final class DiscordIpc implements Closeable {
    public static final int OP_HANDSHAKE = 0, OP_FRAME = 1, OP_CLOSE = 2, OP_PING = 3, OP_PONG = 4;

    public interface Transport extends Closeable {
        InputStream in();
        OutputStream out();
    }

    public record Frame(int op, String json) {}

    private final Transport transport;
    private final long pid;

    private DiscordIpc(Transport t, long pid) { this.transport = t; this.pid = pid; }

    // ------------------------------------------------------------------ framing (unit-tested)
    public static byte[] encode(int op, String json) {
        byte[] body = json.getBytes(StandardCharsets.UTF_8);
        ByteBuffer b = ByteBuffer.allocate(8 + body.length).order(ByteOrder.LITTLE_ENDIAN);
        b.putInt(op).putInt(body.length).put(body);
        return b.array();
    }

    public static Frame read(InputStream in) throws IOException {
        byte[] head = in.readNBytes(8);
        if (head.length < 8) throw new EOFException("Discord closed the connection");
        ByteBuffer h = ByteBuffer.wrap(head).order(ByteOrder.LITTLE_ENDIAN);
        int op = h.getInt(), len = h.getInt();
        if (len < 0 || len > 1 << 20) throw new IOException("bad frame length " + len);
        byte[] body = in.readNBytes(len);
        if (body.length < len) throw new EOFException("truncated frame");
        return new Frame(op, new String(body, StandardCharsets.UTF_8));
    }

    private void send(int op, String json) throws IOException {
        OutputStream o = transport.out();
        o.write(encode(op, json));
        o.flush();
    }

    // ------------------------------------------------------------------ protocol
    /** Performs the handshake over an already-open transport. Throws IOException if Discord rejects the client id. */
    public static DiscordIpc connect(Transport t, String clientId, long pid) throws IOException {
        DiscordIpc ipc = new DiscordIpc(t, pid);
        JsonObject hs = new JsonObject();
        hs.addProperty("v", 1);
        hs.addProperty("client_id", clientId);
        ipc.send(OP_HANDSHAKE, hs.toString());
        Frame f = read(t.in());
        if (f.op() == OP_CLOSE) throw new IOException("Discord rejected the Application ID: " + f.json());
        JsonObject o = JsonParser.parseString(f.json()).getAsJsonObject();
        if (o.has("evt") && !o.get("evt").isJsonNull() && "ERROR".equals(o.get("evt").getAsString()))
            throw new IOException("Discord error: " + f.json());
        return ipc;
    }

    /** Sets (or with null clears) the activity. Blocks until Discord acknowledges. */
    public void setActivity(JsonObject activity) throws IOException {
        JsonObject args = new JsonObject();
        args.addProperty("pid", pid);
        if (activity != null) args.add("activity", activity);
        JsonObject cmd = new JsonObject();
        cmd.addProperty("cmd", "SET_ACTIVITY");
        cmd.add("args", args);
        cmd.addProperty("nonce", UUID.randomUUID().toString());
        send(OP_FRAME, cmd.toString());
        Frame reply = read(transport.in());
        if (reply.op() == OP_PING) send(OP_PONG, reply.json());
    }

    @Override public void close() { try { transport.close(); } catch (IOException ignored) {} }

    // ------------------------------------------------------------------ real transports
    /** Tries discord-ipc-0..9 (Discord, Canary, PTB and forks). */
    public static Transport openAny() throws IOException {
        IOException last = new IOException("Discord does not appear to be running.");
        boolean windows = System.getProperty("os.name", "").toLowerCase().contains("win");
        for (int i = 0; i < 10; i++) {
            try {
                if (windows) return openPipe("\\\\.\\pipe\\discord-ipc-" + i);
                for (String dir : unixDirs()) {
                    Path p = Path.of(dir, "discord-ipc-" + i);
                    if (Files.exists(p)) return openSocket(p);
                }
            } catch (IOException e) { last = e; }
        }
        throw last;
    }

    private static String[] unixDirs() {
        String xdg = System.getenv("XDG_RUNTIME_DIR");
        String tmp = System.getenv("TMPDIR");
        return new String[]{ xdg == null ? "/run/user/1000" : xdg, xdg == null ? "/tmp" : xdg + "/app/com.discordapp.Discord",
            xdg == null ? "/tmp" : xdg + "/snap.discord", tmp == null ? "/tmp" : tmp, "/tmp" };
    }

    public static Transport openSocket(Path path) throws IOException {
        SocketChannel ch = SocketChannel.open(StandardProtocolFamily.UNIX);
        ch.connect(UnixDomainSocketAddress.of(path));
        InputStream in = Channels.newInputStream(ch);
        OutputStream out = Channels.newOutputStream(ch);
        return new Transport() {
            public InputStream in() { return in; }
            public OutputStream out() { return out; }
            public void close() throws IOException { ch.close(); }
        };
    }

    private static Transport openPipe(String name) throws IOException {
        RandomAccessFile raf = new RandomAccessFile(name, "rw");
        InputStream in = new InputStream() {
            public int read() throws IOException { return raf.read(); }
            public int read(byte[] b, int off, int len) throws IOException { return raf.read(b, off, len); }
        };
        OutputStream out = new OutputStream() {
            public void write(int b) throws IOException { raf.write(b); }
            public void write(byte[] b, int off, int len) throws IOException { raf.write(b, off, len); }
        };
        return new Transport() {
            public InputStream in() { return in; }
            public OutputStream out() { return out; }
            public void close() throws IOException { raf.close(); }
        };
    }
}
