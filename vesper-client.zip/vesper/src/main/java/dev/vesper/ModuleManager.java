package dev.vesper;

import dev.vesper.core.Module;
import dev.vesper.core.ModuleRegistry;
import dev.vesper.hud.HudModule;
import dev.vesper.hud.Notifications;
import dev.vesper.mc.Keys;
import net.minecraft.client.Minecraft;

import java.util.*;

/** Owns all modules, drives ticks, polls keybinds and isolates module failures. */
public final class ModuleManager implements ModuleRegistry {
    private final List<Module> all = new ArrayList<>();
    private final List<HudModule> hud = new ArrayList<>();
    private final Map<String, Module> byId = new HashMap<>();
    private final Map<Module, Boolean> keyWas = new HashMap<>();
    private final List<String> favorites = new ArrayList<>(), recent = new ArrayList<>();
    private Object lastLevel;

    public void register(Module m) {
        if (byId.putIfAbsent(m.id, m) != null) throw new IllegalStateException("duplicate module id " + m.id);
        all.add(m);
        if (m instanceof HudModule h) hud.add(h);
        m.resetToDefaults();   // applies default enabled state exactly once
    }

    @Override public List<Module> all() { return all; }
    public List<HudModule> hudModules() { return hud; }
    @Override public List<String> favorites() { return favorites; }
    @Override public List<String> recent() { return recent; }
    public Module get(String id) { return byId.get(id); }

    public boolean isFavorite(Module m) { return favorites.contains(m.id); }
    public void toggleFavorite(Module m) {
        if (!favorites.remove(m.id)) favorites.add(m.id);
        dev.vesper.core.setting.Setting.changeNotify();
    }
    public void touch(Module m) {
        recent.remove(m.id); recent.add(0, m.id);
        while (recent.size() > 8) recent.remove(recent.size() - 1);
        dev.vesper.core.setting.Setting.changeNotify();
    }

    public void applyPreset(String preset) {
        Set<String> on = preset.equals("cpvp")
            ? Set.of("crystal_damage", "target_info", "item_counters", "armor_status", "combat_alerts", "combat_timer", "notifications")
            : Set.of("info", "coordinates", "notifications");
        for (Module m : all) if (m.canToggle()) m.setEnabled(on.contains(m.id));
    }

    public void tick(Minecraft mc) {
        VesperClient.config().tick();
        for (String e : VesperClient.config().drainErrors()) Notifications.push(e, Notifications.WARN);

        if (mc.level != lastLevel) {
            lastLevel = mc.level;
            for (Module m : all) guard(m, m::onWorldChange);
        }
        if (mc.player != null) Notifications.tick((int) (VesperClient.settings().notifySeconds.f() * 20));

        boolean canFire = mc.screen == null && mc.player != null && mc.isWindowActive();
        for (Module m : all) {
            if (m.key() > 0) {
                boolean down = Keys.isDown(m.key());
                boolean was = keyWas.getOrDefault(m, false);
                keyWas.put(m, down);
                if (down && !was && canFire) {
                    guard(m, m::onKeyPressed);
                    if (VesperClient.settings().toggleNotifications.on() && m.canToggle())
                        Notifications.push(m.name + (m.enabled() ? " enabled" : " disabled"), m.enabled() ? Notifications.GOOD : Notifications.INFO);
                }
            }
        }
        for (Module m : all) if (m.enabled()) guard(m, m::onTick);
    }

    /** Runs module code; a module that throws 3 times in a row is disabled so it cannot destabilise the game. */
    public static void guard(Module m, Runnable r) {
        try {
            r.run();
            m.noteOk();
        } catch (Throwable t) {
            VesperClient.LOG.error("Module {} failed", m.id, t);
            if (m.noteError() >= 3) {
                try { m.setEnabled(false); } catch (RuntimeException ignored) {}
                Notifications.push(m.name + " was disabled after repeated errors. See latest.log.", Notifications.BAD);
            }
        }
    }
}
