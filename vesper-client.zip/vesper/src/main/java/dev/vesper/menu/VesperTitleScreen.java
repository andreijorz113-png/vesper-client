package dev.vesper.menu;

import com.mojang.realmsclient.RealmsMainScreen;
import dev.vesper.VesperClient;
import dev.vesper.gui.ClickGui;
import dev.vesper.gui.Draw;
import dev.vesper.gui.Theme;
import dev.vesper.mc.Keys;
import dev.vesper.modules.MainMenu;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * The Vesper main menu: navigation on the left over a scrim, scenery on the right.
 * With a non-null parent it is a preview (Esc returns to the parent); otherwise it is the real title screen.
 */
public final class VesperTitleScreen extends Screen {
    private record Btn(String label, String hint, Runnable action) {}

    private final Screen parent;
    private final List<Btn> buttons = new ArrayList<>();
    private final float[] hoverAnim = new float[8];
    private int selected = -1;
    private final long opened = System.currentTimeMillis();

    public VesperTitleScreen() { this(null); }
    public VesperTitleScreen(Screen parent) {
        super(Component.literal("Vesper"));
        this.parent = parent;
    }

    @Override public boolean isPauseScreen() { return false; }
    @Override public boolean shouldCloseOnEsc() { return parent != null; }
    @Override public void onClose() { if (parent != null) minecraft.setScreen(parent); }

    @Override protected void init() {
        buttons.clear();
        buttons.add(new Btn("Singleplayer", "Play offline worlds", () -> minecraft.setScreen(new SelectWorldScreen(this))));
        buttons.add(new Btn("Multiplayer", "Join servers", () -> minecraft.setScreen(new JoinMultiplayerScreen(this))));
        buttons.add(new Btn("Realms", "Minecraft Realms", () -> minecraft.setScreen(new RealmsMainScreen(this))));
        buttons.add(new Btn("Options", "Video, controls, sound", () -> minecraft.setScreen(new OptionsScreen(this, minecraft.options))));
        buttons.add(new Btn("Client Settings", "Open the Vesper menu", () -> minecraft.setScreen(new ClickGui())));
        buttons.add(new Btn(parent != null ? "Back" : "Quit Game", parent != null ? "Return to the settings" : "Close Minecraft", () -> { if (parent != null) onClose(); else minecraft.stop(); }));
    }

    private MainMenu cfg() { return (MainMenu) VesperClient.modules().get("main_menu"); }
    private float animK() { return VesperClient.settings().reducedMotion.on() ? 0f : (float) cfg().anim.get().doubleValue(); }

    // ------------------------------------------------------------------ layout
    private int navX() { return Math.max(28, width / 14); }
    private int navW() { return Math.min(220, width / 3); }
    private int navTop() { return height / 2 - (buttons.size() * 26) / 2 + 36; }

    @Override public void render(GuiGraphics g, int mx, int my, float delta) {
        MainMenu c = cfg();
        long now = System.currentTimeMillis();
        float t = (now - opened) / 1000f;
        float k = animK();
        float fade = k <= 0 ? 1f : Math.min(1f, t / Math.max(0.05f, (float) c.transition.get().doubleValue()));
        fade = 1 - (1 - fade) * (1 - fade);
        int acc = Theme.accent();

        drawBackground(g, c, t, k);
        g.fill(0, 0, width, height, c.tint.argb());
        g.fill(0, 0, width, height, ((int) (c.dim.get() * 255) & 255) << 24);

        // left scrim for readability, fading out to the right
        int scrimW = navX() + navW() + 90;
        int strips = 48;
        for (int i = 0; i < strips; i++) {
            float f = i / (float) strips;
            int a = (int) (c.menuOpacity.get() * 200 * (1 - f) * (1 - f) * fade);
            g.fill(i * scrimW / strips, 0, (i + 1) * scrimW / strips + 1, height, (a << 24) | (Theme.BG & 0xFFFFFF));
        }
        g.fill(navX() - 14, 0, navX() - 13, height, Draw.alpha(acc, 0.18f * fade));

        // logo
        int lx = navX(), ly = navTop() - 96 - Math.round((1 - fade) * 10);
        float twinkle = c.logoAnim.on() && k > 0 ? 0.5f + 0.5f * (float) Math.sin(t * 2.2) : 0.5f;
        float bob = k > 0 ? (float) Math.sin(t * 0.9) * 1.5f * k : 0;
        Draw.logoMark(g, lx + 24, ly + 28 + bob, 56, acc, twinkle);
        Draw.wordmark(g, lx + 64, ly + 14, 30, Draw.alpha(0xFFF4F1FF, fade));
        Draw.text(g, "CRYSTAL PVP CLIENT", lx + 66, ly + 52, Draw.alpha(Theme.DIM, fade));

        // buttons
        int bx = navX(), bw = navW(), by = navTop();
        for (int i = 0; i < buttons.size(); i++) {
            boolean over = Draw.in(mx, my, bx - 6, by + i * 26, bw + 6, 24) || i == selected;
            float target = over ? 1f : 0f;
            hoverAnim[i] += (target - hoverAnim[i]) * (k <= 0 ? 1f : Math.min(1f, 0.25f * k + 0.05f));
            float h = hoverAnim[i];
            int y = by + i * 26 + Math.round((1 - fade) * 8 * (i + 1) * 0.3f);
            int bgA = (int) ((0.20f + 0.45f * h) * 255 * fade * (float) c.menuOpacity.get().doubleValue());
            Draw.panel(g, bx - 6, y, bw + 6, 24, (bgA << 24) | (Theme.PANEL & 0xFFFFFF), Theme.radius());
            if (h > 0.02f) g.fill(bx - 6, y + 4, bx - 4, y + 20, Draw.alpha(acc, h * fade));
            int off = Math.round(h * 5 * Math.max(k, 0.3f));
            Draw.text(g, buttons.get(i).label(), bx + 6 + off, y + 8, Draw.alpha(Theme.TEXT, fade));
            if (h > 0.3f) {
                String hint = buttons.get(i).hint();
                Draw.text(g, hint, bx + bw - Draw.width(hint) - 6, y + 8, Draw.alpha(Theme.DIM, h * fade));
            }
        }

        // status line
        String ver = "Vesper " + FabricLoader.getInstance().getModContainer("vesper").map(m -> m.getMetadata().getVersion().getFriendlyString()).orElse("dev")
            + "  -  Minecraft " + FabricLoader.getInstance().getModContainer("minecraft").map(m -> m.getMetadata().getVersion().getFriendlyString()).orElse("?");
        Draw.text(g, ver, navX(), height - 18, Draw.alpha(Theme.DIM, fade));
        String hint = Keys.name(VesperClient.settings().key()) + " opens the client menu in game";
        Draw.text(g, hint, width - Draw.width(hint) - 12, height - 18, Draw.alpha(Theme.DIM, 0.7f * fade));
        if (c.background.is("Custom image") && !BackgroundImages.error().isEmpty())
            Draw.text(g, Draw.ellipsize(BackgroundImages.error(), width - 24), 12, 10, Theme.WARN);
    }

    private void drawBackground(GuiGraphics g, MainMenu c, float t, float k) {
        switch (c.background.get()) {
            case "Minecraft panorama" -> minecraft.gameRenderer.getPanorama().render(g, width, height, c.rotate.on() && k > 0);
            case "Custom image" -> {
                if (BackgroundImages.ensure(c.image.get())) drawImage(g, c, t, k);
                else minecraft.gameRenderer.getPanorama().render(g, width, height, true);   // clear fallback instead of a blank screen
            }
            case "Gradient" -> {
                int a = Theme.BG, b = VesperClient.settings().accent.argb() | 0xFF000000;
                int top = dev.vesper.mc.McUtil.mixColor(a, b, 0.0f), bottom = dev.vesper.mc.McUtil.mixColor(a, b, 0.35f);
                int strips = 72;
                for (int i = 0; i < strips; i++)
                    g.fill(0, i * height / strips, width, (i + 1) * height / strips + 1, dev.vesper.mc.McUtil.mixColor(top, bottom, i / (float) (strips - 1)));
            }
            default -> g.fill(0, 0, width, height, Theme.BG);
        }
    }

    private void drawImage(GuiGraphics g, MainMenu c, float t, float k) {
        int iw = BackgroundImages.width(), ih = BackgroundImages.height();
        float zoom = 1.0f + 0.12f * (float) c.drift.get().doubleValue();
        float scale = Math.max(width / (float) iw, height / (float) ih) * zoom;
        float srcW = Math.min(iw, width / scale), srcH = Math.min(ih, height / scale);
        float spanX = iw - srcW, spanY = ih - srcH;
        float dx = k > 0 ? (float) Math.sin(t * 0.12) * (float) c.drift.get().doubleValue() * k : 0;
        float dy = k > 0 ? (float) Math.cos(t * 0.09) * (float) c.drift.get().doubleValue() * k : 0;
        float u = Math.max(0, Math.min(spanX, spanX / 2 + dx * spanX / 2)), v = Math.max(0, Math.min(spanY, spanY / 2 + dy * spanY / 2));
        g.blit(RenderPipelines.GUI_TEXTURED, BackgroundImages.ID, 0, 0, u, v, width, height, Math.round(srcW), Math.round(srcH), iw, ih);
    }

    // ------------------------------------------------------------------ input
    @Override public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        if (e.button() != 0) return super.mouseClicked(e, dbl);
        int bx = navX(), bw = navW(), by = navTop();
        for (int i = 0; i < buttons.size(); i++)
            if (Draw.in(e.x(), e.y(), bx - 6, by + i * 26, bw + 6, 24)) { buttons.get(i).action().run(); return true; }
        return super.mouseClicked(e, dbl);
    }

    @Override public boolean keyPressed(KeyEvent e) {
        int k = e.key();
        if (k == GLFW.GLFW_KEY_DOWN || k == GLFW.GLFW_KEY_TAB) { selected = (selected + 1) % buttons.size(); return true; }
        if (k == GLFW.GLFW_KEY_UP) { selected = selected <= 0 ? buttons.size() - 1 : selected - 1; return true; }
        if ((k == GLFW.GLFW_KEY_ENTER || k == GLFW.GLFW_KEY_KP_ENTER) && selected >= 0) { buttons.get(selected).action().run(); return true; }
        return super.keyPressed(e);
    }
}
