package dev.vesper.menu;

import com.mojang.blaze3d.platform.NativeImage;
import dev.vesper.VesperClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Loads a user image (PNG/JPG/GIF/BMP) from config/vesper/backgrounds into a GPU texture for the main menu.
 * Validated (size, dimensions, decodability); failures are reported via error() and never crash the game.
 * Must be called from the render thread.
 */
public final class BackgroundImages {
    private BackgroundImages() {}

    public static final Identifier ID = Identifier.fromNamespaceAndPath("vesper", "dynamic/menu_background");
    private static final long MAX_BYTES = 40L * 1024 * 1024;
    private static final int MAX_DIM = 8192;

    private static String loadedKey = "";
    private static boolean ready;
    private static int width, height;
    private static String error = "";

    public static Path dir() { return VesperClient.config().root().resolve("backgrounds"); }
    public static String error() { return error; }
    public static int width() { return width; }
    public static int height() { return height; }

    /** Returns true when the named image is loaded and drawable. */
    public static boolean ensure(String fileName) {
        if (fileName == null || fileName.isBlank()) { release(); error = "Enter an image file name (the file goes in config/vesper/backgrounds)."; return false; }
        Path p = dir().resolve(fileName.trim());
        String key;
        try { key = fileName.trim() + "|" + Files.getLastModifiedTime(p).toMillis(); }
        catch (IOException e) { release(); error = "Image not found: config/vesper/backgrounds/" + fileName.trim(); return false; }
        if (key.equals(loadedKey)) return ready;
        loadedKey = key;
        release();
        loadedKey = key;
        try {
            if (fileName.contains("/") || fileName.contains("\\") || fileName.contains("..")) throw new IOException("file name may not contain folders");
            if (Files.size(p) > MAX_BYTES) throw new IOException("file is larger than 40 MB");
            BufferedImage img = ImageIO.read(p.toFile());
            if (img == null) throw new IOException("not a supported image (use PNG, JPG, GIF or BMP)");
            if (img.getWidth() > MAX_DIM || img.getHeight() > MAX_DIM) throw new IOException("image is larger than " + MAX_DIM + "x" + MAX_DIM);
            ByteArrayOutputStream png = new ByteArrayOutputStream();
            ImageIO.write(img, "png", png);
            NativeImage ni = NativeImage.read(new ByteArrayInputStream(png.toByteArray()));
            Minecraft.getInstance().getTextureManager().register(ID, new DynamicTexture(() -> "vesper_menu_background", ni));
            width = img.getWidth(); height = img.getHeight();
            ready = true; error = "";
        } catch (IOException | RuntimeException e) {
            ready = false; error = "Could not load " + fileName.trim() + ": " + e.getMessage();
            VesperClient.LOG.warn(error);
        }
        return ready;
    }

    /** Frees the GPU texture. */
    public static void release() {
        if (ready) {
            try { Minecraft.getInstance().getTextureManager().release(ID); } catch (RuntimeException e) { VesperClient.LOG.warn("Failed to release background: {}", e.getMessage()); }
        }
        ready = false; loadedKey = "";
    }
}
