package dev.vesper.hud;

import net.minecraft.client.gui.GuiGraphics;

/** Implemented by modules that draw relative to the screen center (not a draggable HUD box). */
public interface ScreenOverlay {
    void renderOverlay(GuiGraphics g);
}
