package dev.vesper.hud;

import java.util.ArrayList;
import java.util.List;

/** Tiny notification queue; age advances per in-world client tick so messages are never missed in menus. */
public final class Notifications {
    private Notifications() {}

    public static final int GOOD = 0xFF5FD38D, WARN = 0xFFF2C14E, BAD = 0xFFFF5C6C, INFO = 0xFFECECF4;

    public record Entry(String text, int color, int age) {}
    private static final List<Entry> list = new ArrayList<>();

    public static synchronized void push(String text, int color) {
        if (list.size() >= 6) list.remove(0);
        list.add(new Entry(text, color, 0));
    }

    /** Advance one tick and drop entries older than maxTicks. */
    public static synchronized void tick(int maxTicks) {
        for (int i = list.size() - 1; i >= 0; i--) {
            Entry e = list.get(i);
            if (e.age() + 1 > maxTicks) list.remove(i);
            else list.set(i, new Entry(e.text(), e.color(), e.age() + 1));
        }
    }

    public static synchronized List<Entry> snapshot() { return new ArrayList<>(list); }
    public static synchronized void clear() { list.clear(); }
}
