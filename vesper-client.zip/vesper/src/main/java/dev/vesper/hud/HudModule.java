package dev.vesper.hud;

import com.google.gson.JsonObject;
import dev.vesper.VesperClient;
import dev.vesper.core.Category;
import dev.vesper.core.Module;
import dev.vesper.core.setting.BoolSetting;
import dev.vesper.core.setting.ColorSetting;
import dev.vesper.core.setting.NumberSetting;
import dev.vesper.core.setting.Setting;
import dev.vesper.gui.Draw;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

/**
 * A module that draws on the HUD. Position = anchor corner + offset (GUI pixels), so layouts survive resolution changes.
 * Subclasses draw relative to (0,0); this class handles placement, scaling, background and the editor preview.
 */
public abstract class HudModule extends Module {
    public enum Anchor { TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT }
    public static final int PAD = 3;

    public Anchor anchor;
    public float ox, oy;
    private final Anchor defAnchor;
    private final float defOx, defOy;

    public final NumberSetting scale = add(new NumberSetting("scale", "Scale", "Size of this HUD element. Also adjustable with the mouse wheel in the HUD editor.", 1.0, 0.5, 3.0, 0.05, "x"));
    public final ColorSetting textColor = add(new ColorSetting("textColor", "Text color", "Default text color for this element.", 0xFFECECF4));
    public final BoolSetting background = add(new BoolSetting("background", "Background", "Draw a panel behind the element.", true));
    public final ColorSetting backgroundColor = add(new ColorSetting("backgroundColor", "Background color", "Color and opacity of the panel.", 0x8C101018), () -> background.on());
    public final BoolSetting shadow = add(new BoolSetting("shadow", "Text shadow", "Draw a drop shadow behind text.", true));

    protected HudModule(String id, String name, String description, Category cat, Anchor a, float ox, float oy, boolean defaultEnabled) {
        super(id, name, description, cat, -1, defaultEnabled);
        this.defAnchor = a; this.defOx = ox; this.defOy = oy;
        this.anchor = a; this.ox = ox; this.oy = oy;
    }

    protected abstract int contentWidth(Font f, boolean preview);
    protected abstract int contentHeight(Font f, boolean preview);
    protected abstract void draw(GuiGraphics g, Font f, boolean preview);
    protected boolean hasContent(boolean preview) { return true; }
    /** Called once per rendered frame before measuring (cheap per-frame polling goes here). */
    protected void onFrame() {}

    /** {x, y, w, h} in GUI pixels, including scale. */
    public int[] bounds(Font f, int sw, int sh, boolean preview) {
        float s = scale.f();
        int w = Math.round((contentWidth(f, preview) + PAD * 2) * s);
        int h = Math.round((contentHeight(f, preview) + PAD * 2) * s);
        int x = switch (anchor) { case TOP_LEFT, BOTTOM_LEFT -> Math.round(ox); default -> Math.round(sw - w - ox); };
        int y = switch (anchor) { case TOP_LEFT, TOP_RIGHT -> Math.round(oy); default -> Math.round(sh - h - oy); };
        return new int[]{x, y, w, h};
    }

    public final void render(GuiGraphics g, boolean preview) {
        Minecraft mc = Minecraft.getInstance();
        Font f = mc.font;
        onFrame();
        if (!hasContent(preview)) return;
        int[] b = bounds(f, g.guiWidth(), g.guiHeight(), preview);
        float s = scale.f();
        int w = contentWidth(f, preview) + PAD * 2, h = contentHeight(f, preview) + PAD * 2;
        g.pose().pushMatrix();
        g.pose().translate(b[0], b[1]);
        g.pose().scale(s, s);
        if (background.on()) Draw.panel(g, 0, 0, w, h, backgroundColor.argb(), 3);
        g.pose().pushMatrix();
        g.pose().translate(PAD, PAD);
        draw(g, f, preview);
        g.pose().popMatrix();
        g.pose().popMatrix();
    }

    /** Re-anchors to the nearest corner so the element stays put when the window size changes. */
    public void setFromAbsolute(int x, int y, int w, int h, int sw, int sh) {
        boolean left = x + w / 2 < sw / 2, top = y + h / 2 < sh / 2;
        anchor = left ? (top ? Anchor.TOP_LEFT : Anchor.BOTTOM_LEFT) : (top ? Anchor.TOP_RIGHT : Anchor.BOTTOM_RIGHT);
        ox = left ? x : sw - (x + w);
        oy = top ? y : sh - (y + h);
        Setting.changeNotify();
    }

    public void resetLayout() { anchor = defAnchor; ox = defOx; oy = defOy; scale.reset(); Setting.changeNotify(); }
    @Override protected void extraReset() { anchor = defAnchor; ox = defOx; oy = defOy; }

    @Override public void extraToJson(JsonObject o) {
        JsonObject h = new JsonObject();
        h.addProperty("anchor", anchor.name()); h.addProperty("x", ox); h.addProperty("y", oy);
        o.add("hud", h);
    }
    @Override public void extraFromJson(JsonObject o) {
        if (!o.has("hud") || !o.get("hud").isJsonObject()) return;
        JsonObject h = o.getAsJsonObject("hud");
        try {
            if (h.has("anchor")) anchor = Anchor.valueOf(h.get("anchor").getAsString());
            if (h.has("x")) ox = Math.max(-4000, Math.min(4000, h.get("x").getAsFloat()));
            if (h.has("y")) oy = Math.max(-4000, Math.min(4000, h.get("y").getAsFloat()));
        } catch (RuntimeException e) {
            VesperClient.LOG.warn("Ignoring invalid HUD position for {}: {}", id, e.getMessage());
        }
    }
}
