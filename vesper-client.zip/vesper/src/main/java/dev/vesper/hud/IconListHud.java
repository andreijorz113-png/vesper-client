package dev.vesper.hud;

import dev.vesper.core.Category;
import dev.vesper.core.setting.ModeSetting;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.item.ItemStack;

import java.util.List;

/** HUD element showing item icons with a short text beside each (counters, armor status). */
public abstract class IconListHud extends HudModule {
    public record Entry(ItemStack stack, String text, int color) {}

    public final ModeSetting layout = add(new ModeSetting("layout", "Layout", "Stack icons vertically or place them in a row.", "Vertical", "Vertical", "Horizontal"));
    protected List<Entry> entries = List.of();

    protected IconListHud(String id, String name, String description, Category cat, Anchor a, float ox, float oy, boolean defaultEnabled) {
        super(id, name, description, cat, a, ox, oy, defaultEnabled);
    }

    protected abstract List<Entry> sample();
    private List<Entry> shown(boolean p) { return p ? sample() : entries; }
    @Override protected boolean hasContent(boolean preview) { return preview || !entries.isEmpty(); }

    private int cell(Font f, Entry e) { return 18 + (e.text().isEmpty() ? 0 : f.width(e.text()) + 3); }

    @Override protected int contentWidth(Font f, boolean preview) {
        int w = 0;
        boolean h = layout.is("Horizontal");
        for (Entry e : shown(preview)) w = h ? w + cell(f, e) + 2 : Math.max(w, cell(f, e));
        return h && w > 0 ? w - 2 : w;
    }
    @Override protected int contentHeight(Font f, boolean preview) {
        int n = shown(preview).size();
        return n == 0 ? 0 : layout.is("Horizontal") ? 16 : n * 18 - 2;
    }
    @Override protected void draw(GuiGraphics g, Font f, boolean preview) {
        int x = 0, y = 0;
        boolean h = layout.is("Horizontal");
        for (Entry e : shown(preview)) {
            g.renderItem(e.stack(), x, y);
            if (!e.text().isEmpty()) g.drawString(f, e.text(), x + 18, y + 4, e.color() == 0 ? textColor.argb() : e.color(), shadow.on());
            if (h) x += cell(f, e) + 2; else y += 18;
        }
    }
}
