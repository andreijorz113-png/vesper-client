package dev.vesper.hud;

import dev.vesper.ModuleManager;
import dev.vesper.VesperClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

public final class HudManager {
    private HudManager() {}

    public static void renderAll(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.player == null || mc.screen instanceof dev.vesper.gui.HudEditorScreen) return;
        for (var m : VesperClient.modules().hudModules()) {
            if (m.enabled()) ModuleManager.guard(m, () -> m.render(g, false));
        }
    }
}
