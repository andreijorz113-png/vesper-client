package dev.vesper.hud;

import dev.vesper.core.Category;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

import java.util.List;

/** HUD element made of colored text lines. Subclasses fill `lines` from onTick (never allocate per frame). */
public abstract class TextHudModule extends HudModule {
    public record Line(String text, int color) {}   // color 0 = use the element's text color

    protected List<Line> lines = List.of();

    protected TextHudModule(String id, String name, String description, Category cat, Anchor a, float ox, float oy, boolean defaultEnabled) {
        super(id, name, description, cat, a, ox, oy, defaultEnabled);
    }

    /** Example content shown in the HUD editor and for new users. */
    protected abstract List<Line> sample();

    private List<Line> shown(boolean preview) { return preview ? sample() : lines; }
    @Override protected boolean hasContent(boolean preview) { return preview || !lines.isEmpty(); }

    @Override protected int contentWidth(Font f, boolean preview) {
        int w = 0;
        for (Line l : shown(preview)) w = Math.max(w, f.width(l.text()));
        return w;
    }
    @Override protected int contentHeight(Font f, boolean preview) {
        int n = shown(preview).size();
        return n == 0 ? 0 : n * (f.lineHeight + 1) - 1;
    }
    @Override protected void draw(GuiGraphics g, Font f, boolean preview) {
        int y = 0;
        for (Line l : shown(preview)) {
            g.drawString(f, l.text(), 0, y, l.color() == 0 ? textColor.argb() : l.color(), shadow.on());
            y += f.lineHeight + 1;
        }
    }
}
