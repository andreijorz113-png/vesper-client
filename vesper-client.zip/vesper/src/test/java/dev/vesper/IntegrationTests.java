package dev.vesper;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.vesper.core.setting.*;
import dev.vesper.integration.DiscordIpc;
import dev.vesper.integration.SpotifyApi;
import dev.vesper.render.ParticleClass;
import dev.vesper.theme.ThemeData;
import dev.vesper.theme.ThemeStore;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.StandardProtocolFamily;
import java.net.UnixDomainSocketAddress;
import java.nio.channels.Channels;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public final class IntegrationTests {
    static int failures = 0, run = 0;
    static void check(String n, boolean ok) { run++; if (!ok) { failures++; System.err.println("FAIL " + n); } }

    public static int run() throws Exception {
        failures = 0; run = 0;

        // ---- string / action settings
        StringSetting s = new StringSetting("id", "Id", "", "", 8, "");
        s.set("abc\u0007def123456"); check("string strips control chars and caps length", s.get().equals("abcdef12"));
        boolean threw = false;
        try { s.fromJson(new com.google.gson.JsonPrimitive("waytoolongvalue")); } catch (IllegalArgumentException e) { threw = true; }
        check("string rejects over-long json", threw);
        int[] clicks = {0};
        ActionSetting a = new ActionSetting("a", "A", "", "Go", () -> clicks[0]++);
        a.run(); check("action runs", clicks[0] == 1);
        check("action not persistent", !a.persistent() && s.persistent());

        // ---- themes
        check("7 presets", ThemeData.presetNames().size() == 7);
        boolean distinct = true;
        for (String x : ThemeData.presetNames()) for (String y : ThemeData.presetNames())
            if (!x.equals(y) && ThemeData.preset(x).samePalette(ThemeData.preset(y))) distinct = false;
        check("presets are visually distinct", distinct);
        Path dir = Files.createTempDirectory("themes"), exp = Files.createTempDirectory("exports");
        ThemeStore store = new ThemeStore(dir);
        ThemeData mine = ThemeData.preset("Frost").named("My Frost");
        store.save(mine);
        check("theme save/load roundtrip", store.load("My Frost").samePalette(mine));
        check("theme listed", store.list().contains("My Frost"));
        Path exported = store.export("My Frost", exp);
        check("theme exported", Files.exists(exported));
        String imported = store.importFile(exported.getFileName().toString(), exp);
        check("import gets a unique name", !imported.equals("My Frost") && store.list().contains(imported));
        Files.writeString(exp.resolve("bad.json"), "{\"bg\":\"zzzzzz\"}");
        boolean bad = false; try { store.importFile("bad.json", exp); } catch (java.io.IOException e) { bad = e.getMessage().contains("invalid"); }
        check("bad theme rejected with message", bad);
        Files.writeString(exp.resolve("arr.json"), "[1]");
        boolean arr = false; try { store.importFile("arr.json", exp); } catch (java.io.IOException e) { arr = true; }
        check("non-object theme rejected", arr);
        boolean trav = false; try { store.importFile("../x.json", exp); } catch (java.io.IOException e) { trav = true; }
        check("theme import rejects traversal", trav);
        boolean nm = false; try { store.save(mine.named("../evil")); } catch (java.io.IOException e) { nm = true; }
        check("theme name validated", nm);
        check("theme delete", store.delete("My Frost") && !store.list().contains("My Frost"));

        // ---- particle classification
        check("explosion class", ParticleClass.of("explosion_emitter") == ParticleClass.EXPLOSION);
        check("crit class", ParticleClass.of("crit") == ParticleClass.CRIT);
        check("totem is combat", ParticleClass.of("totem_of_undying") == ParticleClass.COMBAT);
        check("smoke ambient", ParticleClass.of("large_smoke") == ParticleClass.AMBIENT);
        check("unknown general", ParticleClass.of("flame") == ParticleClass.GENERAL);
        check("keep 100 never drops", !ParticleClass.shouldDrop(100, 0.999));
        check("keep 0 always drops", ParticleClass.shouldDrop(0, 0.0));
        int dropped = 0; java.util.Random r = new java.util.Random(1);
        for (int i = 0; i < 10000; i++) if (ParticleClass.shouldDrop(25, r.nextDouble())) dropped++;
        check("keep 25% drops about 75%", Math.abs(dropped - 7500) < 300);

        // ---- Spotify helpers
        check("PKCE challenge matches RFC 7636 vector",
            SpotifyApi.challenge("dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk").equals("E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM"));
        String v = SpotifyApi.newVerifier(); check("verifier length 43..128", v.length() >= 43 && v.length() <= 128);
        String url = SpotifyApi.authorizeUrl("cid", "chal", "st");
        check("authorize url", url.contains("client_id=cid") && url.contains("code_challenge_method=S256") && url.contains("redirect_uri=http%3A%2F%2F127.0.0.1%3A8888%2Fcallback"));
        String json = "{\"is_playing\":true,\"progress_ms\":61000,\"item\":{\"name\":\"Song\",\"duration_ms\":200000,\"artists\":[{\"name\":\"A\"},{\"name\":\"B\"}]}}";
        SpotifyApi.Track t = SpotifyApi.parseCurrentlyPlaying(json);
        check("track parsed", t != null && t.title().equals("Song") && t.artist().equals("A, B") && t.durationMs() == 200000 && t.progressMs() == 61000 && t.playing());
        check("null item -> no track", SpotifyApi.parseCurrentlyPlaying("{\"item\":null}") == null);
        check("garbage -> no track", SpotifyApi.parseCurrentlyPlaying("not json") == null && SpotifyApi.parseCurrentlyPlaying("[]") == null);
        String[] cb = SpotifyApi.parseCallback("GET /callback?code=abc%2B1&state=xyz HTTP/1.1");
        check("callback parsed", "abc+1".equals(cb[0]) && "xyz".equals(cb[1]));
        check("callback error", "access_denied".equals(SpotifyApi.parseCallback("GET /callback?error=access_denied&state=x HTTP/1.1")[2]));
        check("callback wrong path ignored", SpotifyApi.parseCallback("GET /evil?code=1 HTTP/1.1")[0] == null);

        // ---- Discord IPC: framing + full handshake/SET_ACTIVITY against a fake Discord on a unix socket
        byte[] f = DiscordIpc.encode(1, "{\"a\":1}");
        check("frame header little-endian", f[0] == 1 && f[1] == 0 && f[4] == 7 && f.length == 15);
        DiscordIpc.Frame back = DiscordIpc.read(new java.io.ByteArrayInputStream(f));
        check("frame roundtrip", back.op() == 1 && back.json().equals("{\"a\":1}"));
        Path sock = Files.createTempDirectory("ipc").resolve("discord-ipc-0");
        List<String> seen = new CopyOnWriteArrayList<>();
        try (ServerSocketChannel server = ServerSocketChannel.open(StandardProtocolFamily.UNIX)) {
            server.bind(UnixDomainSocketAddress.of(sock));
            Thread fake = new Thread(() -> {
                try (SocketChannel c = server.accept()) {
                    InputStream in = Channels.newInputStream(c); OutputStream out = Channels.newOutputStream(c);
                    DiscordIpc.Frame hs = DiscordIpc.read(in); seen.add(hs.op() + ":" + hs.json());
                    out.write(DiscordIpc.encode(1, "{\"cmd\":\"DISPATCH\",\"evt\":\"READY\"}")); out.flush();
                    DiscordIpc.Frame act = DiscordIpc.read(in); seen.add(act.op() + ":" + act.json());
                    out.write(DiscordIpc.encode(1, "{\"cmd\":\"SET_ACTIVITY\"}")); out.flush();
                } catch (Exception e) { seen.add("ERR " + e); }
            });
            fake.start();
            try (DiscordIpc ipc = DiscordIpc.connect(DiscordIpc.openSocket(sock), "123456789", 4242)) {
                JsonObject act = new JsonObject(); act.addProperty("details", "Playing Minecraft"); act.addProperty("state", "Vesper");
                ipc.setActivity(act);
            }
            fake.join(3000);
        }
        check("handshake sent first with client id", seen.size() >= 1 && seen.get(0).startsWith("0:") && seen.get(0).contains("\"client_id\":\"123456789\"") && seen.get(0).contains("\"v\":1"));
        check("SET_ACTIVITY sent", seen.size() >= 2 && seen.get(1).startsWith("1:"));
        JsonObject cmd = JsonParser.parseString(seen.get(1).substring(2)).getAsJsonObject();
        check("activity payload correct", cmd.get("cmd").getAsString().equals("SET_ACTIVITY") && cmd.getAsJsonObject("args").get("pid").getAsLong() == 4242
            && cmd.getAsJsonObject("args").getAsJsonObject("activity").get("details").getAsString().equals("Playing Minecraft") && cmd.has("nonce"));

        System.out.println("IntegrationTests: " + (run - failures) + "/" + run + " passed");
        return failures;
    }
    public static void main(String[] a) throws Exception { if (run() > 0) System.exit(1); }
}
