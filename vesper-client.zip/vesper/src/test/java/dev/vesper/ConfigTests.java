package dev.vesper;

import com.google.gson.JsonObject;
import dev.vesper.config.ConfigManager;
import dev.vesper.config.Migrations;
import dev.vesper.core.Category;
import dev.vesper.core.Module;
import dev.vesper.core.ModuleRegistry;
import dev.vesper.core.setting.*;

import java.nio.file.*;
import java.util.*;

public final class ConfigTests {
    static int failures = 0, run = 0;
    static void check(String name, boolean ok) { run++; if (!ok) { failures++; System.err.println("FAIL " + name); } }

    static final class Dummy extends Module {
        final BoolSetting flag = add(new BoolSetting("flag", "Flag", "", false));
        final NumberSetting range = add(new NumberSetting("range", "Range", "", 5, 1, 10, 0.5, ""));
        final ModeSetting mode = add(new ModeSetting("mode", "Mode", "", "A", "A", "B", "C"));
        final ColorSetting color = add(new ColorSetting("color", "Color", "", 0xFF112233));
        int enables, disables;
        Dummy() { super("dummy", "Dummy", "", Category.QOL, 70, false); }
        @Override protected void onEnable() { enables++; }
        @Override protected void onDisable() { disables++; }
    }
    static final class Reg implements ModuleRegistry {
        final Dummy d = new Dummy(); final List<String> fav = new ArrayList<>(), rec = new ArrayList<>();
        public List<Module> all() { return List.of(d); }
        public List<String> favorites() { return fav; }
        public List<String> recent() { return rec; }
    }

    public static int run() throws Exception {
        failures = 0; run = 0;
        Path dir = Files.createTempDirectory("vesper-test");

        // settings validation
        NumberSetting n = new NumberSetting("n", "N", "", 5, 1, 10, 0.5, "");
        n.set(99.0); check("number clamps", n.get() == 10.0);
        n.set(2.26); check("number snaps to step", n.get() == 2.5);
        boolean threw = false;
        try { n.fromJson(new com.google.gson.JsonPrimitive(50)); } catch (IllegalArgumentException e) { threw = true; }
        check("number rejects out-of-range json", threw);
        ColorSetting c = new ColorSetting("c", "C", "", 0);
        c.fromJson(new com.google.gson.JsonPrimitive("#33AAFF")); check("color rgb gets opaque alpha", c.argb() == 0xFF33AAFF);
        check("color json roundtrip", c.toJson().getAsString().equals("#FF33AAFF"));

        // roundtrip
        Reg r = new Reg();
        ConfigManager cm = new ConfigManager(dir, r);
        check("first launch detected", cm.load());
        r.d.setEnabled(true); r.d.flag.set(true); r.d.range.set(7.5); r.d.mode.set("C"); r.d.color.set(0x80FF0000); r.d.setKey(81);
        r.fav.add("dummy");
        cm.flushNow();
        Reg r2 = new Reg(); ConfigManager cm2 = new ConfigManager(dir, r2);
        check("second launch not first", !cm2.load());
        check("enabled persisted", r2.d.enabled() && r2.d.enables == 1);
        check("bool persisted", r2.d.flag.get());
        check("number persisted", r2.d.range.get() == 7.5);
        check("mode persisted", r2.d.mode.get().equals("C"));
        check("color persisted", r2.d.color.argb() == 0x80FF0000);
        check("key persisted", r2.d.key() == 81);
        check("favorites persisted", r2.fav.contains("dummy"));

        // invalid setting value -> default + message, rest of file still applied
        Path prof = dir.resolve("profiles/Default.json");
        String bad = Files.readString(prof).replace("\"range\": 7.5", "\"range\": 999");
        Files.writeString(prof, bad);
        Reg r3 = new Reg(); ConfigManager cm3 = new ConfigManager(dir, r3); cm3.load();
        check("invalid value falls back to default", r3.d.range.get() == 5.0);
        check("valid values still applied", r3.d.flag.get());
        check("error explains fix", cm3.drainErrors().stream().anyMatch(s -> s.contains("Range") && s.contains("Reset")));

        // corrupt file recovery
        Files.writeString(prof, "{ this is not json");
        Reg r4 = new Reg(); ConfigManager cm4 = new ConfigManager(dir, r4); cm4.load();
        check("corrupt -> defaults", !r4.d.flag.get() && !r4.d.enabled());
        check("corrupt file kept as backup", Files.list(dir.resolve("profiles")).anyMatch(p -> p.getFileName().toString().contains(".corrupt-")));
        check("corrupt reported", !cm4.drainErrors().isEmpty());

        // profiles + export/import
        r4.d.flag.set(true); cm4.flushNow();
        String p2 = cm4.createFromCurrent();
        check("new profile active", cm4.active().equals(p2) && cm4.profiles().contains(p2));
        r4.d.flag.set(false); cm4.switchTo("Default");
        check("switch restores profile state", r4.d.flag.get());
        Path ex = cm4.exportActive();
        check("export exists", Files.exists(ex));
        String imported = cm4.importFile("Default.json");
        check("import creates uniquely named profile", imported != null && !imported.equals("Default"));
        check("import rejects traversal", cm4.importFile("../state.json") == null);
        Files.writeString(cm4.exportsDir().resolve("evil.json"), "[1,2,3]");
        check("import rejects non-object", cm4.importFile("evil.json") == null);
        check("delete refuses active", !cm4.delete(cm4.active()));

        // migrations
        Migrations.steps().put(1, o -> { o.addProperty("migrated", true); return o; });
        JsonObject v1 = new JsonObject(); v1.addProperty("schemaVersion", 1);
        check("migration runs", Migrations.migrate(v1, 2).get("migrated").getAsBoolean());
        Migrations.steps().clear();
        JsonObject future = new JsonObject(); future.addProperty("schemaVersion", 99);
        boolean t2 = false; try { Migrations.migrate(future, 1); } catch (IllegalArgumentException e) { t2 = true; }
        check("newer schema refused", t2);

        // lifecycle: no duplicate enable/disable
        Dummy d = new Dummy(); d.setEnabled(true); d.setEnabled(true); d.setEnabled(false); d.setEnabled(false);
        check("lifecycle once each", d.enables == 1 && d.disables == 1);
        System.out.println("ConfigTests: " + (run - failures) + "/" + run + " passed");
        return failures;
    }

    public static void main(String[] a) throws Exception { if (run() > 0) System.exit(1); }
}
