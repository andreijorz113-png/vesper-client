package dev.vesper;

import dev.vesper.calc.ExplosionMath;
import dev.vesper.calc.ExplosionMath.Defense;
import dev.vesper.calc.ExplosionMath.Difficulty;

/** Plain-Java checks (no framework needed). Expected values are derived by hand from the vanilla formulas. */
public final class ExplosionMathTests {
    static int failures = 0, run = 0;

    static void eq(String name, double actual, double expected, double eps) {
        run++;
        if (Math.abs(actual - expected) > eps) {
            failures++;
            System.err.println("FAIL " + name + ": expected " + expected + " got " + actual);
        }
    }

    public static int run() {
        failures = 0; run = 0;
        eq("raw point blank", ExplosionMath.rawDamage(0, 1, 6f), 85.0, 1e-6);
        eq("raw half radius", ExplosionMath.rawDamage(6, 1, 6f), 32.0, 1e-6);
        eq("raw edge", ExplosionMath.rawDamage(12, 1, 6f), 0.0, 1e-6);
        eq("raw outside", ExplosionMath.rawDamage(13, 1, 6f), 0.0, 1e-6);
        eq("raw no exposure", ExplosionMath.rawDamage(2, 0, 6f), 0.0, 1e-6);
        eq("difficulty hard", ExplosionMath.scaleForDifficulty(85, Difficulty.HARD), 127.5, 1e-6);
        eq("difficulty easy", ExplosionMath.scaleForDifficulty(85, Difficulty.EASY), 43.5, 1e-6);
        eq("difficulty peaceful", ExplosionMath.scaleForDifficulty(85, Difficulty.PEACEFUL), 0.0, 1e-6);
        eq("armor 20/8 on 32", ExplosionMath.afterArmor(32, 20, 8), 16.64, 1e-4);
        eq("resistance I", ExplosionMath.afterResistance(100, 0), 80.0, 1e-4);
        eq("resistance V", ExplosionMath.afterResistance(100, 4), 0.0, 1e-4);
        eq("epf cap", ExplosionMath.afterEnchantments(100, 32), 20.0, 1e-4);
        // full chain: 85 raw, hard, armor 20/8, resistance I, EPF 32 (capped 20)
        // 127.5 -> *0.84 = 107.1 -> *0.8 = 85.68 -> *0.2 = 17.136
        Defense full = new Defense(20, 8, 32, 0, 0);
        eq("full chain", ExplosionMath.finalDamage(85, Difficulty.HARD, full), 17.136, 1e-3);
        eq("health after w/ absorption", ExplosionMath.healthAfter(10, 14, new Defense(0, 0, 0, -1, 4)), 0.0, 1e-6);
        System.out.println("ExplosionMathTests: " + (run - failures) + "/" + run + " passed");
        return failures;
    }

    public static void main(String[] args) {
        if (run() > 0) System.exit(1);
    }
}
