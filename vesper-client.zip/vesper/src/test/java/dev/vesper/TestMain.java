package dev.vesper;

public final class TestMain {
    public static void main(String[] args) throws Exception {
        int f = ExplosionMathTests.run() + ConfigTests.run() + IntegrationTests.run();
        if (f > 0) { System.err.println(f + " test(s) failed"); System.exit(1); }
        System.out.println("All tests passed");
    }
}
